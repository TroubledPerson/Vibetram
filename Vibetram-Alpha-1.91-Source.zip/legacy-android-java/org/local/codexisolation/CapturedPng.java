// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;
import java.nio.ByteBuffer;
import java.io.*;
import java.util.zip.*;
import java.nio.charset.StandardCharsets;

/** Bounded in-memory RGBA plane normalization. Never writes files or returns tool content. */
final class CapturedPng {
 final int width,height;final String sha256;private final byte[] encoded;
 private CapturedPng(int w,int h,byte[] bytes){width=w;height=h;encoded=bytes;sha256=SyntheticReviewCoordinator.hash(bytes);}
 byte[] bytes(){return encoded.clone();}int size(){return encoded.length;}
 static final class PendingFrame{
  private final int width,height;private final byte[] dense;
  private PendingFrame(int w,int h,byte[] dense){width=w;height=h;this.dense=dense;}
  CapturedPng encode(){return rgba(ByteBuffer.wrap(dense),width,height,width*4,4);}
  SameFramePng.Result encodeBounded(java.util.function.BooleanSupplier allowed){return SameFramePng.encode(dense,width,height,allowed);}
 }
 static PendingFrame copyPlane(ByteBuffer input,int w,int h,int rowStride,int pixelStride){
  ByteBuffer data=checked(input,w,h,rowStride,pixelStride);int base=data.position();byte[] dense=new byte[w*h*4];
  for(int y=0;y<h;y++){ByteBuffer row=data.duplicate();row.position(base+y*rowStride);row.get(dense,y*w*4,w*4);}
  return new PendingFrame(w,h,dense);
 }
 private static ByteBuffer checked(ByteBuffer input,int w,int h,int rowStride,int pixelStride){
  if(input==null||w<1||h<1||w>1024||h>1024||(long)w*h>1048576||pixelStride!=4||rowStride<(long)w*4
    ||(long)rowStride*h>8*1024*1024)throw new IllegalArgumentException("RGBA_BOUNDS_REJECTED");
  ByteBuffer data=input.duplicate();int base=data.position();long needed=(long)(h-1)*rowStride+(long)(w-1)*4+4;
  if(needed>data.remaining())throw new IllegalArgumentException("RGBA_BUFFER_TOO_SMALL");return data;
 }
 static CapturedPng rgba(ByteBuffer input,int w,int h,int rowStride,int pixelStride){
  return rgba(input,w,h,rowStride,pixelStride,()->{});
 }
 static CapturedPng rgba(ByteBuffer input,int w,int h,int rowStride,int pixelStride,Runnable guard){
  return rgba(input,w,h,rowStride,pixelStride,guard,true);
 }
 static CapturedPng rgba(ByteBuffer input,int w,int h,int rowStride,int pixelStride,Runnable guard,boolean rejectUniform){
  guard.run();
  ByteBuffer data=checked(input,w,h,rowStride,pixelStride);int base=data.position();
  Limited compressed=new Limited(32768-57);boolean varied=false;int first=-1;
  try{
   try(DeflaterOutputStream deflate=new DeflaterOutputStream(compressed)){
    byte[] row=new byte[1+w*3];for(int y=0;y<h;y++){guard.run();row[0]=0;
     for(int x=0;x<w;x++){int offset=base+y*rowStride+x*4,a=data.get(offset+3)&255;
      int r=(data.get(offset)&255)*a/255,g=(data.get(offset+1)&255)*a/255,b=(data.get(offset+2)&255)*a/255;
      int rgb=r<<16|g<<8|b;if(first<0)first=rgb;else if(rgb!=first)varied=true;
      row[1+x*3]=(byte)r;row[2+x*3]=(byte)g;row[3+x*3]=(byte)b;
     }deflate.write(row);
    }
   }
   if(rejectUniform&&!varied)throw new IllegalArgumentException("UNIFORM_OR_BLANK_FRAME_REJECTED");
   ByteArrayOutputStream out=new ByteArrayOutputStream();out.write(new byte[]{(byte)137,80,78,71,13,10,26,10});
   ByteArrayOutputStream header=new ByteArrayOutputStream();number(header,w);number(header,h);header.write(new byte[]{8,2,0,0,0});
   chunk(out,"IHDR",header.toByteArray());chunk(out,"IDAT",compressed.toByteArray());chunk(out,"IEND",new byte[0]);
   byte[] bytes=out.toByteArray();if(bytes.length>32768)throw new IllegalArgumentException("PNG_SIZE_LIMIT");
   guard.run();PngImageContent.fromPng(bytes);guard.run();return new CapturedPng(w,h,bytes);
  }catch(IOException error){throw new IllegalArgumentException("PNG_ENCODING_FAILED");}
 }
 private static final class Limited extends ByteArrayOutputStream{
  final int max;Limited(int max){this.max=max;}
  @Override public synchronized void write(int b){if(count>=max)throw new IllegalArgumentException("PNG_SIZE_LIMIT");super.write(b);}
  @Override public synchronized void write(byte[] b,int o,int n){if(n>max-count)throw new IllegalArgumentException("PNG_SIZE_LIMIT");super.write(b,o,n);}
 }
 private static void number(ByteArrayOutputStream out,int n){out.write(n>>>24);out.write(n>>>16);out.write(n>>>8);out.write(n);}
 private static void chunk(ByteArrayOutputStream out,String type,byte[] bytes)throws IOException{
  byte[] name=type.getBytes(StandardCharsets.US_ASCII);number(out,bytes.length);out.write(name);out.write(bytes);
  CRC32 crc=new CRC32();crc.update(name);crc.update(bytes);number(out,(int)crc.getValue());
 }
}
