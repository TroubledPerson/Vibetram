// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.File;

/** Runs only the packaged offline fake child. No device-code or provider request. */
public final class OfflineSyntheticTurnActivity extends Activity {
    private volatile OfflineSyntheticTurnSession session;
    private volatile boolean destroyed;
    private boolean attempted;
    @Override public void onCreate(Bundle saved){
        super.onCreate(saved);
        attempted=saved!=null&&saved.getBoolean("attempted");
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setOnApplyWindowInsetsListener((v,insets)->{
            if(Build.VERSION.SDK_INT>=30){
                android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout());
                v.setPadding(bars.left,bars.top,bars.right,bars.bottom);
            }else v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),
                    insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());
            return insets;
        });
        Button run=new Button(this);run.setText("RUN OFFLINE SYNTHETIC TURN");run.setEnabled(!attempted);
        TextView report=new TextView(this);report.setTextIsSelectable(true);
        report.setText("1.37 offline synthetic turn. Fake child and fake account only. Keep the phone offline. No sign-in, provider, model, or network request.\n");
        root.addView(run);ScrollView scroll=new ScrollView(this);scroll.addView(report);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);root.requestApplyInsets();
        run.setOnClickListener(v->{
            if(attempted)return;attempted=true;run.setEnabled(false);
            if(Build.VERSION.SDK_INT<29||!"arm64-v8a".equals(Build.SUPPORTED_ABIS[0])){
                report.append("FAIL code=UNSUPPORTED_DEVICE\n");return;
            }
            File fake=new File(getApplicationInfo().nativeLibraryDir,"libcodex_fake_turn.so");
            new Thread(()->{
                for(OfflineSyntheticTurnSession.Mode mode:OfflineSyntheticTurnSession.Mode.values()){
                    session=new OfflineSyntheticTurnSession(OfflineAppServerAdapter.SYSTEM,
                            OfflineSyntheticTurnSession.FAKE_CHILD_SHA256);
                    String line;
                    try{
                        OfflineSyntheticTurnSession.Result result=session.run(getFilesDir(),fake,mode);
                        line=mode==OfflineSyntheticTurnSession.Mode.COMPLETE
                                ?"PASS mode=COMPLETE stage="+session.stage()+" fakeAccount=ONLY chunks="+result.chunks
                                    +" authJson=ABSENT modelRequests=0 networkRequests=0"
                                :"FAIL mode=CANCEL_AFTER_DELTA code=NOT_CANCELLED";
                    }catch(OfflineSyntheticTurnSession.GateException e){
                        line=mode==OfflineSyntheticTurnSession.Mode.CANCEL_AFTER_DELTA
                                &&"CANCELLED".equals(e.code)
                                ?"PASS mode=CANCEL_AFTER_DELTA stage="+session.stage()
                                    +" fakeAccount=ONLY authJson=ABSENT modelRequests=0 networkRequests=0"
                                :"FAIL mode="+mode+" stage="+session.stage()+" code="+e.code;
                    }
                    String output=line;
                    runOnUiThread(()->{if(!destroyed)report.append(output+"\n");});
                    if(line.startsWith("FAIL"))break;
                }
            },"offline-synthetic-turn-parent").start();
        });
    }
    @Override protected void onSaveInstanceState(Bundle out){out.putBoolean("attempted",attempted);super.onSaveInstanceState(out);}
    @Override protected void onDestroy(){destroyed=true;if(session!=null)session.cancel();super.onDestroy();}
}
