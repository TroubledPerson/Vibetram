// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

/** Source candidate: one read-only capability, never preloaded note contents. */
final class NativeCoreProbe {
    static byte[] runInIsolatedService(NoteClient client, ModelClient model) {
        if (!android.os.Process.isIsolated()) {
            throw new SecurityException("Core fixture requires an isolated process");
        }
        // Check isolation before loading or initializing any native library.
        System.loadLibrary("codex_android_model_broker");
        return runModelBrokerProof(client,model);
    }

    private static native byte[] runModelBrokerProof(NoteClient client, ModelClient model);
    private NativeCoreProbe() {}
}
