// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Pure request-only response transform. Deliberately has no NoteGrant reference. */
final class ModelPolicy {
    static final int MAX_JSON=65536,MAX_WIRE=65546,MAX_REPLY=92;
    private static SecurityException bad(){return new SecurityException("Offline model route rejected");}
    @SuppressWarnings("unchecked") private static Map<String,Object> map(Object x){if(!(x instanceof Map))throw bad();return (Map<String,Object>)x;}
    @SuppressWarnings("unchecked") private static List<Object> list(Object x){if(!(x instanceof List))throw bad();return (List<Object>)x;}
    private static void equal(Object got,String expected){if(!expected.equals(got))throw bad();}
    static byte[] reply(int id,byte[] wire){
        if(id<1||id>2||wire==null||wire.length<10||wire.length>MAX_WIRE)throw bad();
        if(wire[0]!='M'||wire[1]!='B'||wire[2]!='Q'||wire[3]!='1'||wire[4]!=id||wire[5]!=(id==2?1:0))throw bad();
        long size=0;for(int i=0;i<4;i++)size|=(long)(wire[6+i]&255)<<(8*i);
        if(size>MAX_JSON||size!=wire.length-10)throw bad();
        Map<String,Object> request=map(BoundedJson.parse(Arrays.copyOfRange(wire,10,wire.length)));
        if(request.get("tools")!=null)throw bad();
        List<Object> input=list(request.get("input"));if(input.size()>64)throw bad();
        int calls=0,outputs=0,adverts=0;String note=null;
        for(Object v:input){Map<String,Object> item=map(v);Object type=item.get("type");
            if("additional_tools".equals(type)){
                adverts++;equal(item.get("role"),"developer");List<Object> namespaces=list(item.get("tools"));if(namespaces.size()!=1)throw bad();Map<String,Object> ns=map(namespaces.get(0));equal(ns.get("type"),"namespace");equal(ns.get("name"),"fixture");List<Object> tools=list(ns.get("tools"));if(tools.size()!=1)throw bad();Map<String,Object> tool=map(tools.get(0));equal(tool.get("type"),"function");equal(tool.get("name"),"read_text");
            }else if("function_call".equals(type)){
                calls++;equal(item.get("namespace"),"fixture");equal(item.get("name"),"read_text");equal(item.get("arguments"),"{\"path\":\"note.txt\"}");equal(item.get("call_id"),"fixture-read-1");
            }else if("function_call_output".equals(type)){
                outputs++;equal(item.get("call_id"),"fixture-read-1");if(!(item.get("output") instanceof String))throw bad();note=(String)item.get("output");
            }else if(!"message".equals(type)&&!"reasoning".equals(type)){throw bad();}
        }
        if(adverts!=1||calls!=(id==1?0:1)||outputs!=(id==1?0:1))throw bad();
        if(id==1)return new byte[]{'M','B','R','1',1,1};
        if(note==null||!note.matches("parent-note-[0-9a-f]{64}"))throw bad();
        byte[] text=("note-read:"+note).getBytes(StandardCharsets.US_ASCII),reply=new byte[92];
        System.arraycopy(new byte[]{'M','B','R','1',2,2},0,reply,0,6);System.arraycopy(text,0,reply,6,86);return reply;
    }
    static void validateReply(int id,byte[] reply){if(reply==null||reply.length!=(id==1?6:92)||!Arrays.equals(Arrays.copyOf(reply,6),new byte[]{'M','B','R','1',(byte)id,(byte)id}))throw bad();}
}
