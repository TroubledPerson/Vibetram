// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

import android.os.IBinder;
import android.os.Parcel;
import android.os.RemoteException;
import java.util.concurrent.atomic.AtomicBoolean;

/** JNI callback: no paths, credentials, content, or general operations as arguments. */
public final class NoteClient {
    private final IBinder broker;
    private final byte[] token;
    private final long generation;
    private final AtomicBoolean used = new AtomicBoolean();
    private final boolean replay;
    NoteClient(IBinder broker, byte[] token, long generation) {
        this(broker, token, generation, false);
    }
    NoteClient(IBinder broker, byte[] token, long generation, boolean replay) {
        this.broker = broker; this.token = token.clone(); this.generation = generation;
        this.replay = replay;
    }
    public byte[] readNote() throws RemoteException {
        if (!used.compareAndSet(false, true)) throw new SecurityException("Read already attempted");
        Parcel in = Parcel.obtain(), out = Parcel.obtain();
        try {
            in.writeInterfaceToken(NoteGrant.DESCRIPTOR);
            in.writeByteArray(token);
            in.writeLong(generation);
            in.writeInt(1);
            if (!broker.transact(NoteGrant.READ, in, out, 0) || out.dataSize() > NoteGrant.MAX_PARCEL)
                throw new RemoteException("Invalid note reply");
            out.readException();
            if (out.dataAvail() < 16 || out.readLong() != generation || out.readInt() != 1)
                throw new RemoteException("Stale note reply");
            // Note is always 12 ASCII prefix bytes + 64 fresh hex characters.
            byte[] bytes = new byte[76];
            out.readByteArray(bytes);
            if (out.dataAvail() != 0) throw new RemoteException("Trailing note reply");
            if (replay) {
                // Test-only protocol probe, not a second Session tool invocation.
                try {
                    new NoteClient(broker, token, generation).readNote();
                    throw new RemoteException("Replay unexpectedly succeeded");
                } catch (SecurityException expectedDenial) { /* Parent must confirm DENY:REPLAY. */ }
            }
            return bytes;
        } finally { in.recycle(); out.recycle(); }
    }
}
