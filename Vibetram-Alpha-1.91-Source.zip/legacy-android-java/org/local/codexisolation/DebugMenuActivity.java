// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.List;

/** Navigation only: no workers, capture, authentication, or remote activation. */
abstract class DebugMenuActivity extends Activity {
    private boolean opening;
    final void showMenu(String title, String explanation, List<DebugNavigationCatalog.Route> routes) {
        LinearLayout layout=new LinearLayout(this);layout.setOrientation(LinearLayout.VERTICAL);
        layout.setOnApplyWindowInsetsListener((v,insets)->{
            if(Build.VERSION.SDK_INT>=30){
                android.graphics.Insets bars=insets.getInsets(android.view.WindowInsets.Type.systemBars()|android.view.WindowInsets.Type.displayCutout());
                v.setPadding(bars.left,bars.top,bars.right,bars.bottom);
            }else v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());
            return insets;
        });
        TextView heading=new TextView(this);heading.setText(title);heading.setTextSize(22);layout.addView(heading);
        TextView note=new TextView(this);note.setText(explanation);layout.addView(note);
        for(DebugNavigationCatalog.Route route:routes){
            Button button=new Button(this);button.setText(route.label);
            button.setOnClickListener(v->{
                if(opening||isFinishing()||!hasWindowFocus())return;
                opening=true;
                startActivity(new Intent().setClassName(this,route.activity));
            });
            layout.addView(button,new LinearLayout.LayoutParams(-1,-2));
        }
        ScrollView scroll=new ScrollView(this);scroll.addView(layout);setContentView(scroll);layout.requestApplyInsets();
    }
    @Override protected void onResume(){super.onResume();opening=false;}
}
