// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

/** Process-local, foreground-only permission for fixed screen capability status. */
final class ScreenStatusGate {
    private long epoch = 1;
    private boolean enabled;
    private boolean foreground;
    private boolean focused;

    synchronized void setForeground(boolean value) {
        foreground = value;
        if (!value) stop();
    }

    synchronized void setFocused(boolean value) {
        focused = value;
        if (!value) stop();
    }

    synchronized boolean enable() {
        if (!foreground || !focused || enabled) return false;
        enabled = true;
        epoch++;
        return true;
    }

    synchronized void stop() {
        enabled = false;
        epoch++;
    }

    synchronized boolean active() { return enabled && foreground && focused; }

    synchronized long token() { return active() ? epoch : -1; }

    synchronized boolean valid(long token) { return token > 0 && token == epoch && active(); }

    static String fixedResult() {
        return "SCREEN_STATUS active=true capture=not_integrated tap=not_integrated";
    }
}
