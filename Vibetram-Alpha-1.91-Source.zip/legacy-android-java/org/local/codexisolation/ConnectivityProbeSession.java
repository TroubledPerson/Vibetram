// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/** One explicit, credential-free native reachability check. */
final class ConnectivityProbeSession {
    private static final int MAX_OUTPUT=256;
    private final OfflineAppServerAdapter.ProcessFactory factory;
    private final AtomicBoolean started=new AtomicBoolean(),cancelled=new AtomicBoolean();
    private volatile Process child;
    ConnectivityProbeSession(OfflineAppServerAdapter.ProcessFactory factory){this.factory=factory;}
    void cancel(){cancelled.set(true);Process p=child;if(p!=null)p.destroyForcibly();}

    String run(File filesDir,File binary) {
        if(!started.compareAndSet(false,true))return "ALREADY_RUN";
        if(cancelled.get())return "CANCELLED";
        Process p=null;
        try{
            File privateDir=filesDir.getCanonicalFile();
            if(!privateDir.isDirectory()||!binary.isFile()||!binary.canExecute())return "CLIENT_BUILD_FAILED";
            File home=new File(privateDir,"connectivity-home-v37").getCanonicalFile();
            if(!privateDir.equals(home.getParentFile()))return "CLIENT_BUILD_FAILED";
            Files.createDirectories(home.toPath());
            Map<String,String> env=new HashMap<>();
            env.put("PATH","/system/bin");env.put("HOME",home.getPath());env.put("CODEX_HOME",home.getPath());
            p=factory.start(Arrays.asList(binary.getAbsolutePath(),"--coretest-connectivity-probe"),env);
            child=p;
            if(cancelled.get())return "CANCELLED";
            if(!p.waitFor(15,TimeUnit.SECONDS))return "OVERALL_DEADLINE";
            if(cancelled.get())return "CANCELLED";
            String stdout=new String(readBounded(p.getInputStream()),StandardCharsets.US_ASCII);
            // Ignore stderr content entirely; only the fixed stdout grammar can reach the UI.
            if(p.exitValue()!=0)return "OTHER_TRANSPORT_FAILED";
            return parseFixedOutput(stdout);
        }catch(Exception ignored){return cancelled.get()?"CANCELLED":"OTHER_TRANSPORT_FAILED";}
        finally{if(p!=null)p.destroyForcibly();child=null;}
    }
    private static byte[] readBounded(InputStream in) throws IOException {
        ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] chunk=new byte[64];int n;
        while((n=in.read(chunk))!=-1){if(out.size()+n>MAX_OUTPUT)throw new IOException("output bound");out.write(chunk,0,n);}
        return out.toByteArray();
    }
    static String parseFixedOutput(String output){
        String[] lines=output.split("\\n",-1);
        if(lines.length<2||lines.length>4||!lines[lines.length-1].isEmpty())return "OTHER_TRANSPORT_FAILED";
        StringBuilder result=new StringBuilder();int seen=0;
        for(int i=0;i<lines.length-1;i++){
            String line=lines[i].replace("\r","");
            if("OVERALL_DEADLINE".equals(line)&&i==lines.length-2){
                if(result.length()>0)result.append('\n');
                result.append(line);return result.toString();
            }
            String prefix="RESULT_"+(seen+1)+"=";
            if(seen>=2||!line.startsWith(prefix)||!allowed(line.substring(prefix.length())))
                return "OTHER_TRANSPORT_FAILED";
            if(result.length()>0)result.append('\n');
            result.append(line);seen++;
        }
        return seen>=1?result.toString():"OTHER_TRANSPORT_FAILED";
    }
    private static boolean allowed(String value){
        return "CLIENT_BUILD_FAILED".equals(value)||"CONNECT_FAILED".equals(value)
                ||"TIMEOUT".equals(value)||"OTHER_TRANSPORT_FAILED".equals(value)
                ||"HTTP_REACHED".equals(value);
    }
}
