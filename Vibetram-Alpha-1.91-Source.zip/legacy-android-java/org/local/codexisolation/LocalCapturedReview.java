// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;
/** Exact-image local receipt only. Synthetic access modes cannot authorize this path. */
final class LocalCapturedReview {
 interface Owner{boolean live();boolean replace(CapturedPng oldFrame,CapturedPng next);boolean finish(CapturedPng expected);void revoke(String code);}
 static final class Approval{private final LocalCapturedReview owner;final long revision;final String hash;private Approval(LocalCapturedReview o,long r,String h){owner=o;revision=r;hash=h;}}
 static final class Receipt{final long revision;final String hash;final int width,height,bytes;private Receipt(long r,CapturedPng p){revision=r;hash=p.sha256;width=p.width;height=p.height;bytes=p.size();}}
 private final Owner owner;private LocalReviewImage image;private CapturedPng frame;private Approval approval;private long revision=1;private int edits;private boolean closed;private String status="LOCAL_REVIEW_READY";
 LocalCapturedReview(CapturedPng input,int[] argb,Owner owner){
  if(input==null||owner==null)throw new IllegalArgumentException("LOCAL_REVIEW_INPUT");this.owner=owner;
  LocalReviewImage decoded=LocalReviewImage.fromArgb(input.width,input.height,argb,this::guard);
  if(!decoded.png.sha256.equals(input.sha256))throw new IllegalArgumentException("LOCAL_REVIEW_DECODE_BINDING");image=decoded;frame=input;
 }
 private boolean active(){if(closed)return false;if(!owner.live()){close("LOCAL_REVIEW_REVOKED");return false;}return true;}
 private void guard(){if(!active())throw new IllegalStateException("LOCAL_REVIEW_REVOKED");}
 synchronized CapturedPng preview(){return active()?frame:null;}
 synchronized long revision(){return revision;}
 synchronized int remainingEdits(){return active()?8-edits:0;}
 synchronized String status(){active();return status;}
 synchronized boolean pending(Approval candidate){return active()&&candidate!=null&&candidate==approval&&candidate.revision==revision;}
 synchronized Approval requestApproval(long displayedRevision,String displayedHash){
  if(!active()||frame==null||displayedRevision!=revision||!frame.sha256.equals(displayedHash))return null;
  approval=new Approval(this,revision,frame.sha256);status="APPROVE_EXACT_IMAGE_LOCALLY";return approval;
 }
 synchronized boolean edit(boolean crop,int x,int y,int w,int h){
  if(!active())return false;approval=null;revision++;status="EDIT_REJECTED_FRESH_APPROVAL_REQUIRED";
  if(edits>=8)return false;edits++;
  try{
   LocalReviewImage next=crop?image.crop(x,y,w,h,this::guard):image.redact(x,y,w,h,this::guard);guard();
   if(!owner.replace(frame,next.png)){close("LOCAL_REVIEW_REVOKED");return false;}
   image=next;frame=next.png;status="IMAGE_CHANGED_FRESH_APPROVAL_REQUIRED";return true;
  }catch(IllegalArgumentException rejected){return false;}catch(IllegalStateException revoked){close("LOCAL_REVIEW_REVOKED");return false;}
 }
 synchronized Receipt approve(Approval candidate,boolean allow){
  if(!active()||candidate==null||candidate!=approval||candidate.owner!=this||candidate.revision!=revision||!candidate.hash.equals(frame.sha256)||!candidate.hash.equals(SyntheticReviewCoordinator.hash(frame.bytes())))return null;
  if(!allow){close("LOCAL_REVIEW_NOT_APPROVED");return null;}
  if(!active())return null;if(!owner.finish(frame)){close("LOCAL_REVIEW_REVOKED");return null;}
  Receipt receipt=new Receipt(revision,frame);release();closed=true;status="APPROVED_LOCALLY_NOTHING_TRANSMITTED";return receipt;
 }
 synchronized void close(String code){if(closed)return;closed=true;release();status=code;owner.revoke(code);}
 private void release(){image=null;frame=null;approval=null;}
}
