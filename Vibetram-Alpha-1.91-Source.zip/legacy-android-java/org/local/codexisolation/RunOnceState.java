// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;
final class RunOnceState {
    private boolean chosen,attempted;
    RunOnceState(boolean restoredAttempt){attempted=restoredAttempt;}
    boolean select(){if(attempted)return false;chosen=true;return true;}
    boolean begin(){if(!chosen||attempted)return false;attempted=true;return true;}
    boolean attempted(){return attempted;}
}
