// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
/** Wait outside authority locks. Explicit revocation always precedes wakeup. */
final class StreamGate {
    static final int SUCCESS=0,REVOKE=1,TIMEOUT=2,WAIT_MS=1200,DELAY_MS=200;
    final int mode;private final GrantState.Clock clock;private final CountDownLatch signal=new CountDownLatch(1);
    private boolean held,released,returned,aborted,timedOut,rejected;private int order,entryOrder,cancelOrder,releaseOrder,commitOrder,rejectOrder,sinkEntries;private long entered,elapsed;
    StreamGate(int mode,GrantState.Clock clock){if(mode<0||mode>2)throw new IllegalArgumentException();this.mode=mode;this.clock=clock;}
    void hold(StreamState state,Runnable notify){
        synchronized(this){if(held||mode==SUCCESS){aborted=true;throw new SecurityException("Invalid hold");}held=true;entered=clock.now();entryOrder=++order;}
        try{notify.run();boolean woke=signal.await(WAIT_MS,TimeUnit.MILLISECONDS);
            if(!woke){state.cancel("TIMEOUT");synchronized(this){if(released){aborted=true;}else{timedOut=true;cancelOrder=++order;released=true;releaseOrder=++order;}}signal.countDown();}
        }catch(InterruptedException e){Thread.currentThread().interrupt();cleanup(state);}catch(RuntimeException e){cleanup(state);}
        synchronized(this){returned=true;elapsed=clock.now()-entered;}
    }
    boolean revokeAndRelease(StreamState state){state.cancel("REVOKED");boolean valid;
        synchronized(this){long ms=clock.now()-entered;valid=mode==REVOKE&&held&&!released&&!aborted&&ms>=DELAY_MS&&ms<WAIT_MS;if(valid){cancelOrder=++order;released=true;releaseOrder=++order;}else aborted=true;}
        signal.countDown();return valid;
    }
    void cleanup(StreamState state){state.cancel("CANCELLED");synchronized(this){if(held&&!released)aborted=true;}signal.countDown();}
    synchronized void beforeCommit(){if(!held||!returned||!released||commitOrder!=0)aborted=true;commitOrder=++order;}
    synchronized void sinkEntered(){sinkEntries++;aborted=true;throw new SecurityException("Held frame serialized");}
    synchronized void rejected(){if(rejectOrder!=0)aborted=true;rejected=true;rejectOrder=++order;}
    synchronized boolean proven(){return mode!=SUCCESS&&held&&released&&returned&&!aborted&&rejected&&sinkEntries==0&&entryOrder==1&&cancelOrder==2&&releaseOrder==3&&commitOrder==4&&rejectOrder==5&&(mode==REVOKE?!timedOut&&elapsed>=DELAY_MS&&elapsed<WAIT_MS:timedOut&&elapsed>=WAIT_MS&&elapsed<2000);}
    synchronized String report(){return "held="+held+" released="+released+" returned="+returned+" timedOut="+timedOut+" aborted="+aborted+" order="+entryOrder+","+cancelOrder+","+releaseOrder+","+commitOrder+","+rejectOrder+" rejected="+rejected+" heldSinkEntries="+sinkEntries+" holdMs="+elapsed;}
    boolean signalled(){return signal.getCount()==0;}
}
