// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;

/** Fixed MBP1 frame; no JSON, paths, commands or unbounded transcript. */
final class OutputProof {
    static final int LENGTH=171;
    final byte[] noteHash,finalHash;
    private OutputProof(byte[] noteHash,byte[] finalHash){this.noteHash=noteHash;this.finalHash=finalHash;}
    static OutputProof parse(byte[] frame,byte[] expectedNoteHash) {
        byte[] header=new byte[]{'M','B','P','1',2,1,7,76,86};
        if(frame==null||frame.length!=LENGTH||expectedNoteHash==null||expectedNoteHash.length!=32
                ||!Arrays.equals(Arrays.copyOf(frame,9),header))throw new SecurityException("Proof header/bounds");
        byte[] note=Arrays.copyOfRange(frame,9,85),text=Arrays.copyOfRange(frame,85,171);
        byte[] prefix="parent-note-".getBytes(StandardCharsets.US_ASCII);
        if(!Arrays.equals(Arrays.copyOf(note,12),prefix))throw new SecurityException("Note prefix");
        for(int i=12;i<76;i++)if(!((note[i]>='0'&&note[i]<='9')||(note[i]>='a'&&note[i]<='f')))throw new SecurityException("Note encoding");
        byte[] expectedFinal=new byte[86];byte[] finalPrefix="note-read:".getBytes(StandardCharsets.US_ASCII);
        System.arraycopy(finalPrefix,0,expectedFinal,0,10);System.arraycopy(note,0,expectedFinal,10,76);
        byte[] hash=GrantState.digest(note);
        if(!MessageDigest.isEqual(hash,expectedNoteHash)||!Arrays.equals(text,expectedFinal))throw new SecurityException("Proof output dependency");
        return new OutputProof(hash,GrantState.digest(text));
    }
}
