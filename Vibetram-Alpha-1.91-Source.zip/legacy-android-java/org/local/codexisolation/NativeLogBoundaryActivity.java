// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.File;

/** Synthetic offline native logging check; no login or device-code request. */
public final class NativeLogBoundaryActivity extends Activity {
    private NativeLogBoundarySession session;
    private boolean attempted,destroyed;
    @Override public void onCreate(Bundle saved){
        super.onCreate(saved);
        attempted=saved!=null&&saved.getBoolean("attempted");
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setOnApplyWindowInsetsListener((v,insets)->{
            if(Build.VERSION.SDK_INT>=30){
                android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout());
                v.setPadding(bars.left,bars.top,bars.right,bars.bottom);
            }else{
                v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),
                        insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());
            }
            return insets;
        });
        Button run=new Button(this);run.setText("RUN OFFLINE NATIVE LOG CHECK ONCE");run.setEnabled(!attempted);
        TextView report=new TextView(this);report.setTextIsSelectable(true);
        report.setText("1.37 synthetic native log check. Keep the phone offline. No sign-in, code, token, or model request.\n");
        root.addView(run);ScrollView scroll=new ScrollView(this);scroll.addView(report);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);root.requestApplyInsets();
        run.setOnClickListener(v->{
            if(attempted)return;attempted=true;run.setEnabled(false);
            report.append("CASE=OFFLINE_NATIVE_LOG_BOUNDARY\n");
            if(Build.VERSION.SDK_INT<29||!"arm64-v8a".equals(Build.SUPPORTED_ABIS[0])){
                report.append("FAIL code=UNSUPPORTED_DEVICE\n");return;
            }
            session=new NativeLogBoundarySession(OfflineAppServerAdapter.SYSTEM);
            File binary=new File(getApplicationInfo().nativeLibraryDir,"libcodex_app_server.so");
            new Thread(()->{
                for(NativeLogBoundarySession.Mode mode:NativeLogBoundarySession.Mode.values()){
                    String line;
                    try {
                        NativeLogBoundarySession.Result result=session.run(getFilesDir(),binary,mode);
                        line="PASS mode="+result.mode+" nativeMarker=EMITTED logsDb=CREATED"
                                +" markerOnDisk=ABSENT authJson=ABSENT files="+result.files
                                +" sidecars="+result.sidecars;
                    }catch(NativeLogBoundarySession.GateException e){
                        line="FAIL mode="+mode+" code="+e.code;
                    }
                    String output=line;
                    runOnUiThread(()->{if(!destroyed)report.append(output+"\n");});
                    if(line.startsWith("FAIL"))break;
                }
            },"offline-native-log-boundary").start();
        });
    }
    @Override protected void onSaveInstanceState(Bundle out){out.putBoolean("attempted",attempted);super.onSaveInstanceState(out);}
    @Override protected void onDestroy(){destroyed=true;if(session!=null)session.cancel();super.onDestroy();}
}
