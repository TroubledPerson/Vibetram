// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

/** Linearizes deliberate service stop versus unexpected destruction; never grants capture. */
final class OneShotTeardown {
 private boolean planned,unexpected;
 synchronized void plannedStop(Runnable stop){
  planned=true;stop.run();
 }
 synchronized boolean serviceDestroyed(Runnable revoke){
  if(planned||unexpected)return false;
  unexpected=true;revoke.run();return true;
 }
}
