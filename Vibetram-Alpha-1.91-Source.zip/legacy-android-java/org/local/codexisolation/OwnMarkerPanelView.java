// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.Paint;
import android.os.Looper;
import android.view.View;
import android.widget.ImageView;
import java.io.ByteArrayOutputStream;
import java.util.Base64;

/** Dedicated app-owned marker View. It contains no chat, account, or system UI. */
final class OwnMarkerPanelView extends ImageView {
    static final int SIDE_PX=300;
    private VisualPattern.Challenge shown;
    private long revision;
    private int selectedCell=-1;

    OwnMarkerPanelView(Context context){
        super(context);
        setScaleType(ScaleType.FIT_XY);
        setBackgroundColor(0xFFFFFFFF);
        setContentDescription("Synthetic marker panel");
        setVisibility(View.GONE);
    }

    void showFresh(){
        requireMain();
        showChallenge(VisualPattern.fresh());
    }

    /** Test-only panel change; never reuses the image revision approved for an action. */
    void regenerateForStaleTest(){
        requireMain();
        if(shown==null||selectedCell>=0||!isShown())throw new IllegalStateException("OWN_PANEL_NOT_VISIBLE");
        VisualPattern.Challenge challenge=VisualPattern.fresh();
        if(challenge.cell==shown.cell&&challenge.color==shown.color)
            challenge=VisualPattern.render((shown.cell+1)%9,shown.color);
        showChallenge(challenge);
    }

    private void showChallenge(VisualPattern.Challenge challenge){
        String url=PngImageContent.requireDataUrl(challenge.dataUrl);
        byte[] png=Base64.getDecoder().decode(url.substring(PngImageContent.PREFIX.length()));
        Bitmap decoded=BitmapFactory.decodeByteArray(png,0,png.length);
        if(decoded==null||decoded.getWidth()!=SIDE_PX||decoded.getHeight()!=SIDE_PX)
            throw new IllegalStateException("OWN_PANEL_IMAGE_INVALID");
        setImageBitmap(decoded);
        shown=challenge;
        selectedCell=-1;
        nextRevision();
        setVisibility(View.VISIBLE);
    }

    void clear(){
        requireMain();
        shown=null;selectedCell=-1;setImageBitmap(null);setVisibility(View.GONE);nextRevision();
    }

    /** Local diagnostic state only; does not render, capture, or expose marker contents. */
    long[] diagnosticState(){requireMain();return new long[]{revision,selectedCell};}

    ManagedChatSession.PanelImage snapshot(){
        requireMain();
        if(shown==null||selectedCell>=0||!isShown()||getWidth()!=SIDE_PX||getHeight()!=SIDE_PX)
            throw new IllegalStateException("OWN_PANEL_NOT_VISIBLE");
        Rect visible=new Rect();
        if(!getGlobalVisibleRect(visible)||visible.width()!=SIDE_PX||visible.height()!=SIDE_PX)
            throw new IllegalStateException("OWN_PANEL_NOT_VISIBLE");
        Bitmap bitmap=Bitmap.createBitmap(SIDE_PX,SIDE_PX,Bitmap.Config.ARGB_8888);
        try{
            Canvas canvas=new Canvas(bitmap);
            // This View is the entire capture boundary: no parent, root, window, or display draw.
            draw(canvas);
            ByteArrayOutputStream encoded=new ByteArrayOutputStream();
            if(!bitmap.compress(Bitmap.CompressFormat.PNG,100,encoded))
                throw new IllegalStateException("OWN_PANEL_ENCODE_FAILED");
            String url=PngImageContent.fromPng(encoded.toByteArray());
            return new ManagedChatSession.PanelImage(url,shown.expected,revision);
        }finally{bitmap.recycle();}
    }

    /** Local selection marker only; does not synthesize or dispatch a touch event. */
    boolean selectCell(long imageRevision,int row,int column){
        requireMain();
        if(row<0||row>2||column<0||column>2||shown==null||selectedCell>=0
                ||revision!=imageRevision||!isShown())return false;
        Rect visible=new Rect();
        if(!getGlobalVisibleRect(visible)||visible.width()!=SIDE_PX||visible.height()!=SIDE_PX)return false;
        selectedCell=row*3+column;
        nextRevision();
        invalidate();
        return true;
    }

    @Override protected void onDraw(Canvas canvas){
        super.onDraw(canvas);
        if(selectedCell<0)return;
        Paint mark=new Paint();mark.setColor(0xFF111111);mark.setStyle(Paint.Style.STROKE);
        mark.setStrokeWidth(6);
        int left=(selectedCell%3)*100+7,top=(selectedCell/3)*100+7;
        canvas.drawRect(left,top,left+86,top+86,mark);
    }

    private void nextRevision(){revision=revision==Long.MAX_VALUE?1:revision+1;}

    private static void requireMain(){
        if(Looper.myLooper()!=Looper.getMainLooper())throw new IllegalStateException("OWN_PANEL_THREAD_INVALID");
    }
}
