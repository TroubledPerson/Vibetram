// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;
import android.os.Bundle;
public final class StreamDebugToolsActivity extends DebugMenuActivity {
    @Override public void onCreate(Bundle saved){
        super.onCreate(saved);
        showMenu("Stream debug tools",
            "Historical tests remain available. Each screen keeps its original explicit Run/sign-in controls and prerequisites. The one-turn and connectivity screens can contact OpenAI only after their separate user action. Back returns without starting a test.",
            DebugNavigationCatalog.stream());
    }
}
