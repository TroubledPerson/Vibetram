// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

/** Simulated consent events only. Cannot launch a system request, acquire screen pixels or send data. */
final class SimulatedHandoff {
    enum State {IDLE,PENDING,HELD,RETURNED,CONFIRM,GENERATING,PREVIEW,REVIEW,DONE,CLOSED}
    interface FixtureFactory {SyntheticReviewRaster create();}
    enum Result {APPROVED,DENIED,MALFORMED}
    static final class Ticket {
        final SimulatedHandoff owner;final long generation;
        private Ticket(SimulatedHandoff owner,long generation){this.owner=owner;this.generation=generation;}
    }
    private final SyntheticReviewCoordinator.Clock clock;
    private final FixtureFactory factory;
    private State state=State.IDLE;
    private String status="IDLE_SIMULATION_ONLY";
    private long generation,hardDeadline,deadline;
    private boolean actualVisible,simVisible=true,departed,returned,resultSeen;
    private Ticket ticket;
    private SyntheticReviewCoordinator review;
    private SyntheticReviewCoordinator.Ticket imageTicket;
    private SyntheticReviewCoordinator.Approval approval;
    private int results,confirmations,frames,releases;
    SimulatedHandoff(SyntheticReviewCoordinator.Clock clock){this(clock,SyntheticReviewRaster::fixture);}
    SimulatedHandoff(SyntheticReviewCoordinator.Clock clock,FixtureFactory factory){
        if(clock==null||factory==null)throw new IllegalArgumentException();this.clock=clock;this.factory=factory;
    }
    synchronized void actualVisible(boolean value){actualVisible=value;if(!value)close("ACTUAL_LIFECYCLE_REVOKED");}
    synchronized State state(){expire();return state;}
    synchronized String status(){expire();return status;}
    // -1 means an inert local confirmation with no deadline, not an expired approval.
    synchronized long remaining(){expire();return state==State.CONFIRM||state==State.GENERATING?-1:active()&&state!=State.IDLE?Math.max(0,deadline-clock.now()):0;}
    synchronized long hardDeadline(){return hardDeadline;}
    synchronized int results(){return results;}
    synchronized int confirmations(){return confirmations;}
    synchronized int frames(){return frames;}
    synchronized int releases(){return releases;}
    private boolean active(){return actualVisible&&state!=State.CLOSED&&state!=State.DONE;}
    private boolean current(Ticket t){return active()&&t!=null&&t==ticket&&t.owner==this&&t.generation==generation;}
    private void expire(){
        if(active()&&state!=State.IDLE&&state!=State.CONFIRM&&state!=State.GENERATING&&clock.now()>=deadline)close("TIMEOUT_REVOKED");
    }
    synchronized Ticket begin(){
        expire();if(!active()||state!=State.IDLE)return null;
        ticket=new Ticket(this,++generation);hardDeadline=Math.addExact(clock.now(),20000);deadline=hardDeadline;
        state=State.PENDING;status="SIMULATED_CONSENT_PENDING_NO_PIXELS";return ticket;
    }
    synchronized boolean simulatedLoss(String label){
        expire();if(!active())return false;
        if(!returned&&(state==State.PENDING||state==State.HELD)){
            simVisible=false;departed=true;status="SIMULATED_LOSS_CAUSE_UNKNOWN_NO_PIXELS";return true;
        }
        close("SIMULATED_POST_RETURN_LOSS_REVOKED");return false;
    }
    synchronized boolean simulatedReturn(){
        expire();if(!active()||returned||!(state==State.PENDING||state==State.HELD)||(!departed&&!resultSeen))return false;
        simVisible=true;firstReturn();return true;
    }
    private void firstReturn(){
        returned=true;deadline=Math.min(hardDeadline,Math.addExact(clock.now(),5000));
        if(resultSeen)enterConfirmation();
        else{state=State.RETURNED;status="RETURNED_WAITING_SIMULATED_RESULT";}
    }
    private void enterConfirmation(){
        state=State.CONFIRM;deadline=0;status="FRESH_LOCAL_CONFIRMATION_REQUIRED_NO_DEADLINE";
    }
    synchronized boolean result(Ticket t,Result outcome){
        expire();if(!current(t)||resultSeen||!(state==State.PENDING||state==State.RETURNED))return false;
        if(outcome!=Result.APPROVED){close(outcome==Result.DENIED?"SIMULATED_DENIAL_REVOKED":"SIMULATED_MALFORMED_REVOKED");return false;}
        resultSeen=true;results++;
        if(returned)enterConfirmation();
        else if(simVisible)firstReturn();
        else{state=State.HELD;deadline=Math.min(deadline,Math.addExact(clock.now(),5000));status="SIMULATED_RESULT_HELD_NO_PIXELS";}
        return true;
    }
    boolean confirm(Ticket t){
        synchronized(this){
            expire();if(!current(t)||state!=State.CONFIRM||!returned||!resultSeen||!simVisible)return false;
            confirmations++;state=State.GENERATING;status="GENERATING_ONE_SYNTHETIC_FRAME";
        }
        SyntheticReviewRaster frame;
        try{frame=factory.create();}
        catch(RuntimeException error){synchronized(this){if(current(t)&&state==State.GENERATING)close("GENERATED_FIXTURE_FAILED");}return false;}
        finally{synchronized(this){releases++;}} // Completed local fixture job, not an OS resource.
        synchronized(this){
            if(!current(t)||state!=State.GENERATING||!simVisible)return false;
            review=new SyntheticReviewCoordinator(clock);review.foreground(true);review.focused(true);
            imageTicket=review.requestFixture();
            if(!review.approveFixture(imageTicket,true)||!review.acceptSyntheticFrame(imageTicket,frame)){
                close("GENERATED_FIXTURE_REJECTED");return false;
            }
            frames++;deadline=Math.addExact(clock.now(),60000);state=State.PREVIEW;
            status="GENERATED_PREVIEW_NO_CAPTURE_NO_TRANSMISSION";return true;
        }
    }
    synchronized SyntheticReviewCoordinator.Preview preview(){expire();return active()&&review!=null?review.preview():null;}
    synchronized boolean redact(Ticket t){
        expire();if(!current(t)||review==null||!(state==State.PREVIEW||state==State.REVIEW))return false;
        SyntheticReviewCoordinator.Preview p=review.preview();
        if(p==null||!review.redact(imageTicket,p.width/4,p.height/4,Math.max(1,p.width/2),Math.max(1,p.height/2)))return false;
        approval=null;state=State.PREVIEW;status="EDIT_INVALIDATED_FINAL_APPROVAL";return true;
    }
    synchronized boolean requestReview(Ticket t){
        expire();if(!current(t)||state!=State.PREVIEW||review==null)return false;
        approval=review.requestLocalApproval(imageTicket);if(approval==null)return false;
        state=State.REVIEW;status="APPROVE_EXACT_GENERATED_PREVIEW_ONCE";return true;
    }
    synchronized SyntheticReviewCoordinator.Receipt approve(Ticket t,long revision,String hash){
        expire();if(!current(t)||state!=State.REVIEW||review==null)return null;
        SyntheticReviewCoordinator.Preview p=review.preview();
        if(p==null||p.revision!=revision||!p.sha256.equals(hash))return null;
        SyntheticReviewCoordinator.Receipt r=review.approvePreview(approval,true);
        if(r!=null){ticket=null;approval=null;generation++;state=State.DONE;status="LOCAL_RECEIPT_ONLY_NOTHING_TRANSMITTED";}
        return r;
    }
    synchronized void close(String reason){
        if(state==State.CLOSED)return;
        generation++;ticket=null;approval=null;imageTicket=null;
        if(review!=null)review.close(reason);review=null;
        state=State.CLOSED;status=reason;
    }
}
