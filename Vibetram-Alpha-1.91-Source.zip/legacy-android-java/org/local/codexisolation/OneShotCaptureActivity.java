// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.media.projection.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.util.concurrent.atomic.AtomicInteger;

/** Explicit one-shot local preview. Never registers model tools or saves/transmits image data. */
public final class OneShotCaptureActivity extends Activity {
 private static final AtomicInteger REQUESTS=new AtomicInteger(17900);
 private final Handler main=new Handler(Looper.getMainLooper());
 private OneShotSession session;private OneShotSession.Ticket ticket;private int requestCode;private boolean resultDelivered,resumed,destroyed;
 private TextView status;private ImageView image;private Bitmap bitmap;private String shownHash;
 private String processingSummary;
 private Button fresh,request,confirm,stop,end,discard;
 private Button crop,redact,reviewExact,approveExact,rejectExact;
 private LinearLayout approvalControls;
 private LocalCapturedReview review;private LocalCapturedReview.Approval localApproval;
 private long displayedRevision=-1;private String localReceipt="";
 private final Runnable tick=new Runnable(){public void run(){
  if(destroyed)return;updateLifecycle();if(resumed)render();else session.state();
  if(resumed||session.handoff())main.postDelayed(this,200);
 }};
 @Override public void onCreate(Bundle saved){
  super.onCreate(saved);session=new OneShotSession(SystemClock::elapsedRealtime);
  LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
  root.setOnApplyWindowInsetsListener((v,insets)->{
   if(Build.VERSION.SDK_INT>=30){Insets b=insets.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout());v.setPadding(b.left,b.top,b.right,b.bottom);}
   else v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());return insets;
  });
  TextView title=new TextView(this);title.setText("1.82 LOCAL CROP/REDACTION SOURCE CANDIDATE. Android 14+. No saving, upload or model request. "
   +"This first test explicitly requests ENTIRE DEFAULT DISPLAY capture while this screen remains full-screen and focused. Visible other-app pixels, system UI and overlays may be included. "
   +"Full-display scope requires your Android consent. App-window capture and split-screen are unsupported here: cancel an unexpected chooser instead of accepting another source. No silent substitution or fallback. "
   +"Android consent may temporarily take focus (20s, result/return 5s); unrelated focus loss can occur in that window. No capture until you return and explicitly confirm. "
   +"After return all focus loss revokes. Confirmation has no timer while focused; stale OS consent may still be rejected. One frame only, projection stopped before preview. "
   +"Max 640-pixel edge, 32KiB PNG. On overflow only, the same frame may reduce to 480/360/240 edge (at most four encodes); no recapture. Reduced previews may lose readable text. Blank/invalid or still-oversized acquisition rejects. Preview clears after 60s or exit. Up to eight explicit crop/redaction attempts; edits never extend expiry. Review exact final image for a local-only hash receipt. Any edit invalidates earlier approval. No automatic redaction, undo store or transmission.");root.addView(title);
  stop=button(root,"STOP LOCAL CAPTURE");end=button(root,"END LOCAL CAPTURE SESSION");
  ScrollView scroll=new ScrollView(this);LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);scroll.addView(body);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
  fresh=button(body,"NEW LOCAL CAPTURE SESSION");request=button(body,"REQUEST ANDROID CONSENT FOR ONE LOCAL FRAME");
  confirm=button(body,"ARE YOU SURE? CAPTURE ONE LOCAL FRAME");
  TextView fixture=new TextView(this);fixture.setText("LOCAL TEST FIXTURE\nBLUE  RED  GREEN\nOnly this test screen is supported in the first build.");fixture.setTextColor(Color.BLUE);fixture.setBackgroundColor(Color.WHITE);fixture.setTextSize(24);body.addView(fixture);
  status=new TextView(this);status.setSaveEnabled(false);body.addView(status);
  image=new ImageView(this);image.setAdjustViewBounds(true);image.setScaleType(ImageView.ScaleType.FIT_CENTER);image.setSaveEnabled(false);
  image.setContentDescription("Ephemeral local screenshot preview; never saved or transmitted");body.addView(image,new LinearLayout.LayoutParams(-1,(int)(240*getResources().getDisplayMetrics().density)));
  discard=button(body,"DISCARD LOCAL PREVIEW");setContentView(root);root.requestApplyInsets();
  crop=button(body,"CROP TO CENTRAL REGION");redact=button(body,"REDACT CENTRAL RECTANGLE (OPAQUE)");
  reviewExact=button(body,"REVIEW EXACT IMAGE FOR LOCAL APPROVAL");approvalControls=new LinearLayout(this);approvalControls.setOrientation(LinearLayout.VERTICAL);body.addView(approvalControls);bindApprovalControls(null,null);
  crop.setOnClickListener(v->editLocal(true));redact.setOnClickListener(v->editLocal(false));
  reviewExact.setOnClickListener(v->{updateLifecycle();if(review!=null){localApproval=review.requestApproval(displayedRevision,shownHash);bindApprovalControls(review,localApproval);}render();});
  fresh.setOnClickListener(v->{if(!allowsCaptureNow())return;clearReview("REPLACED");session.close("REPLACED");session=new OneShotSession(SystemClock::elapsedRealtime);ticket=null;requestCode=0;resultDelivered=false;processingSummary=null;localReceipt="";clearImage();getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);updateLifecycle();render();});
  request.setOnClickListener(v->{
   updateLifecycle();if(Build.VERSION.SDK_INT<34||!allowsCaptureNow())return;
   OneShotSession.Ticket t=session.begin();if(t==null)return;ticket=t;resultDelivered=false;
   requestCode=REQUESTS.incrementAndGet();if(requestCode>65000){session.close("REQUEST_ID_EXHAUSTED");render();return;}
   try{Intent consent=getSystemService(MediaProjectionManager.class).createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay());
    startActivityForResult(consent,requestCode);
   }catch(RuntimeException error){session.close("CONSENT_UI_UNAVAILABLE");}render();
  });
  confirm.setOnClickListener(v->{
   updateLifecycle();if(!allowsCaptureNow())return;OneShotSession.Lease lease=session.confirm(ticket);
   if(lease!=null&&!OneShotProjectionService.launch(this,session,lease))session.close("CAPTURE_START_BUSY_OR_REJECTED");render();
  });
  stop.setOnClickListener(v->{session.close("STOPPED");render();});end.setOnClickListener(v->{session.close("END_SESSION");render();});
  discard.setOnClickListener(v->{session.close("PREVIEW_DISCARDED");render();});render();
 }
 private Button button(LinearLayout parent,String name){Button b=new Button(this);b.setText(name);parent.addView(b);return b;}
 private boolean allowedScope(){
  if(Build.VERSION.SDK_INT<34||isInMultiWindowMode()||isInPictureInPictureMode())return false;
  android.view.Display d=getDisplay();KeyguardManager keyguard=getSystemService(KeyguardManager.class);
  return d!=null&&d.getDisplayId()==android.view.Display.DEFAULT_DISPLAY&&keyguard!=null&&!keyguard.isKeyguardLocked();
 }
 boolean allowsCaptureNow(){return !destroyed&&resumed&&hasWindowFocus()&&allowedScope()&&getWindow().getDecorView().getWindowVisibility()==View.VISIBLE;}
 private void updateLifecycle(){if(session!=null){session.lifecycle(resumed,hasWindowFocus(),allowedScope());if(session.state()!=OneShotSession.State.PREVIEW)clearReview("LOCAL_REVIEW_REVOKED");}}
 private void clearReview(String code){if(review!=null)review.close(code);review=null;localApproval=null;displayedRevision=-1;}
 private void bindApprovalControls(LocalCapturedReview boundReview,LocalCapturedReview.Approval boundApproval){
  // New Views per approval: queued events on detached old controls retain their old token.
  approvalControls.removeAllViews();approveExact=button(approvalControls,"APPROVE EXACT IMAGE LOCALLY ONCE");rejectExact=button(approvalControls,"REJECT LOCAL IMAGE APPROVAL");
  approveExact.setOnClickListener(v->finishApproval(boundReview,boundApproval,true));rejectExact.setOnClickListener(v->finishApproval(boundReview,boundApproval,false));
 }
 private void finishApproval(LocalCapturedReview boundReview,LocalCapturedReview.Approval boundApproval,boolean allow){
  if(boundReview==null||boundReview!=review||boundApproval==null||boundApproval!=localApproval)return;
  updateLifecycle();if(boundReview!=review)return;
  LocalCapturedReview.Receipt receipt=boundReview.approve(boundApproval,allow);
  if(receipt!=null)localReceipt="LOCAL RECEIPT ONLY: revision="+receipt.revision+", "+receipt.width+"x"+receipt.height+", bytes="+receipt.bytes+", SHA256="+receipt.hash+". NOTHING TRANSMITTED.";
  localApproval=null;render();
 }
 private void editLocal(boolean cropping){
  updateLifecycle();if(review==null)return;CapturedPng p=review.preview();if(p==null)return;
  localApproval=null;review.edit(cropping,p.width/4,p.height/4,Math.max(1,p.width/2),Math.max(1,p.height/2));render();
 }
 private void startReview(OneShotSession owner,CapturedPng frame){
  int[] argb=new int[frame.width*frame.height];bitmap.getPixels(argb,0,frame.width,0,0,frame.width,frame.height);
  review=new LocalCapturedReview(frame,argb,new LocalCapturedReview.Owner(){
   public boolean live(){return owner==session&&allowsCaptureNow()&&owner.state()==OneShotSession.State.PREVIEW;}
   public boolean replace(CapturedPng expected,CapturedPng next){if(!live())return false;return owner.replaceLocalPreview(expected,next);}
   public boolean finish(CapturedPng expected){if(!live())return false;return owner.finishLocalReview(expected);}
   public void revoke(String code){owner.close(code);}
  });
 }
 @Override protected void onActivityResult(int code,int result,Intent data){
  super.onActivityResult(code,result,data);
  if(destroyed||code!=requestCode||ticket==null||resultDelivered)return;
  resultDelivered=true;updateLifecycle();session.result(ticket,result==RESULT_OK?data:null);render();
 }
 void deliver(OneShotSession owner,OneShotSession.Lease lease,SameFramePng.Result frame){
  if(destroyed||owner!=session||!allowsCaptureNow()){owner.close("DELIVERY_LIFECYCLE_REVOKED");return;}
  updateLifecycle();if(owner.adopt(lease,frame.image))processingSummary="Input="+frame.inputWidth+"x"+frame.inputHeight+", output="+frame.image.width+"x"+frame.image.height+", encode attempts="+frame.attempts
   +"\n"+(frame.reduced()?"REDUCED RESOLUTION; fine text may be unreadable.":"Original acquired dimensions retained.");render();
 }
 void reportExhausted(OneShotSession owner,SameFramePng.Exhausted detail){
  if(destroyed||owner!=session||owner.state()!=OneShotSession.State.CLOSED||!"LOCAL_PNG_LADDER_EXHAUSTED_REJECTED".equals(owner.status()))return;
  processingSummary="Input="+detail.inputWidth+"x"+detail.inputHeight+", output=none, last attempted="+detail.lastWidth+"x"+detail.lastHeight+", encode attempts="+detail.attempts;render();
 }
 void refreshFromAdapter(OneShotSession owner){if(!destroyed&&owner==session)render();}
 private void clearImage(){if(image!=null)image.setImageDrawable(null);if(bitmap!=null){bitmap.recycle();bitmap=null;}shownHash=null;}
 private void render(){
  if(status==null)return;OneShotSession.State state=session.state();CapturedPng frame=session.preview();
  if(frame==null){clearReview("LOCAL_REVIEW_REVOKED");clearImage();}else if(!frame.sha256.equals(shownHash)){
   getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);clearImage();byte[] bytes=frame.bytes();bitmap=BitmapFactory.decodeByteArray(bytes,0,bytes.length);
   if(bitmap==null||bitmap.getWidth()!=frame.width||bitmap.getHeight()!=frame.height){session.close("PREVIEW_DECODE_FAILED");clearImage();frame=null;}
   else{image.setImageBitmap(bitmap);shownHash=frame.sha256;}
  }
  if(frame!=null&&review==null)try{startReview(session,frame);}catch(RuntimeException rejected){session.close("LOCAL_REVIEW_INPUT_REJECTED");clearReview("LOCAL_REVIEW_INPUT_REJECTED");clearImage();frame=null;}
  if(frame!=null&&review!=null)displayedRevision=review.revision();
  state=session.state();if(state==OneShotSession.State.CLOSED){clearImage();frame=null;}
  boolean allowed=allowsCaptureNow();fresh.setEnabled(allowed);request.setEnabled(allowed&&state==OneShotSession.State.IDLE);
  confirm.setEnabled(allowed&&state==OneShotSession.State.CONFIRM);stop.setEnabled(resumed&&state!=OneShotSession.State.CLOSED);end.setEnabled(stop.isEnabled());discard.setEnabled(allowed&&state==OneShotSession.State.PREVIEW);
  int editsRemaining=review==null?0:review.remainingEdits();String reviewStatus=review==null?"":review.status();
  boolean editable=allowed&&frame!=null&&review!=null&&editsRemaining>0;
  crop.setEnabled(editable&&frame.width>=2&&frame.height>=2);redact.setEnabled(editable);
  reviewExact.setEnabled(allowed&&frame!=null&&review!=null);approveExact.setEnabled(allowed&&review!=null&&review.pending(localApproval));rejectExact.setEnabled(approveExact.isEnabled());
  long left=session.remaining();state=session.state();if(state==OneShotSession.State.CLOSED){clearReview("LOCAL_REVIEW_REVOKED");clearImage();frame=null;crop.setEnabled(false);redact.setEnabled(false);reviewExact.setEnabled(false);approveExact.setEnabled(false);rejectExact.setEnabled(false);discard.setEnabled(false);stop.setEnabled(false);end.setEnabled(false);confirm.setEnabled(false);}
  status.setText("State: "+state+" / "+session.status()+"\n"+(left<0?"Are you sure? No local confirmation timer; no capture has started.":"Active-stage deadline: "+left+" ms")
   +"\nConsent results="+session.accepted()+", handle consumptions="+session.starts()+", retained frames="+session.frames()
   +"\nAdapter bound="+session.resourceBound()+", cleanup reported="+session.cleanupReported()+", cleanup OK="+session.cleanupOk()
   +"\n"+(processingSummary==null?"":"Acquired frame processing: "+processingSummary+"\n")
   +(frame==null?"No retained preview.":"LOCAL ONLY current image "+frame.width+"x"+frame.height+", "+frame.size()+" bytes\nSHA256="+frame.sha256+"\nReview revision="+displayedRevision+", remaining edit attempts="+editsRemaining+"\n"+reviewStatus)+"\n"+localReceipt);
 }
 @Override protected void onResume(){super.onResume();resumed=true;updateLifecycle();main.removeCallbacks(tick);main.post(tick);}
 @Override public void onWindowFocusChanged(boolean f){super.onWindowFocusChanged(f);if(session!=null){updateLifecycle();render();}}
 @Override protected void onPause(){resumed=false;updateLifecycle();clearImage();super.onPause();}
 @Override protected void onStop(){resumed=false;updateLifecycle();clearImage();super.onStop();}
 @Override protected void onDestroy(){destroyed=true;main.removeCallbacks(tick);session.close("OWNER_DESTROYED");clearImage();super.onDestroy();}
}
