// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

/** One fixed Responses SSE stream, served only from 127.0.0.1. */
final class LoopbackStreamingServer implements AutoCloseable {
    static final String EXPECTED_TEXT="Local café.";
    private final ServerSocket listener;
    private final Thread worker;
    private final boolean stallAfterFirstDelta;
    private volatile int requests;
    private volatile boolean utf8SplitWritten;
    private volatile String failure;
    LoopbackStreamingServer(boolean stallAfterFirstDelta) throws Exception {
        this.stallAfterFirstDelta=stallAfterFirstDelta;
        listener=new ServerSocket(0,1,InetAddress.getByName("127.0.0.1"));
        listener.setSoTimeout(30000);
        worker=new Thread(this::serve,"coretest-loopback-streaming");
        worker.setDaemon(true);worker.start();
    }
    int port(){return listener.getLocalPort();}
    int requests(){return requests;}
    boolean utf8SplitWritten(){return utf8SplitWritten;}
    String failure(){return failure;}
    private static String event(String type,String json){return "event: "+type+"\ndata: "+json+"\n\n";}
    private static void chunk(OutputStream out,byte[] data,int offset,int length) throws Exception {
        out.write((Integer.toHexString(length)+"\r\n").getBytes(StandardCharsets.US_ASCII));
        out.write(data,offset,length);out.write("\r\n".getBytes(StandardCharsets.US_ASCII));out.flush();
    }
    private static void chunk(OutputStream out,String text) throws Exception {
        byte[] data=text.getBytes(StandardCharsets.UTF_8);chunk(out,data,0,data.length);
    }
    private void serve(){
        try(Socket client=listener.accept()){
            client.setSoTimeout(10000);
            if(!client.getInetAddress().isLoopbackAddress())throw new IllegalStateException("NON_LOOPBACK_CLIENT");
            InputStream in=client.getInputStream();OutputStream out=client.getOutputStream();
            ByteArrayOutputStream header=new ByteArrayOutputStream();
            while(header.size()<8192){
                int b=in.read();if(b<0)throw new IllegalStateException("EARLY_EOF");header.write(b);
                byte[] bytes=header.toByteArray();int n=bytes.length;
                if(n>=4&&bytes[n-4]=='\r'&&bytes[n-3]=='\n'&&bytes[n-2]=='\r'&&bytes[n-1]=='\n')break;
            }
            String headers=new String(header.toByteArray(),StandardCharsets.US_ASCII);
            if(!headers.startsWith("POST /v1/responses "))throw new IllegalStateException("UNEXPECTED_PATH");
            int length=-1;
            for(String line:headers.split("\r\n")){
                if(line.toLowerCase(java.util.Locale.ROOT).startsWith("content-length:"))
                    length=Integer.parseInt(line.substring(line.indexOf(':')+1).trim());
                if(line.toLowerCase(java.util.Locale.ROOT).startsWith("authorization:")&&
                        !line.equals("Authorization: Bearer sk-coretest-local-only"))
                    throw new IllegalStateException("UNEXPECTED_AUTH_HEADER");
            }
            if(length<0||length>1024*1024)throw new IllegalStateException("BODY_SIZE_INVALID");
            byte[] body=new byte[length];int got=0;
            while(got<length){int n=in.read(body,got,length-got);if(n<0)throw new IllegalStateException("BODY_EOF");got+=n;}
            String request=new String(body,StandardCharsets.UTF_8);
            if(!request.contains("offline synthetic ping"))throw new IllegalStateException("PROMPT_MISSING");
            requests++;
            out.write(("HTTP/1.1 200 OK\r\nContent-Type: text/event-stream\r\n"
                    +"Cache-Control: no-cache\r\nTransfer-Encoding: chunked\r\nConnection: close\r\n\r\n")
                    .getBytes(StandardCharsets.US_ASCII));out.flush();
            chunk(out,event("response.created","{\"type\":\"response.created\",\"response\":{\"id\":\"resp-local-stream-1\"}}"));
            chunk(out,event("response.output_item.added","{\"type\":\"response.output_item.added\",\"item\":{\"type\":\"message\",\"role\":\"assistant\",\"id\":\"msg-local-stream-1\",\"content\":[{\"type\":\"output_text\",\"text\":\"\"}]}}"));
            chunk(out,event("response.output_text.delta","{\"type\":\"response.output_text.delta\",\"delta\":\"Local \"}"));
            if(stallAfterFirstDelta){Thread.sleep(30000);return;}
            byte[] second=event("response.output_text.delta","{\"type\":\"response.output_text.delta\",\"delta\":\"café.\"}")
                    .getBytes(StandardCharsets.UTF_8);
            int split=-1;
            for(int i=0;i+1<second.length;i++)if((second[i]&255)==0xc3&&(second[i+1]&255)==0xa9){split=i+1;break;}
            if(split<0)throw new IllegalStateException("UTF8_SPLIT_POINT_MISSING");
            chunk(out,second,0,split);Thread.sleep(40);chunk(out,second,split,second.length-split);
            utf8SplitWritten=true;
            chunk(out,event("response.output_item.done","{\"type\":\"response.output_item.done\",\"item\":{\"type\":\"message\",\"role\":\"assistant\",\"id\":\"msg-local-stream-1\",\"content\":[{\"type\":\"output_text\",\"text\":\"Local café.\"}]}}"));
            chunk(out,event("response.completed","{\"type\":\"response.completed\",\"response\":{\"id\":\"resp-local-stream-1\",\"usage\":{\"input_tokens\":0,\"input_tokens_details\":null,\"output_tokens\":0,\"output_tokens_details\":null,\"total_tokens\":0}}}"));
            out.write("0\r\n\r\n".getBytes(StandardCharsets.US_ASCII));out.flush();
        }catch(Exception e){if(!listener.isClosed())failure=e.getClass().getSimpleName()+":"+e.getMessage();}
        finally{try{listener.close();}catch(Exception ignored){}}
    }
    @Override public void close() throws Exception{
        listener.close();worker.interrupt();worker.join(2000);
        if(worker.isAlive())throw new IllegalStateException("LOOPBACK_WORKER_STILL_RUNNING");
    }
}
