// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

import android.app.Activity;
import android.os.Handler;
import android.os.Looper;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import javax.net.ssl.HttpsURLConnection;

/** Inactive until a separately approved owner/device pairing supplies credentials. */
final class RemotePhonePoller {
    private static final Handler MAIN=new Handler(Looper.getMainLooper());
    private final URL base;
    private final String ownerId,deviceId,deviceToken;
    private final RemotePhoneSession session;
    private final RemoteApprovalPrompt prompt;
    private final Runnable onEnded;
    private volatile boolean running;
    private volatile HttpsURLConnection current;
    RemotePhonePoller(Activity screen,String httpsOrigin,String ownerId,String deviceId,
            String deviceToken,SelectedFolderAccess folder,Runnable onEnded) throws Exception {
        URL url=RemotePhoneEnrollment.origin(httpsOrigin);
        if(deviceId==null||!deviceId.matches("[A-Za-z0-9_-]{1,64}")||deviceToken==null
                ||!deviceToken.matches("[A-Za-z0-9._~-]{32,256}"))throw new IllegalArgumentException("PAIRING_INVALID");
        this.base=url;this.ownerId=ownerId;this.deviceId=deviceId;this.deviceToken=deviceToken;
        session=new RemotePhoneSession(ownerId,folder);prompt=new RemoteApprovalPrompt(screen);this.onEnded=onEnded;
    }
    boolean isRunning(){return running;}
    void start(){
        if(running)throw new IllegalStateException("ALREADY_RUNNING");
        running=true;Thread worker=new Thread(this::run,"remote-folder-https");worker.setDaemon(true);worker.start();
    }
    void stop(){
        running=false;session.disconnect();prompt.stop();
        HttpsURLConnection connection=current;if(connection!=null)connection.disconnect();
    }
    private void run(){
        try{
            while(running){
                Map<?,?> poll=post("/phone/poll",new JSONObject().put("ownerId",ownerId).put("deviceId",deviceId));
                Object item=poll.get("request");
                if(item instanceof Map){
                    Map<?,?> request=(Map<?,?>)item;
                    RemotePhoneSession.Request work=new RemotePhoneSession.Request(
                            field(request,"id"),field(request,"ownerId"),field(request,"operation"),
                            field(request,"name"),number(request.get("expiresAt")));
                    RemotePhoneSession.Result result=session.handle(work,prompt,System.currentTimeMillis());
                    if(!running)break;
                    post("/phone/complete",new JSONObject().put("ownerId",ownerId).put("deviceId",deviceId)
                            .put("id",result.id).put("decision",result.decision).put("text",result.text));
                }else if(item!=null)throw new IllegalStateException("POLL_INVALID");
                Thread.sleep(1500);
            }
        }catch(Exception ignored){/* Network loss stops this process-memory bridge. */}
        finally{
            running=false;session.disconnect();prompt.stop();
            try{post("/phone/disconnect",new JSONObject().put("ownerId",ownerId).put("deviceId",deviceId));}
            catch(Exception ignored){/* Owner-side revocation is needed if HTTPS is unavailable. */}
            if(onEnded!=null)MAIN.post(onEnded);
        }
    }
    private static String field(Map<?,?> value,String key){
        Object item=value.get(key);if(!(item instanceof String))throw new IllegalArgumentException("POLL_INVALID");
        return (String)item;
    }
    private static long number(Object value){
        if(!(value instanceof BigDecimal))throw new IllegalArgumentException("POLL_INVALID");
        return ((BigDecimal)value).longValueExact();
    }
    private Map<?,?> post(String path,JSONObject body) throws Exception {
        HttpsURLConnection connection=(HttpsURLConnection)new URL(base,path).openConnection();current=connection;
        try{
            connection.setInstanceFollowRedirects(false);
            connection.setRequestMethod("POST");connection.setDoOutput(true);
            connection.setConnectTimeout(5000);connection.setReadTimeout(5000);
            connection.setRequestProperty("Authorization","Bearer "+deviceToken);
            connection.setRequestProperty("Content-Type","application/json");
            byte[] bytes=body.toString().getBytes(StandardCharsets.UTF_8);
            if(bytes.length>32768)throw new IllegalArgumentException("REQUEST_TOO_LARGE");
            try(OutputStream out=connection.getOutputStream()){out.write(bytes);}
            if(connection.getResponseCode()!=200)throw new IllegalStateException("REMOTE_UNAVAILABLE");
            ByteArrayOutputStream buffer=new ByteArrayOutputStream();byte[] chunk=new byte[1024];
            try(InputStream in=connection.getInputStream()){
                int count;while((count=in.read(chunk))!=-1){
                    if(buffer.size()+count>16384)throw new IllegalStateException("REPLY_TOO_LARGE");
                    buffer.write(chunk,0,count);
                }
            }
            Object parsed=BoundedJson.parse(buffer.toByteArray());
            if(!(parsed instanceof Map))throw new IllegalStateException("REPLY_INVALID");
            return (Map<?,?>)parsed;
        }finally{current=null;connection.disconnect();}
    }
}
