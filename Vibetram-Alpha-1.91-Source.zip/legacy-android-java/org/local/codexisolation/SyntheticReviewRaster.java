// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.zip.CRC32;
import java.util.zip.DeflaterOutputStream;

/** Generated RGB pixels only: no file, URI, screen, camera, or external byte decoder. */
final class SyntheticReviewRaster {
    static final int MAX_EDGE=1024,MAX_PIXELS=1024*1024;
    final int width,height;
    private final int[] pixels;
    private SyntheticReviewRaster(int width,int height,int[] pixels){
        bounds(width,height);this.width=width;this.height=height;this.pixels=pixels;
    }
    private static void bounds(int width,int height){
        if(width<1||height<1||width>MAX_EDGE||height>MAX_EDGE||(long)width*height>MAX_PIXELS)
            throw new IllegalArgumentException("SYNTHETIC_PIXEL_LIMIT");
    }
    static SyntheticReviewRaster fixture(){return generatedFixture(240,160,false);}
    /** Deterministic generated test data, including an incompressible rejection fixture. */
    static SyntheticReviewRaster generatedFixture(int width,int height,boolean noise){
        bounds(width,height);int[] pixels=new int[width*height];int random=0x13579bdf;
        for(int y=0;y<height;y++)for(int x=0;x<width;x++){
            int color=0xf8f8f8;
            if(noise){random^=random<<13;random^=random>>>17;random^=random<<5;color=random&0xffffff;}
            else if(x>=80&&x<160&&y>=60&&y<120)color=0xd62828;
            else if(x>=16&&x<48&&y>=16&&y<48)color=0x2368d6;
            else if(x>=190&&x<220&&y>=110&&y<145)color=0x188c4a;
            pixels[y*width+x]=color;
        }
        return new SyntheticReviewRaster(width,height,pixels);
    }
    private void rectangle(int x,int y,int w,int h){
        if(x<0||y<0||w<1||h<1||(long)x+w>width||(long)y+h>height)
            throw new IllegalArgumentException("SYNTHETIC_RECT_INVALID");
    }
    SyntheticReviewRaster crop(int x,int y,int w,int h){
        rectangle(x,y,w,h);int[] cropped=new int[w*h];
        for(int row=0;row<h;row++)System.arraycopy(pixels,(y+row)*width+x,cropped,row*w,w);
        return new SyntheticReviewRaster(w,h,cropped);
    }
    SyntheticReviewRaster redact(int x,int y,int w,int h){
        rectangle(x,y,w,h);int[] redacted=pixels.clone();
        for(int row=y;row<y+h;row++)java.util.Arrays.fill(redacted,row*width+x,row*width+x+w,0);
        return new SyntheticReviewRaster(width,height,redacted);
    }
    byte[] png(){
        try{
            LimitedBuffer compressed=new LimitedBuffer(PngImageContent.MAX_PNG_BYTES-57);
            try(DeflaterOutputStream encoder=new DeflaterOutputStream(compressed)){
                byte[] row=new byte[1+width*3];
                for(int y=0;y<height;y++){
                    row[0]=0;
                    for(int x=0;x<width;x++){
                        int pixel=pixels[y*width+x],offset=1+x*3;
                        row[offset]=(byte)(pixel>>>16);row[offset+1]=(byte)(pixel>>>8);row[offset+2]=(byte)pixel;
                    }
                    encoder.write(row);
                }
            }
            ByteArrayOutputStream png=new ByteArrayOutputStream();
            png.write(new byte[]{(byte)137,80,78,71,13,10,26,10});
            ByteArrayOutputStream header=new ByteArrayOutputStream();
            number(header,width);number(header,height);header.write(new byte[]{8,2,0,0,0});
            chunk(png,"IHDR",header.toByteArray());chunk(png,"IDAT",compressed.toByteArray());chunk(png,"IEND",new byte[0]);
            byte[] bytes=png.toByteArray();PngImageContent.fromPng(bytes);return bytes;
        }catch(IOException error){throw new IllegalStateException("SYNTHETIC_ENCODING_FAILED",error);}
    }
    private static final class LimitedBuffer extends ByteArrayOutputStream {
        final int maximum;
        LimitedBuffer(int maximum){this.maximum=maximum;}
        @Override public synchronized void write(int value){
            if(count>=maximum)throw new IllegalArgumentException("SYNTHETIC_PNG_LIMIT");super.write(value);
        }
        @Override public synchronized void write(byte[] bytes,int offset,int length){
            if(length>maximum-count)throw new IllegalArgumentException("SYNTHETIC_PNG_LIMIT");super.write(bytes,offset,length);
        }
    }
    private static void chunk(ByteArrayOutputStream out,String name,byte[] data)throws IOException{
        byte[] type=name.getBytes(StandardCharsets.US_ASCII);number(out,data.length);out.write(type);out.write(data);
        CRC32 crc=new CRC32();crc.update(type);crc.update(data);number(out,(int)crc.getValue());
    }
    private static void number(ByteArrayOutputStream out,int value){
        out.write(value>>>24);out.write(value>>>16);out.write(value>>>8);out.write(value);
    }
}
