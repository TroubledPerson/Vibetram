// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

/** Host-testable button rules; all actions are still guarded by ManagedChatSession. */
final class ChatScreenRules {
    private ChatScreenRules(){}
    static boolean signIn(boolean hasAttempt,boolean settled){return !hasAttempt||settled;}
    static boolean send(boolean ready,boolean inFlight,boolean settled,int submitted){
        return ready&&!inFlight&&!settled&&submitted<ManagedChatSession.MAX_TURNS;
    }
    static boolean stop(boolean inFlight,boolean stopping,boolean settled){
        return inFlight&&!stopping&&!settled;
    }
    static boolean end(boolean hasAttempt,boolean settled){return hasAttempt&&!settled;}
    static boolean input(boolean inFlight){return !inFlight;}
}
