// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

/** Main-thread cleanup guard: callbacks/logging cannot recursively repeat teardown. */
final class ReleaseGuard {
    private boolean running;
    void run(Runnable cleanup) {
        if (running) return;
        running = true;
        try { cleanup.run(); }
        finally { running = false; }
    }
}
