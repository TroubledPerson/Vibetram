// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

/** Fresh-grant controller, separate from all synthetic/project tool authorization. */
final class OneShotSession {
 interface Clock{long now();}
 interface Resource{void requestStop();} // Nonblocking; never waits while holding this controller's monitor.
 enum State{IDLE,PENDING,HELD,RETURNED,CONFIRM,ACQUIRING,STOPPING,PREVIEW,CLOSED}
 static final class Ticket{final OneShotSession owner;final long epoch;private Ticket(OneShotSession o,long e){owner=o;epoch=e;}}
 static final class Lease{final Ticket ticket;private Lease(Ticket t){ticket=t;}}
 private final Clock clock;private State state=State.IDLE;private String status="IDLE_LOCAL_ONLY";
 private boolean resumed,focused,scope,departed,returned,seen,taken,stopped,cleanupReported;
 private long epoch,hard,deadline;private Ticket ticket;private Lease lease,boundLease;private Object grant;private Resource resource;
 private CapturedPng preview;private int accepted,starts,frames;
 OneShotSession(Clock clock){if(clock==null)throw new IllegalArgumentException();this.clock=clock;}
 synchronized State state(){expire();return state;}
 synchronized String status(){expire();return status;}
 synchronized int accepted(){return accepted;} synchronized int starts(){return starts;} synchronized int frames(){return frames;}
 synchronized boolean resourceBound(){return resource!=null;} synchronized boolean cleanupReported(){return cleanupReported;} synchronized boolean cleanupOk(){return stopped;}
 synchronized long remaining(){expire();return state==State.CONFIRM?-1:state==State.IDLE||state==State.CLOSED?0:Math.max(0,deadline-clock.now());}
 synchronized boolean handoff(){expire();return state==State.PENDING||state==State.HELD;}
 synchronized void lifecycle(boolean r,boolean f,boolean allowed){
  expire();resumed=r;focused=f;scope=allowed;
  if(state==State.CLOSED||state==State.IDLE)return;
  if(!scope){close("SCOPE_OR_LOCK_REVOKED");return;}
  if(!r||!f){if(!returned&&(state==State.PENDING||state==State.HELD)){departed=true;return;}close("LIFECYCLE_REVOKED");return;}
  if(!returned&&departed&&(state==State.PENDING||state==State.HELD))firstReturn();
 }
 synchronized Ticket begin(){expire();if(state!=State.IDLE||!visible())return null;ticket=new Ticket(this,++epoch);
  deadline=hard=Math.addExact(clock.now(),20000);state=State.PENDING;status="ANDROID_CONSENT_PENDING_NO_CAPTURE";return ticket;}
 synchronized boolean result(Ticket t,Object value){
  expire();if(!current(t)||seen||!(state==State.PENDING||state==State.RETURNED))return false;
  if(value==null){close("CONSENT_DENIED_OR_MALFORMED");return false;}
  grant=value;seen=true;accepted++;
  if(returned)confirmation();else if(visible())firstReturn();else{state=State.HELD;deadline=Math.min(hard,clock.now()+5000);status="RESULT_HELD_NO_CAPTURE";}return true;
 }
 private void firstReturn(){returned=true;if(seen)confirmation();else{state=State.RETURNED;deadline=Math.min(hard,clock.now()+5000);status="FOCUSED_WAITING_CONSENT_RESULT";}}
 private void confirmation(){state=State.CONFIRM;deadline=0;status="EXPLICIT_ONE_FRAME_CONFIRMATION_REQUIRED_NO_TIMEOUT";}
 synchronized Lease confirm(Ticket t){expire();if(!current(t)||state!=State.CONFIRM||!visible()||!returned||grant==null)return null;
  lease=new Lease(t);state=State.ACQUIRING;deadline=clock.now()+10000;status="ONE_FRAME_ACQUISITION_STARTING";return lease;}
 synchronized boolean live(Lease l){expire();return l!=null&&l==lease&&current(l.ticket)&&visible()&&(state==State.ACQUIRING||state==State.STOPPING);}
 synchronized boolean bind(Lease l,Resource r){if(r==null)return false;if(!live(l)||resource!=null){r.requestStop();return false;}resource=r;boundLease=l;return true;}
 synchronized Object takeGrant(Lease l){if(!live(l)||state!=State.ACQUIRING||taken||resource==null)return null;taken=true;Object value=grant;grant=null;starts++;return value;}
 synchronized boolean stopping(Lease l){if(!live(l)||state!=State.ACQUIRING||!taken)return false;state=State.STOPPING;status="STOPPING_PROJECTION_BEFORE_PREVIEW";return true;}
 synchronized void resourcesStopped(Lease l,Resource r,boolean clean){
  if(resource!=r||boundLease!=l)return;resource=null;boundLease=null;stopped=clean;cleanupReported=true;if(!clean)close("RESOURCE_CLEANUP_FAILED");
 }
 synchronized boolean adopt(Lease l,CapturedPng image){
  if(!live(l)||state!=State.STOPPING||!stopped||resource!=null||image==null)return false;
  preview=image;lease=null;ticket=null;grant=null;epoch++;frames++;state=State.PREVIEW;deadline=clock.now()+60000;status="LOCAL_PREVIEW_PROJECTION_STOPPED_NOT_SAVED";return true;
 }
 synchronized CapturedPng preview(){expire();return state==State.PREVIEW?preview:null;}
 synchronized boolean replaceLocalPreview(CapturedPng expected,CapturedPng replacement){
  expire();if(state!=State.PREVIEW||!visible()||preview!=expected||replacement==null)return false;
  preview=replacement;return true; // Same capture, same absolute preview deadline, no frame/grant increment.
 }
 synchronized boolean finishLocalReview(CapturedPng expected){
  expire();if(state!=State.PREVIEW||!visible()||preview!=expected)return false;
  close("LOCAL_IMAGE_APPROVED_NOT_TRANSMITTED");return true;
 }
 synchronized void close(String reason){
  if(state==State.CLOSED)return;state=State.CLOSED;status=reason;epoch++;ticket=null;lease=null;grant=null;preview=null;
  Resource old=resource;if(old!=null)old.requestStop();
 }
 private boolean visible(){return resumed&&focused&&scope;}
 private boolean current(Ticket t){return state!=State.CLOSED&&t!=null&&t==ticket&&t.owner==this&&t.epoch==epoch;}
 private void expire(){if(state!=State.IDLE&&state!=State.CONFIRM&&state!=State.CLOSED&&clock.now()>=deadline)close("TIMEOUT_REVOKED");}
}
