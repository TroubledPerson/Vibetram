// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Parcel;
import android.os.RemoteException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

/** Separate isolated worker for the offline-only Java boundary fixture. */
public final class OfflineFixtureService extends Service {
    static final String DESCRIPTOR="org.local.codexisolation.offline-fixture.v1";
    static final int RUN=IBinder.FIRST_CALL_TRANSACTION;
    private final AtomicBoolean started=new AtomicBoolean();
    private final Handler main=new Handler(Looper.getMainLooper());
    private final Runnable terminate=()->android.os.Process.killProcess(android.os.Process.myPid());
    private final Binder endpoint=new Binder() {
        @Override protected boolean onTransact(int code,Parcel in,Parcel out,int flags) throws RemoteException {
            if(code==INTERFACE_TRANSACTION){out.writeString(DESCRIPTOR);return true;}
            if(code!=RUN)return super.onTransact(code,in,out,flags);
            if(out==null || (flags&IBinder.FLAG_ONEWAY)!=0 || in.dataSize()>OfflineFixtureProtocol.MAX_PARCEL)
                throw new SecurityException("Offline fixture parcel");
            in.enforceInterface(DESCRIPTOR);
            if(!android.os.Process.isIsolated() || Binder.getCallingUid()==android.os.Process.myUid()
                    || !started.compareAndSet(false,true))throw new SecurityException("Offline worker isolation or replay");
            long requestId=in.readLong();int authFlags=in.readInt(),count=in.readInt();
            if(count!=2)throw new SecurityException("Offline message count");
            List<OfflineSseAdapter.Message> messages=new ArrayList<>(2);
            for(int i=0;i<count;i++)messages.add(new OfflineSseAdapter.Message(
                    in.readLong(),in.readInt(),in.readString(),in.readString()));
            if(in.dataAvail()!=0)throw new SecurityException("Trailing offline parcel");
            OfflineFixtureProtocol.Packet packet=new OfflineFixtureProtocol.Packet(requestId,authFlags,messages);
            OfflineFixtureProtocol.validate(packet);
            out.writeNoException();out.writeLong(requestId);out.writeInt(1);
            out.writeInt(OfflineFixtureProtocol.EXPECTED_TEXT.getBytes(StandardCharsets.UTF_8).length);
            return true;
        }
    };
    @Override public void onCreate(){super.onCreate();if(!android.os.Process.isIsolated())throw new SecurityException("Isolation required");main.postDelayed(terminate,10000);}
    @Override public IBinder onBind(Intent intent){return endpoint;}
    @Override public boolean onUnbind(Intent intent){main.removeCallbacks(terminate);terminate.run();return false;}
    @Override public void onDestroy(){main.removeCallbacks(terminate);super.onDestroy();terminate.run();}
}
