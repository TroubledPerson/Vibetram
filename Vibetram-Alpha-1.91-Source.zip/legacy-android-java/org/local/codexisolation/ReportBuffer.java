// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;
final class ReportBuffer {
    static final int MAX_CHARS=16384,MAX_LINES=48;
    private final StringBuilder text=new StringBuilder();private int lines;private boolean overflow;
    ReportBuffer(String initial){if(initial==null||initial.length()>MAX_CHARS){overflow=true;return;}text.append(initial);}
    boolean append(String line){if(overflow||line==null||line.indexOf('\n')>=0||line.indexOf('\r')>=0||lines>=MAX_LINES||text.length()+1+line.length()>MAX_CHARS){overflow=true;return false;}text.append('\n').append(line);lines++;return true;}
    String snapshot(){return text.toString();}
    boolean overflowed(){return overflow;}
}
