// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

import android.app.Activity;
import android.os.*;
import android.graphics.*;
import android.view.*;
import android.widget.*;

/** On-screen simulated events only; actual lifecycle loss always revokes. */
public final class SimulatedHandoffActivity extends Activity {
    private SimulatedHandoff controller;
    private SimulatedHandoff.Ticket ticket;
    private final SimulatedReplayEvidence replayEvidence=new SimulatedReplayEvidence();
    private final Handler handler=new Handler(Looper.getMainLooper());
    private boolean resumed;
    private boolean confirming;
    private boolean destroyed;
    private TextView details;
    private ImageView image;
    private Bitmap bitmap;
    private long displayedRevision=-1;
    private String displayedHash,receipt="";
    private Button fresh,begin,loss,back,success,deny,replay,confirm,redact,review,approve,mode,death,stop,end;
    private final Runnable tick=new Runnable(){public void run(){render();if(resumed)handler.postDelayed(this,200);}};
    @Override public void onCreate(Bundle saved){
        super.onCreate(saved);controller=new SimulatedHandoff(SystemClock::elapsedRealtime);replayEvidence.attach(controller);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setOnApplyWindowInsetsListener((v,insets)->{
            if(Build.VERSION.SDK_INT>=30){Insets bars=insets.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout());
                v.setPadding(bars.left,bars.top,bars.right,bars.bottom);
            }else v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());return insets;
        });
        TextView title=new TextView(this);title.setText("1.78 SIMULATED HANDOFF ONLY. No Android consent dialog, screen capture or transmission. "
                +"Approval/handoff: 20-second hard window and 5-second return/result bounds. The later Are you sure? stage has NO timeout while focused. "
                +"Waiting never generates anything. Your Are you sure? click generates one synthetic frame immediately; there is no second Generate step. Image preview: 60 seconds. Simulated loss has unknown cause, including unrelated loss. "
                +"Real focus loss or leaving this screen ALWAYS revokes. Buttons simulate events without switching apps. "
                +"Fresh local confirmation is required; only a generated fixture can follow. "
                +"Replay uses only a genuine accepted result; its outcome and before/after counters are shown below. Begin never creates a replay result.");root.addView(title);
        LinearLayout controls=new LinearLayout(this);controls.setOrientation(LinearLayout.VERTICAL);root.addView(controls);
        stop=button(controls,"STOP SIMULATED HANDOFF");end=button(controls,"END SIMULATED SESSION");
        ScrollView scroll=new ScrollView(this);LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);scroll.addView(body);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        fresh=button(body,"NEW SIMULATED SESSION");begin=button(body,"BEGIN 20-SECOND SIMULATED CONSENT");
        loss=button(body,"SIMULATE DEPARTURE (FOCUS/PAUSE/STOP)");
        success=button(body,"SIMULATE APPROVED RESULT");deny=button(body,"SIMULATE DENIED RESULT");
        back=button(body,"SIMULATE FOCUSED RETURN");replay=button(body,"REPLAY LAST ACCEPTED SIMULATED RESULT");
        details=new TextView(this);details.setSaveEnabled(false);body.addView(details);
        confirm=button(body,"ARE YOU SURE? GENERATE ONE SYNTHETIC FRAME NOW");
        image=new ImageView(this);image.setAdjustViewBounds(true);image.setScaleType(ImageView.ScaleType.FIT_CENTER);
        image.setContentDescription("Generated synthetic fixture only");image.setSaveEnabled(false);
        body.addView(image,new LinearLayout.LayoutParams(-1,(int)(160*getResources().getDisplayMetrics().density)));
        redact=button(body,"REDACT GENERATED PREVIEW");review=button(body,"REVIEW EXACT GENERATED PREVIEW");
        approve=button(body,"APPROVE GENERATED PREVIEW LOCALLY ONCE");
        mode=button(body,"SIMULATE MODE CHANGE (REVOKE)");death=button(body,"SIMULATE PROCESS LOSS (REVOKE)");
        setContentView(root);root.requestApplyInsets();
        fresh.setOnClickListener(v->{if(!resumed||!hasWindowFocus())return;
            controller.close("REPLACED");controller=new SimulatedHandoff(SystemClock::elapsedRealtime);controller.actualVisible(true);replayEvidence.attach(controller);
            ticket=null;receipt="";confirming=false;clearImage();render();});
        begin.setOnClickListener(v->{SimulatedHandoff.Ticket requested=controller.begin();if(requested!=null)ticket=requested;render();});
        loss.setOnClickListener(v->{controller.simulatedLoss("UNKNOWN_CAUSE");render();});
        back.setOnClickListener(v->{controller.simulatedReturn();render();});
        success.setOnClickListener(v->{replayEvidence.primary(controller,ticket,SimulatedHandoff.Result.APPROVED);render();});
        deny.setOnClickListener(v->{replayEvidence.primary(controller,ticket,SimulatedHandoff.Result.DENIED);render();});
        replay.setOnClickListener(v->{replayEvidence.replay(controller);render();});
        confirm.setOnClickListener(v->{
            if(confirming||!resumed||!hasWindowFocus())return;
            final SimulatedHandoff target=controller;final SimulatedHandoff.Ticket authorized=ticket;
            confirming=true;render();
            new Thread(()->{try{target.confirm(authorized);}finally{handler.post(()->{
                if(!destroyed&&controller==target){confirming=false;render();}
            });}},"synthetic-fixture-once").start();
        });
        redact.setOnClickListener(v->{controller.redact(ticket);render();});
        review.setOnClickListener(v->{controller.requestReview(ticket);render();});
        approve.setOnClickListener(v->{SyntheticReviewCoordinator.Receipt r=controller.approve(ticket,displayedRevision,displayedHash);
            if(r!=null)receipt="Local receipt revision="+r.revision+" sha256="+r.sha256+" bytes="+r.encodedBytes+". Nothing transmitted.";render();});
        stop.setOnClickListener(v->{controller.close("STOPPED");render();});end.setOnClickListener(v->{controller.close("END_SESSION");render();});
        mode.setOnClickListener(v->{controller.close("MODE_CHANGE_REVOKED");render();});death.setOnClickListener(v->{controller.close("SIMULATED_PROCESS_LOSS_REVOKED");render();});
        render();
    }
    private Button button(LinearLayout parent,String label){Button b=new Button(this);b.setText(label);parent.addView(b);return b;}
    private void clearImage(){if(image!=null)image.setImageDrawable(null);if(bitmap!=null){bitmap.recycle();bitmap=null;}displayedRevision=-1;displayedHash=null;}
    private void render(){
        if(details==null)return;
        SimulatedHandoff.State state=controller.state();SyntheticReviewCoordinator.Preview p=controller.preview();
        if(p==null)clearImage();else if(displayedRevision!=p.revision){
            clearImage();byte[] bytes=p.png();bitmap=BitmapFactory.decodeByteArray(bytes,0,bytes.length);
            if(bitmap==null||bitmap.getWidth()!=p.width||bitmap.getHeight()!=p.height){controller.close("GENERATED_DECODE_FAILED");clearImage();}
            else{image.setImageBitmap(bitmap);displayedRevision=p.revision;displayedHash=p.sha256;}
        }
        state=controller.state();if(state==SimulatedHandoff.State.CLOSED||state==SimulatedHandoff.State.DONE){p=null;clearImage();}
        boolean visible=resumed&&hasWindowFocus(),live=visible&&state!=SimulatedHandoff.State.CLOSED&&state!=SimulatedHandoff.State.DONE;
        fresh.setEnabled(visible);begin.setEnabled(live&&state==SimulatedHandoff.State.IDLE);
        loss.setEnabled(live&&state!=SimulatedHandoff.State.IDLE);back.setEnabled(live&&(state==SimulatedHandoff.State.PENDING||state==SimulatedHandoff.State.HELD));
        success.setEnabled(live&&(state==SimulatedHandoff.State.PENDING||state==SimulatedHandoff.State.RETURNED));deny.setEnabled(success.isEnabled());
        replay.setEnabled(visible&&replayEvidence.hasAcceptedResult());confirm.setEnabled(live&&state==SimulatedHandoff.State.CONFIRM&&!confirming);
        redact.setEnabled(live&&(state==SimulatedHandoff.State.PREVIEW||state==SimulatedHandoff.State.REVIEW));review.setEnabled(live&&state==SimulatedHandoff.State.PREVIEW);
        approve.setEnabled(live&&state==SimulatedHandoff.State.REVIEW);mode.setEnabled(live);death.setEnabled(live);stop.setEnabled(live);end.setEnabled(live);
        long remaining=controller.remaining();
        details.setText("State: "+state+" / "+controller.status()+"\n"+(state==SimulatedHandoff.State.GENERATING
                ?"Generating the one approved synthetic fixture; cancellation still discards its result."
                :remaining<0?"Are you sure? No confirmation timeout. Waiting is inert; explicit confirmation or cancellation required."
                :"Approval/handoff or active-stage deadline remaining: "+remaining+" ms")
                +"\nSimulated accepted results="+controller.results()+", confirmations="+controller.confirmations()+", generated frames="+controller.frames()+", completed generated jobs="+controller.releases()
                +"\n"+replayEvidence.text()
                +"\nNo actual acquisition resources exist.\n"+(p==null?"No retained preview.":"Exact generated PNG "+p.width+"x"+p.height+", bytes="+p.encodedBytes()+", revision="+p.revision+"\nSHA256="+p.sha256)+"\n"+receipt);
    }
    @Override protected void onResume(){super.onResume();resumed=true;if(hasWindowFocus())controller.actualVisible(true);handler.post(tick);}
    @Override public void onWindowFocusChanged(boolean focused){super.onWindowFocusChanged(focused);if(controller!=null){controller.actualVisible(resumed&&focused);render();}}
    @Override protected void onPause(){resumed=false;handler.removeCallbacks(tick);controller.actualVisible(false);clearImage();render();super.onPause();}
    @Override protected void onStop(){controller.actualVisible(false);clearImage();super.onStop();}
    @Override protected void onDestroy(){destroyed=true;handler.removeCallbacks(tick);controller.close("DESTROYED");clearImage();super.onDestroy();}
}
