// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.io.File;

/** Explicit connectivity check; never starts device sign-in. */
public final class ConnectivityProbeActivity extends Activity {
    private ConnectivityProbeSession session;
    private boolean attempted,destroyed;
    @Override public void onCreate(Bundle saved){
        super.onCreate(saved);
        attempted=saved!=null&&saved.getBoolean("attempted");
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setOnApplyWindowInsetsListener((v,insets)->{
            if(Build.VERSION.SDK_INT>=30){
                android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout());
                v.setPadding(bars.left,bars.top,bars.right,bars.bottom);
            }else v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),
                    insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());
            return insets;
        });
        TextView report=new TextView(this);report.setTextIsSelectable(true);
        report.setText("1.46 connectivity check. Two HEAD requests maximum to auth.openai.com/codex/device. No sign-in, codes, account read, or model use.\n");
        Button run=new Button(this);run.setText("RUN CONNECTIVITY CHECK ONCE");run.setEnabled(!attempted);
        Button cancel=new Button(this);cancel.setText("CANCEL CONNECTIVITY CHECK");
        root.addView(run);root.addView(cancel);root.addView(report);setContentView(root);root.requestApplyInsets();
        run.setOnClickListener(v->{
            if(attempted)return;attempted=true;run.setEnabled(false);report.append("CASE=CONNECTIVITY_HEAD\n");
            if(Build.VERSION.SDK_INT<29||!"arm64-v8a".equals(Build.SUPPORTED_ABIS[0])){
                report.append("UNSUPPORTED_DEVICE\n");return;
            }
            session=new ConnectivityProbeSession(OfflineAppServerAdapter.SYSTEM);
            File binary=new File(getApplicationInfo().nativeLibraryDir,"libcodex_app_server.so");
            new Thread(()->{
                String outcome=session.run(getFilesDir(),binary);
                runOnUiThread(()->{if(!destroyed)report.append(outcome+"\n");});
            },"connectivity-probe-parent").start();
        });
        cancel.setOnClickListener(v->{if(session!=null){session.cancel();report.append("CANCEL_REQUESTED\n");}});
    }
    @Override protected void onSaveInstanceState(Bundle out){out.putBoolean("attempted",attempted);super.onSaveInstanceState(out);}
    @Override protected void onDestroy(){destroyed=true;if(session!=null)session.cancel();super.onDestroy();}
}
