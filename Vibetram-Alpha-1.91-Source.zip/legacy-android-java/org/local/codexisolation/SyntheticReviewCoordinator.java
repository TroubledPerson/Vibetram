// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/** Synthetic-only review session. No delivery adapter, real capture grant, or production tool context. */
final class SyntheticReviewCoordinator {
    interface Clock {long now();}
    enum State {IDLE,FIXTURE_APPROVAL,FRAME_PENDING,PREVIEW,PREVIEW_APPROVAL,APPROVED_LOCAL,CLOSED}
    enum Mode {REQUEST_APPROVAL,APPROVE_FOR_ME,FULL_ACCESS}
    enum Decision {ASK,ALLOW,DENY}
    private Mode mode=Mode.REQUEST_APPROVAL;
    private boolean ruleApprovedFrame;
    synchronized Mode mode(){expire();return mode;}
    synchronized Decision decision(String action,boolean uncertain,boolean sensitive,boolean consequential){
        expire();
        if(!active()||!("FIXED_SYNTHETIC_FIXTURE".equals(action)||"LOCAL_CROP".equals(action)
                ||"LOCAL_REDACT".equals(action)||"EXACT_LOCAL_RECEIPT".equals(action)))return Decision.DENY;
        if(uncertain||sensitive||consequential)return Decision.ASK;
        if(mode==Mode.REQUEST_APPROVAL)return Decision.ASK;
        if(mode==Mode.APPROVE_FOR_ME&&"EXACT_LOCAL_RECEIPT".equals(action))return Decision.ASK;
        return Decision.ALLOW;
    }
    synchronized boolean selectMode(Mode selected,boolean confirmedHigherRisk){
        expire();
        if(!active()||selected==null||(selected==Mode.FULL_ACCESS&&!confirmedHigherRisk))return false;
        if(selected==mode)return false;
        generation++;release();mode=selected;state=State.IDLE;edits=0;
        status="MODE_CHANGED_PENDING_WORK_DISCARDED";return true;
    }
    // Explicit local button request only. This cannot grant production tool or OS authority.
    synchronized Ticket requestFixedFixture(){
        Ticket requested=requestFixture();
        if(requested!=null&&decision("FIXED_SYNTHETIC_FIXTURE",false,false,false)==Decision.ALLOW){
            if(approveFixture(requested,true)){
                ruleApprovedFrame=true;acceptSyntheticFrame(requested,SyntheticReviewRaster.fixture());
            }
        }
        return requested;
    }
    synchronized Receipt approveExactByMode(Ticket candidate,long displayedRevision,String displayedHash){
        if(decision("EXACT_LOCAL_RECEIPT",false,false,false)!=Decision.ALLOW||!current(candidate)
                ||preview==null||preview.revision!=displayedRevision||!preview.sha256.equals(displayedHash))return null;
        Approval exact=requestLocalApproval(candidate);
        return exact==null?null:approvePreview(exact,true);
    }
    static final class Ticket {
        private final SyntheticReviewCoordinator owner;
        private final long generation;
        private Ticket(SyntheticReviewCoordinator owner,long generation){this.owner=owner;this.generation=generation;}
    }
    static final class Approval {
        private final Ticket ticket;
        final long revision;
        final String sha256;
        private Approval(Ticket ticket,long revision,String sha256){this.ticket=ticket;this.revision=revision;this.sha256=sha256;}
    }
    static final class Preview {
        final int width,height;
        final long revision;
        final String sha256;
        private final byte[] png;
        private Preview(SyntheticReviewRaster raster,long revision,byte[] png){
            width=raster.width;height=raster.height;this.revision=revision;this.png=png.clone();sha256=hash(png);
        }
        byte[] png(){return png.clone();}
        int encodedBytes(){return png.length;}
    }
    static final class Receipt {
        final String sha256;
        final long revision;
        final int width,height,encodedBytes;
        private Receipt(Preview preview){sha256=preview.sha256;revision=preview.revision;
            width=preview.width;height=preview.height;encodedBytes=preview.encodedBytes();}
    }
    private final Clock clock;
    private boolean foreground,focused;
    private State state=State.IDLE;
    private String status="IDLE";
    private long generation,revision,deadline;
    private int edits,fixtureApprovals,acceptedFrames,localApprovals;
    private Ticket ticket;
    private Approval approval;
    private SyntheticReviewRaster raster;
    private Preview preview;
    SyntheticReviewCoordinator(Clock clock){if(clock==null)throw new IllegalArgumentException();this.clock=clock;}
    synchronized void foreground(boolean value){foreground=value;if(!value)close("BACKGROUND_REVOKED");}
    synchronized void focused(boolean value){focused=value;if(!value)close("FOCUS_REVOKED");}
    synchronized State state(){expire();return state;}
    synchronized String status(){expire();return status;}
    private boolean active(){return foreground&&focused&&state!=State.CLOSED&&state!=State.APPROVED_LOCAL;}
    private long after(long millis){return Math.addExact(clock.now(),millis);}
    private void expire(){
        if(state!=State.IDLE&&state!=State.CLOSED&&state!=State.APPROVED_LOCAL&&clock.now()>=deadline)close("EXPIRED");
    }
    private boolean current(Ticket candidate){expire();return active()&&candidate!=null&&candidate==ticket
            &&candidate.owner==this&&candidate.generation==generation;}
    synchronized Ticket requestFixture(){
        if(!active()||state!=State.IDLE)return null;
        ticket=new Ticket(this,++generation);deadline=after(120000);state=State.FIXTURE_APPROVAL;status="FIXTURE_APPROVAL_REQUIRED";
        return ticket;
    }
    synchronized boolean approveFixture(Ticket candidate,boolean allow){
        if(!current(candidate)||state!=State.FIXTURE_APPROVAL)return false;
        if(!allow){close("FIXTURE_NOT_APPROVED");return false;}
        fixtureApprovals++;state=State.FRAME_PENDING;deadline=after(10000);status="SYNTHETIC_FRAME_PENDING";return true;
    }
    synchronized boolean acceptSyntheticFrame(Ticket candidate,SyntheticReviewRaster frame){
        if(!current(candidate)||state!=State.FRAME_PENDING)return false;
        if(frame==null){close("SYNTHETIC_FRAME_INVALID");return false;}
        try{
            byte[] png=frame.png();
            if(ruleApprovedFrame&&!hash(png).equals(hash(SyntheticReviewRaster.fixture().png()))){
                close("RULE_FIXTURE_MISMATCH");return false;
            }
            raster=frame;preview=new Preview(frame,++revision,png);
            acceptedFrames++;state=State.PREVIEW;deadline=after(60000);status="PREVIEW_LOCAL_ONLY";return true;
        }catch(IllegalArgumentException error){close("SYNTHETIC_SIZE_OR_ENCODING_REJECTED");return false;}
    }
    synchronized Preview preview(){expire();return active()?preview:null;}
    synchronized boolean crop(Ticket candidate,int x,int y,int width,int height){
        if(!editable(candidate))return false;
        try{return replace(raster.crop(x,y,width,height));}catch(IllegalArgumentException error){status="EDIT_REJECTED";return false;}
    }
    synchronized boolean redact(Ticket candidate,int x,int y,int width,int height){
        if(!editable(candidate))return false;
        try{return replace(raster.redact(x,y,width,height));}catch(IllegalArgumentException error){status="EDIT_REJECTED";return false;}
    }
    private boolean editable(Ticket candidate){return current(candidate)
            &&(state==State.PREVIEW||state==State.PREVIEW_APPROVAL)&&edits<8;}
    private boolean replace(SyntheticReviewRaster replacement){
        byte[] png=replacement.png();raster=replacement;preview=new Preview(replacement,++revision,png);
        edits++;approval=null;state=State.PREVIEW;status="PREVIEW_CHANGED_FRESH_APPROVAL_REQUIRED";return true;
    }
    synchronized Approval requestLocalApproval(Ticket candidate){
        if(!current(candidate)||state!=State.PREVIEW)return null;
        approval=new Approval(ticket,preview.revision,preview.sha256);state=State.PREVIEW_APPROVAL;
        status="APPROVE_EXACT_PREVIEW_LOCALLY";return approval;
    }
    synchronized Receipt approvePreview(Approval candidate,boolean allow){
        expire();
        if(!active()||state!=State.PREVIEW_APPROVAL||candidate==null||candidate!=approval
                ||!current(candidate.ticket)||candidate.revision!=preview.revision
                ||!candidate.sha256.equals(preview.sha256)||!candidate.sha256.equals(hash(preview.png)))return null;
        if(!allow){close("PREVIEW_NOT_APPROVED");return null;}
        Receipt receipt=new Receipt(preview);localApprovals++;release();state=State.APPROVED_LOCAL;
        status="APPROVED_LOCALLY_NO_TRANSMISSION";return receipt;
    }
    synchronized void close(String reason){
        if(state==State.CLOSED)return;
        generation++;release();mode=Mode.REQUEST_APPROVAL;state=State.CLOSED;status=reason;
    }
    private void release(){raster=null;preview=null;approval=null;ticket=null;ruleApprovedFrame=false;}
    synchronized int fixtureApprovals(){return fixtureApprovals;}
    synchronized int acceptedFrames(){return acceptedFrames;}
    synchronized int localApprovals(){return localApprovals;}
    synchronized int editsRemaining(){expire();return active()&&(state==State.PREVIEW||state==State.PREVIEW_APPROVAL)?8-edits:0;}
    synchronized boolean retainsPixels(){return raster!=null||preview!=null;}
    static String hash(byte[] png){
        try{
            byte[] digest=MessageDigest.getInstance("SHA-256").digest(png);StringBuilder out=new StringBuilder(64);
            for(byte value:digest){int b=value&255;out.append(Character.forDigit(b>>>4,16));out.append(Character.forDigit(b&15,16));}
            return out.toString();
        }catch(NoSuchAlgorithmException error){throw new AssertionError(error);}
    }
}
