// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/** Fixed, parent-UID offline RPC against the pinned genuine app-server. */
final class RealOfflineTurnSession {
    static final String APP_SERVER_SHA256="50d655fd709a44dabede21242f3c01aef2c9cf9c78b5fbfeecd1799555750c09";
    private static final String FAKE_KEY="sk-coretest-local-only";
    private static final String FIXED_TEXT="Local café.";
    private static final int MAX_FRAME=65536, MAX_FRAMES=96, MAX_STDERR=131072;
    enum Mode { COMPLETE, INTERRUPT, LIFECYCLE_DESTROY }
    static final class GateException extends Exception {
        final String code;
        GateException(String code){super(code);this.code=code;}
    }
    static final class Result {
        final String status;final int localRequests,deltaCount;final boolean utf8Split;
        Result(String status,int localRequests,int deltaCount,boolean utf8Split){
            this.status=status;this.localRequests=localRequests;this.deltaCount=deltaCount;this.utf8Split=utf8Split;
        }
    }
    private final OfflineAppServerAdapter.ProcessFactory factory;
    private final Runnable firstDeltaCallback;
    private final AtomicBoolean started=new AtomicBoolean(), cancelled=new AtomicBoolean();
    private volatile Process child;
    private volatile String stage="NOT_STARTED";
    private int frames;
    private volatile int stderrBytes;
    private String threadId,turnId;
    private String agentMessageItemId;
    private final StringBuilder deltaText=new StringBuilder();
    private int deltaCount;
    private boolean loginCompleted,fixedAssistantText;
    private volatile boolean cleanupComplete,childStopped,serverClosed,authJsonAbsent;
    private volatile int observedRequests,observedDeltas;
    private volatile boolean observedUtf8Split;
    RealOfflineTurnSession(OfflineAppServerAdapter.ProcessFactory factory){this(factory,null);}
    RealOfflineTurnSession(OfflineAppServerAdapter.ProcessFactory factory,Runnable firstDeltaCallback){
        this.factory=factory;this.firstDeltaCallback=firstDeltaCallback;
    }
    String stage(){return stage;}
    boolean cleanupComplete(){return cleanupComplete&&childStopped&&serverClosed&&authJsonAbsent;}
    int observedRequests(){return observedRequests;}
    int observedDeltas(){return observedDeltas;}
    boolean observedUtf8Split(){return observedUtf8Split;}
    void cancel(){cancelled.set(true);Process p=child;if(p!=null)try{p.destroyForcibly();}catch(RuntimeException ignored){}}

    Result run(File filesDir,File binary,Mode mode) throws GateException {
        if(!started.compareAndSet(false,true))throw new GateException("ALREADY_RUN");
        File home=null;Process p=null;LoopbackStreamingServer server=null;
        ExecutorService readers=Executors.newFixedThreadPool(2);
        try{
            long deadline=System.nanoTime()+TimeUnit.SECONDS.toNanos(60);
            stage="HOME_CHECK";
            File privateDir=filesDir.getCanonicalFile();
            require(privateDir.isDirectory(),"PRIVATE_FILES_MISSING");
            home=new File(privateDir,"real-offline-turn-v42-"+mode.name().toLowerCase(java.util.Locale.ROOT)
                    +"-"+UUID.randomUUID()).getCanonicalFile();
            require(privateDir.equals(home.getParentFile()),"HOME_OUTSIDE_PRIVATE_FILES");
            require(!home.exists(),"HOME_ALREADY_EXISTS");
            Files.createDirectory(home.toPath());
            require(binary.isFile()&&binary.canExecute()&&binary.length()==253508688,"APP_SERVER_UNAVAILABLE");
            MessageDigest digest=MessageDigest.getInstance("SHA-256");
            try(InputStream input=Files.newInputStream(binary.toPath())){
                byte[] buffer=new byte[65536];int count;
                while((count=input.read(buffer))!=-1)digest.update(buffer,0,count);
            }
            require(APP_SERVER_SHA256.equals(hex(digest.digest())),"APP_SERVER_MISMATCH");
            server=new LoopbackStreamingServer(mode!=Mode.COMPLETE);
            String config="model = \"mock-model\"\nmodel_provider = \"mock_provider\"\n"
                    +"approval_policy = \"never\"\nsandbox_mode = \"read-only\"\n"
                    +"cli_auth_credentials_store = \"ephemeral\"\n"
                    +"[history]\npersistence = \"none\"\n"
                    +"[analytics]\nenabled = false\n"
                    +"[model_providers.mock_provider]\nname = \"Offline local provider\"\n"
                    +"base_url = \"http://127.0.0.1:"+server.port()+"/v1\"\n"
                    +"wire_api = \"responses\"\nrequest_max_retries = 0\nstream_max_retries = 0\n"
                    +"supports_websockets = false\nrequires_openai_auth = false\n";
            Files.write(home.toPath().resolve("config.toml"),config.getBytes(StandardCharsets.UTF_8));
            Map<String,String> env=new HashMap<>();
            env.put("PATH","/system/bin");env.put("HOME",home.getPath());env.put("CODEX_HOME",home.getPath());
            stage="PROCESS_START";
            p=factory.start(Arrays.asList(binary.getAbsolutePath(),"--listen","stdio://",
                    "-c","cli_auth_credentials_store=\"ephemeral\"",
                    "-c","features.plugins=false","-c","features.remote_plugin=false",
                    "--disable-plugin-startup-tasks-for-tests"),env);
            child=p;
            final Process running=p;
            readers.submit(()->{byte[] b=new byte[512];int n;
                try{while((n=running.getErrorStream().read(b))!=-1){stderrBytes+=n;
                    if(stderrBytes>MAX_STDERR){cancel();break;}}}catch(IOException ignored){} });
            InputStream in=p.getInputStream();OutputStream out=p.getOutputStream();
            stage="INITIALIZE";
            send(out,"{\"id\":1,\"method\":\"initialize\",\"params\":{\"clientInfo\":{\"name\":\"offline-real-turn\",\"title\":null,\"version\":\"0.1\"}}}");
            Map<?,?> init=obj(reply(in,readers,deadline,1).get("result"),"INIT_INVALID");
            require("android".equals(init.get("platformOs"))&&home.getPath().equals(init.get("codexHome")),"INIT_BOUNDARY_INVALID");
            send(out,"{\"method\":\"initialized\"}");
            stage="ACCOUNT_EMPTY";
            send(out,"{\"id\":2,\"method\":\"account/read\",\"params\":{\"refreshToken\":false}}");
            Map<?,?> account=obj(reply(in,readers,deadline,2).get("result"),"ACCOUNT_INVALID");
            require(account.containsKey("account")&&account.get("account")==null,"ACCOUNT_NOT_EMPTY");
            stage="FAKE_LOGIN";
            send(out,"{\"id\":3,\"method\":\"account/login/start\",\"params\":{\"type\":\"apiKey\",\"apiKey\":\""+FAKE_KEY+"\"}}");
            reply(in,readers,deadline,3);
            while(!loginCompleted)notification(frame(in,readers,deadline));
            stage="THREAD_START";
            send(out,"{\"id\":4,\"method\":\"thread/start\",\"params\":{\"model\":\"mock-model\",\"modelProvider\":\"mock_provider\",\"cwd\":"+quote(home.getPath())+",\"approvalPolicy\":\"never\",\"sandbox\":\"read-only\",\"ephemeral\":true}}");
            Map<?,?> thread=obj(reply(in,readers,deadline,4).get("result"),"THREAD_INVALID");
            threadId=string(obj(thread.get("thread"),"THREAD_INVALID").get("id"),"THREAD_INVALID");
            require(threadId.length()<=64,"THREAD_INVALID");
            stage="TURN_START";
            send(out,"{\"id\":5,\"method\":\"turn/start\",\"params\":{\"threadId\":"+quote(threadId)+",\"input\":[{\"type\":\"text\",\"text\":\"offline synthetic ping\",\"textElements\":[]}]}}");
            Map<?,?> turn=obj(reply(in,readers,deadline,5).get("result"),"TURN_INVALID");
            turnId=string(obj(turn.get("turn"),"TURN_INVALID").get("id"),"TURN_INVALID");
            require(turnId.length()<=64,"TURN_INVALID");
            stage="STREAM";
            if(mode==Mode.INTERRUPT){
                while(deltaCount<1)require(notification(frame(in,readers,deadline))==null,"PREMATURE_COMPLETION");
                require("Local ".contentEquals(deltaText),"FIRST_DELTA_INVALID");
                send(out,"{\"id\":6,\"method\":\"turn/interrupt\",\"params\":{\"threadId\":"+quote(threadId)+",\"turnId\":"+quote(turnId)+"}}");
                reply(in,readers,deadline,6);
            }
            if(mode==Mode.LIFECYCLE_DESTROY){
                while(deltaCount<1)require(notification(frame(in,readers,deadline))==null,"PREMATURE_COMPLETION");
                require("Local ".contentEquals(deltaText),"FIRST_DELTA_INVALID");
                stage="WAIT_FOR_ACTIVITY_DESTROY";
                for(int i=0;i<MAX_FRAMES;i++)notification(frame(in,readers,deadline));
                throw new GateException("ACTIVITY_DESTROY_NOT_OBSERVED");
            }
            String status=null;
            for(int i=0;i<MAX_FRAMES&&status==null;i++)status=notification(frame(in,readers,deadline));
            require((mode==Mode.COMPLETE?"completed":"interrupted").equals(status),"TURN_STATUS_INVALID");
            if(mode==Mode.COMPLETE)
                require(deltaCount==2&&FIXED_TEXT.contentEquals(deltaText)&&fixedAssistantText
                        &&server.utf8SplitWritten(),"STREAM_CONTENT_INVALID");
            else require(deltaCount==1&&"Local ".contentEquals(deltaText)
                    &&!server.utf8SplitWritten(),"INTERRUPT_STREAM_INVALID");
            require(server.requests()==1&&server.failure()==null,"LOCAL_PROVIDER_INVALID");
            require(stderrBytes<=MAX_STDERR,"STDERR_OVERSIZE");
            stage="COMPLETE";
            return new Result(status,server.requests(),deltaCount,server.utf8SplitWritten());
        }catch(GateException e){throw e;}
        catch(Exception e){throw new GateException(cancelled.get()?"CANCELLED":"SESSION_STOPPED");}
        finally{
            if(p!=null){p.destroyForcibly();try{if(!p.waitFor(2,TimeUnit.SECONDS)||p.isAlive())throw new GateException("CHILD_STILL_RUNNING");
                    childStopped=true;}
                catch(InterruptedException e){Thread.currentThread().interrupt();throw new GateException("CHILD_STILL_RUNNING");}}
            child=null;readers.shutdownNow();
            if(server!=null){observedRequests=server.requests();observedUtf8Split=server.utf8SplitWritten();
                try{server.close();serverClosed=true;}catch(Exception e){throw new GateException("SERVER_STILL_RUNNING");}}
            observedDeltas=deltaCount;
            if(home!=null&&new File(home,"auth.json").exists()){
                try{Files.deleteIfExists(new File(home,"auth.json").toPath());}catch(IOException ignored){}
                throw new GateException("CREDENTIAL_FILE_CREATED");
            }
            authJsonAbsent=true;
            cleanupComplete=true;
        }
    }
    private Map<?,?> reply(InputStream in,ExecutorService readers,long deadline,int id) throws Exception{
        for(int i=0;i<MAX_FRAMES;i++){
            Map<?,?> value=frame(in,readers,deadline);
            if(value.containsKey("id")){
                require(BigDecimal.valueOf(id).equals(value.get("id"))&&!value.containsKey("error"),"RPC_REJECTED");
                return value;
            }
            require(notification(value)==null,"PREMATURE_COMPLETION");
        }
        throw new GateException("REPLY_MISSING");
    }
    private String notification(Map<?,?> value) throws GateException{
        require(!value.containsKey("id"),"UNREQUESTED_SERVER_CALL");
        String method=string(value.get("method"),"METHOD_INVALID");
        Map<?,?> params=obj(value.get("params"),"NOTIFICATION_INVALID");
        if("account/login/completed".equals(method)){
            require(Boolean.TRUE.equals(params.get("success")),"FAKE_LOGIN_FAILED");loginCompleted=true;return null;
        }
        if("item/started".equals(method)||"item/completed".equals(method)){
            require(threadId.equals(params.get("threadId"))&&turnId.equals(params.get("turnId")),"ITEM_IDS_INVALID");
            Map<?,?> item=obj(params.get("item"),"ITEM_INVALID");
            String type=string(item.get("type"),"ITEM_INVALID");
            require("userMessage".equals(type)||"agentMessage".equals(type),"UNEXPECTED_ITEM_TYPE");
            if("agentMessage".equals(type)){
                String id=string(item.get("id"),"ITEM_ID_INVALID");require(id.length()<=64,"ITEM_ID_INVALID");
                if("item/started".equals(method))agentMessageItemId=id;
                else{
                    require(id.equals(agentMessageItemId),"ITEM_ID_INVALID");
                    fixedAssistantText=FIXED_TEXT.equals(item.get("text"));
                }
            }
            return null;
        }
        if("item/agentMessage/delta".equals(method)){
            require(threadId.equals(params.get("threadId"))&&turnId.equals(params.get("turnId"))
                    &&agentMessageItemId!=null&&agentMessageItemId.equals(params.get("itemId")),"DELTA_IDS_INVALID");
            String delta=string(params.get("delta"),"DELTA_INVALID");
            require(delta.length()<=64&&++deltaCount<=2&&deltaText.length()+delta.length()<=64,"DELTA_OVERSIZE");
            deltaText.append(delta);
            if(deltaCount==1&&firstDeltaCallback!=null)firstDeltaCallback.run();
            return null;
        }
        if("turn/completed".equals(method)){
            require(threadId.equals(params.get("threadId")),"COMPLETION_ID_INVALID");
            Map<?,?> turn=obj(params.get("turn"),"COMPLETION_INVALID");
            require(turnId.equals(turn.get("id")),"COMPLETION_ID_INVALID");
            return string(turn.get("status"),"COMPLETION_INVALID");
        }
        require("remoteControl/status/changed".equals(method)||"account/updated".equals(method)
                ||"thread/started".equals(method)||"warning".equals(method)
                ||"thread/status/changed".equals(method)||"turn/started".equals(method)
                ||"thread/tokenUsage/updated".equals(method)||"account/rateLimits/updated".equals(method),
                "UNEXPECTED_NOTIFICATION");
        return null;
    }
    private Map<?,?> frame(InputStream in,ExecutorService readers,long deadline) throws Exception{
        require(!cancelled.get(),"CANCELLED");require(++frames<=MAX_FRAMES,"TOO_MANY_FRAMES");
        long remaining=deadline-System.nanoTime();require(remaining>0,"SESSION_TIMEOUT");
        byte[] line=readers.submit(()->readLine(in)).get(remaining,TimeUnit.NANOSECONDS);
        return obj(BoundedJson.parse(line),"FRAME_INVALID");
    }
    private static byte[] readLine(InputStream in) throws IOException{
        ByteArrayOutputStream bytes=new ByteArrayOutputStream();
        while(bytes.size()<MAX_FRAME){int b=in.read();if(b<0)throw new IOException("EOF");if(b=='\n')return bytes.toByteArray();bytes.write(b);}
        throw new IOException("FRAME_OVERSIZE");
    }
    private static void send(OutputStream out,String value) throws IOException{out.write((value+"\n").getBytes(StandardCharsets.UTF_8));out.flush();}
    private static String quote(String value){return "\""+value.replace("\\","\\\\").replace("\"","\\\"")+"\"";}
    private static Map<?,?> obj(Object value,String code) throws GateException{if(!(value instanceof Map))throw new GateException(code);return (Map<?,?>)value;}
    private static String string(Object value,String code) throws GateException{if(!(value instanceof String))throw new GateException(code);return (String)value;}
    private static void require(boolean good,String code) throws GateException{if(!good)throw new GateException(code);}
    private static String hex(byte[] b){char[] h="0123456789abcdef".toCharArray();char[] x=new char[b.length*2];for(int i=0;i<b.length;i++){x[2*i]=h[(b[i]>>4)&15];x[2*i+1]=h[b[i]&15];}return new String(x);}
}
