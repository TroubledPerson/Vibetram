// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.DocumentsContract;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;

/** Ephemeral SAF tree grant. Only immediate, named, small UTF-8 text documents are exposed. */
final class SafFolder implements SelectedFolderAccess {
    private static final String[] COLUMNS={DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_FLAGS,DocumentsContract.Document.COLUMN_SIZE};
    private final Context app;
    private final Uri tree;
    private final String rootId;
    private final boolean writeGranted;
    private volatile boolean revoked;
    private static final class Entry {
        final String id,name;final boolean writable;final long size;
        Entry(String id,String name,boolean writable,long size){this.id=id;this.name=name;this.writable=writable;this.size=size;}
    }
    static SafFolder fromPicker(Context context,Intent result) throws IOException {
        if(result==null||result.getData()==null)throw new IOException("PICKER_CANCELLED");
        Uri uri=result.getData();int flags=result.getFlags();
        if(!"content".equals(uri.getScheme())||uri.getAuthority()==null||!DocumentsContract.isTreeUri(uri)
                ||(flags&Intent.FLAG_GRANT_READ_URI_PERMISSION)==0)throw new IOException("TREE_GRANT_INVALID");
        try{return new SafFolder(context.getApplicationContext(),uri,
                (flags&Intent.FLAG_GRANT_WRITE_URI_PERMISSION)!=0);}
        catch(IllegalArgumentException e){throw new IOException("TREE_GRANT_INVALID",e);}
    }
    private SafFolder(Context app,Uri tree,boolean writeGranted){
        this.app=app;this.tree=tree;this.writeGranted=writeGranted;
        this.rootId=DocumentsContract.getTreeDocumentId(tree);
    }
    String scope(){return revoked?"No selected folder":"Selected folder "+rootId+" via "+tree.getAuthority()
            +"; immediate .txt/.md/.json files only; "+(writeGranted?"reviewed writes available":"read only")
            +"; access ends on disconnect or app restart.";}
    void revoke(){
        revoked=true;
        Thread revoke=new Thread(()->{
            synchronized(this){try{app.revokeUriPermission(tree,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);}
                catch(RuntimeException ignored){/* Local bridge is revoked even if provider already dropped the grant. */}}
        },"selected-folder-revoke");
        revoke.setDaemon(true);revoke.start();
    }
    private void check() throws IOException {if(revoked)throw new IOException("FOLDER_DISCONNECTED");}
    private Uri document(String id){return DocumentsContract.buildDocumentUriUsingTree(tree,id);}
    private List<Entry> entries() throws Exception {
        check();
        Uri children=DocumentsContract.buildChildDocumentsUriUsingTree(tree,rootId);
        List<Entry> result=new ArrayList<>();HashSet<String> seen=new HashSet<>();int count=0;
        try(Cursor cursor=app.getContentResolver().query(children,COLUMNS,null,null,null)){
            if(cursor==null)throw new IOException("PROVIDER_UNAVAILABLE");
            while(cursor.moveToNext()){
                if(++count>FolderPolicy.MAX_ENTRIES)throw new IOException("TOO_MANY_CHILDREN");
                String id=cursor.getString(0),name=cursor.getString(1),mime=cursor.getString(2);
                if(id==null||id.isEmpty()||name==null||DocumentsContract.Document.MIME_TYPE_DIR.equals(mime))continue;
                try{FolderPolicy.name(name);}catch(IOException ignored){continue;}
                if(!seen.add(name.toLowerCase(Locale.ROOT)))throw new IOException("DUPLICATE_NAME");
                int flags=cursor.isNull(3)?0:cursor.getInt(3);
                long size=cursor.isNull(4)?-1:cursor.getLong(4);
                result.add(new Entry(id,name,(flags&DocumentsContract.Document.FLAG_SUPPORTS_WRITE)!=0,size));
            }
        }
        result.sort((a,b)->a.name.compareToIgnoreCase(b.name));
        return result;
    }
    public synchronized String list() throws Exception {
        List<Entry> entries=entries();StringBuilder out=new StringBuilder();
        out.append("Immediate text files (").append(entries.size()).append("):\n");
        for(Entry entry:entries)out.append(entry.name).append(" (")
                .append(entry.size<0?"size unknown":entry.size+" bytes")
                .append(writeGranted&&entry.writable?", reviewed write":", read only").append(")\n");
        return out.toString();
    }
    private Entry find(String name) throws Exception {
        FolderPolicy.name(name);
        Entry found=null;
        for(Entry entry:entries())if(entry.name.equals(name))found=entry;
        if(found==null)throw new IOException("FILE_NOT_FOUND");
        return found;
    }
    private byte[] readBytes(Entry entry) throws Exception {
        if(entry.size>FolderPolicy.MAX_BYTES)throw new IOException("FILE_TOO_LARGE");
        ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] chunk=new byte[512];
        try(ParcelFileDescriptor fd=app.getContentResolver().openFileDescriptor(document(entry.id),"r")){
            if(fd==null)throw new IOException("PROVIDER_UNAVAILABLE");
            try(FileInputStream in=new FileInputStream(fd.getFileDescriptor())){
                int n;while((n=in.read(chunk))!=-1){
                    if(out.size()+n>FolderPolicy.MAX_BYTES)throw new IOException("FILE_TOO_LARGE");
                    out.write(chunk,0,n);
                }
            }
        }
        return out.toByteArray();
    }
    public synchronized PhoneWorkspace.Snapshot read(String name) throws Exception {
        Entry entry=find(name);byte[] bytes=readBytes(entry);
        return new PhoneWorkspace.Snapshot(FolderPolicy.text(bytes),FolderPolicy.sha(bytes),false);
    }
    public synchronized Proposal propose(String name,String expectedHash,String replacement) throws Exception {
        Entry entry=find(name);
        if(!writeGranted||!entry.writable)throw new IOException("FOLDER_READ_ONLY");
        byte[] current=readBytes(entry);String original=FolderPolicy.text(current);
        if(expectedHash==null||!expectedHash.equals(FolderPolicy.sha(current)))throw new IOException("STALE_FILE");
        FolderPolicy.replacement(replacement);
        String diff="--- "+name+" (current)\n"+original+"\n+++ "+name+" (proposed)\n"+replacement
                +"\nProvider writes may sync and may not be atomic. Only approve this exact replacement.";
        return new Proposal(name,entry.id,expectedHash,replacement,diff);
    }
    public synchronized String apply(Proposal proposal) throws Exception {
        check();Entry entry=find(proposal.name);
        if(!writeGranted||!entry.writable)throw new IOException("FOLDER_READ_ONLY");
        if(!entry.id.equals(proposal.id)||!FolderPolicy.sha(readBytes(entry)).equals(proposal.expectedSha256))
            throw new IOException("STALE_FILE");
        byte[] bytes=FolderPolicy.replacement(proposal.newText);
        ContentResolver resolver=app.getContentResolver();boolean opened=false;
        try{
            try(ParcelFileDescriptor fd=resolver.openFileDescriptor(document(entry.id),"rwt")){
                if(fd==null)throw new IOException("PROVIDER_WRITE_UNAVAILABLE");
                opened=true;
                try(FileOutputStream out=new FileOutputStream(fd.getFileDescriptor())){
                    out.write(bytes);out.flush();
                }
            }
            String hash=FolderPolicy.sha(bytes);
            if(!hash.equals(FolderPolicy.sha(readBytes(find(proposal.name)))))throw new IOException("PROVIDER_VERIFY_FAILED");
            return hash;
        }catch(Exception e){
            if(opened)throw new IOException("WRITE_UNCERTAIN_INSPECT_FILE",e);
            throw e;
        }
    }
}
