// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.security.SecureRandom;
import java.util.zip.CRC32;
import java.util.zip.DeflaterOutputStream;

/** Synthetic pixels only. The answer stays local and is never PNG metadata. */
final class VisualPattern {
    static final int SIZE=300,CELL=100;
    private static final String[] COLORS={"red","green","orange","purple"};
    private static final int[] RGB={0xD62828,0x188C4A,0xE07A12,0x783BA8};
    private static final String[] ROWS={"top","middle","bottom"};
    private static final String[] COLS={"left","center","right"};
    private static final SecureRandom RANDOM=new SecureRandom();
    static final class Challenge {
        final String dataUrl,expected;
        final int cell,color;
        Challenge(String url,String answer,int cell,int color){
            this.dataUrl=url;this.expected=answer;this.cell=cell;this.color=color;
        }
    }
    private VisualPattern(){}

    static Challenge fresh(){return render(RANDOM.nextInt(9),RANDOM.nextInt(RGB.length));}

    /** Package-private deterministic entry point for local pixel tests only. */
    static Challenge render(int cell,int color){
        if(cell<0||cell>=9||color<0||color>=RGB.length)throw new IllegalArgumentException("PATTERN_INVALID");
        byte[] scanlines=new byte[SIZE*(1+SIZE*3)];
        int cursor=0;
        for(int y=0;y<SIZE;y++){
            scanlines[cursor++]=0; // PNG filter type 0
            for(int x=0;x<SIZE;x++){
                int tile=(y/CELL)*3+x/CELL;
                int dx=x%CELL-50,dy=y%CELL-50;
                int edge=Math.min(Math.min(x%CELL,CELL-1-x%CELL),Math.min(y%CELL,CELL-1-y%CELL));
                int rgb=0xFFFFFF;
                if(edge<3)rgb=0xCBD1D8;
                else if(tile==cell){
                    int distance=Math.abs(dx)+Math.abs(dy);
                    if(distance<=35)rgb=distance>29?0x222222:RGB[color];
                }else{
                    int distance=dx*dx+dy*dy;
                    if(distance<=28*28)rgb=distance>24*24?0x222222:0x2368D6;
                }
                scanlines[cursor++]=(byte)(rgb>>>16);
                scanlines[cursor++]=(byte)(rgb>>>8);
                scanlines[cursor++]=(byte)rgb;
            }
        }
        try{
            ByteArrayOutputStream compressed=new ByteArrayOutputStream();
            try(DeflaterOutputStream deflater=new DeflaterOutputStream(compressed)){
                deflater.write(scanlines);
            }
            ByteArrayOutputStream png=new ByteArrayOutputStream();
            png.write(new byte[]{(byte)137,80,78,71,13,10,26,10});
            ByteArrayOutputStream header=new ByteArrayOutputStream();
            u32(header,SIZE);u32(header,SIZE);header.write(new byte[]{8,2,0,0,0});
            chunk(png,"IHDR",header.toByteArray());
            chunk(png,"IDAT",compressed.toByteArray());
            chunk(png,"IEND",new byte[0]);
            byte[] bytes=png.toByteArray();
            String url=PngImageContent.fromPng(bytes);
            String answer=COLORS[color]+" diamond in the "+ROWS[cell/3]+" "+COLS[cell%3]+" cell";
            return new Challenge(url,answer,cell,color);
        }catch(IOException error){throw new IllegalStateException("PATTERN_ENCODING_FAILED",error);}
    }

    private static void chunk(ByteArrayOutputStream png,String name,byte[] payload)throws IOException{
        byte[] type=name.getBytes(java.nio.charset.StandardCharsets.US_ASCII);
        u32(png,payload.length);png.write(type);png.write(payload);
        CRC32 crc=new CRC32();crc.update(type);crc.update(payload);
        u32(png,(int)crc.getValue());
    }
    private static void u32(ByteArrayOutputStream out,int value){
        out.write((value>>>24)&255);out.write((value>>>16)&255);
        out.write((value>>>8)&255);out.write(value&255);
    }
}
