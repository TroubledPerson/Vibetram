// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Handler;
import android.os.Looper;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/** Visible one-request approval adapter for a future HTTPS poller. */
final class RemoteApprovalPrompt implements RemotePhoneSession.Approval {
    private static final Handler MAIN=new Handler(Looper.getMainLooper());
    private final Activity screen;
    private volatile boolean stopped;
    private volatile CountDownLatch pending;
    private volatile AlertDialog dialog;
    RemoteApprovalPrompt(Activity screen){this.screen=screen;}
    void stop(){
        stopped=true;
        CountDownLatch latch=pending;if(latch!=null)latch.countDown();
        MAIN.post(()->{AlertDialog d=dialog;if(d!=null)d.dismiss();});
    }
    public boolean allow(String ownerId,String operation,String name){
        if(stopped)return false;
        CountDownLatch latch=new CountDownLatch(1);AtomicBoolean accepted=new AtomicBoolean(false);
        pending=latch;
        MAIN.post(()->{
            if(stopped||screen.isFinishing()){latch.countDown();return;}
            String subject="LIST".equals(operation)?"List immediate text files":"Read "+name;
            dialog=new AlertDialog.Builder(screen).setTitle("Allow one Longhorn request?")
                    .setMessage(subject+" in the folder you selected. Owner: "+ownerId
                            +". The result can appear in your Codex chat. No write access is requested.")
                    .setNegativeButton("Deny",(d,w)->latch.countDown())
                    .setPositiveButton("Allow once",(d,w)->{accepted.set(true);latch.countDown();})
                    .setOnCancelListener(d->latch.countDown()).show();
        });
        try {if(!latch.await(45,TimeUnit.SECONDS))return false;}
        catch(InterruptedException error){Thread.currentThread().interrupt();return false;}
        finally{
            pending=null;
            MAIN.post(()->{AlertDialog d=dialog;dialog=null;if(d!=null)d.dismiss();});
        }
        return !stopped&&accepted.get();
    }
}
