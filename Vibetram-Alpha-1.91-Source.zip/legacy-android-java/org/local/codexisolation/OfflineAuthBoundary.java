// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

import java.net.URI;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

/** Parent-only, memory-only browser/loopback transaction. No browser or network I/O. */
final class OfflineAuthBoundary {
    interface Clock { long nowSeconds(); }
    static final class Attempt {
        final String state, nonce, verifier, challenge, redirectUri;
        final long deadline;
        private boolean consumed;
        private Attempt(String state, String nonce, String verifier, String redirectUri, long deadline) {
            this.state=state; this.nonce=nonce; this.verifier=verifier;
            this.challenge=sha256Base64(verifier); this.redirectUri=redirectUri; this.deadline=deadline;
        }
        synchronized String accept(String callback, Clock clock) {
            if(consumed) throw new SecurityException("Auth attempt already closed");
            consumed=true; // A bad callback also ends this attempt.
            if(clock.nowSeconds()>=deadline || callback==null || callback.length()>4096)
                throw new SecurityException("Auth callback expired or oversized");
            URI expected=URI.create(redirectUri), got;
            try { got=URI.create(callback); } catch(RuntimeException e) { throw new SecurityException("Invalid callback"); }
            if(!"http".equals(got.getScheme()) || !"127.0.0.1".equals(got.getHost()) ||
                    got.getPort()!=expected.getPort() || !expected.getRawPath().equals(got.getRawPath()) ||
                    got.getRawFragment()!=null || got.getRawUserInfo()!=null || got.getRawQuery()==null)
                throw new SecurityException("Callback origin mismatch");
            Map<String,String> query=new HashMap<>();
            for(String pair:got.getRawQuery().split("&",-1)) {
                String[] bits=pair.split("=",-1);
                if(bits.length!=2 || bits[0].isEmpty()) throw new SecurityException("Invalid callback query");
                String key=decode(bits[0]), value=decode(bits[1]);
                if(query.putIfAbsent(key,value)!=null) throw new SecurityException("Duplicate callback field");
            }
            String suppliedState=query.get("state");
            if(query.size()!=2 || suppliedState==null ||
                    !MessageDigest.isEqual(state.getBytes(StandardCharsets.US_ASCII),suppliedState.getBytes(StandardCharsets.US_ASCII)) ||
                    query.get("code")==null || !query.get("code").matches("[A-Za-z0-9._~-]{1,512}"))
                throw new SecurityException("Callback state or code rejected");
            return query.get("code"); // Only the parent can exchange it in a future, separately authorized flow.
        }
        synchronized void cancel() { consumed=true; }
        synchronized boolean closed() { return consumed; }
    }
    static Attempt begin(int port, Clock clock, SecureRandom random) {
        if(port<1024 || port>65535) throw new SecurityException("Invalid loopback port");
        byte[] state=new byte[32], nonce=new byte[32], verifier=new byte[32];
        random.nextBytes(state); random.nextBytes(nonce); random.nextBytes(verifier);
        return new Attempt(b64(state),b64(nonce),b64(verifier),"http://127.0.0.1:"+port+"/oauth/callback",clock.nowSeconds()+300);
    }
    private static String decode(String text) {
        try { return URLDecoder.decode(text,StandardCharsets.UTF_8.name()); }
        catch(RuntimeException | java.io.UnsupportedEncodingException e) { throw new SecurityException("Invalid query encoding"); }
    }
    private static String b64(byte[] bytes) { return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes); }
    private static String sha256Base64(String value) {
        try { return b64(MessageDigest.getInstance("SHA-256").digest(value.getBytes(StandardCharsets.US_ASCII))); }
        catch(Exception e) { throw new IllegalStateException(e); }
    }
}
