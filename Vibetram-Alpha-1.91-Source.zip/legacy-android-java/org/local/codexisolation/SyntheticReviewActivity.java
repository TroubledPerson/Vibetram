// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.View;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Standalone local synthetic review. No production session, capture API, URI, or transmission. */
public final class SyntheticReviewActivity extends Activity {
    private final Handler main=new Handler(Looper.getMainLooper());
    private SyntheticReviewCoordinator coordinator;
    private SyntheticReviewCoordinator.Ticket ticket;
    private SyntheticReviewCoordinator.Approval approval;
    private Button fresh,request,approveFixture,rejectFixture,crop,redact,review,approvePreview,rejectPreview,stop,end;
    private TextView details;
    private ImageView image;
    private Bitmap bitmap;
    private long displayedRevision=-1;
    private String displayedHash;
    private boolean foreground;
    private boolean fullAccessConfirmationPending;
    private Button requestMode,ruleMode,fullMode,confirmFull;
    private String receipt="";
    private final Runnable expiration=new Runnable(){public void run(){render();if(foreground)main.postDelayed(this,500);}};
    @Override public void onCreate(Bundle saved){
        super.onCreate(saved);coordinator=new SyntheticReviewCoordinator(SystemClock::elapsedRealtime);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setOnApplyWindowInsetsListener((v,insets)->{
            if(android.os.Build.VERSION.SDK_INT>=30){
                android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout());
                v.setPadding(bars.left,bars.top,bars.right,bars.bottom);
            }else v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),
                    insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());
            return insets;
        });
        TextView title=new TextView(this);
        title.setText("1.74 SYNTHETIC-ONLY session modes. Generated pixels only. No real screen capture, sign-in or transmission. "
                +"Approve fixture generation, edit the local preview, then approve its exact bytes locally. "
                +"Only a hash receipt remains after approval. Leaving or unfocusing this screen ends this local review; start a new one explicitly. "
                +"Request approval is more conservative, not guaranteed safe. Approve for me skips only the fixed fixture prompt; final review still asks. "
                +"Full access is higher risk: fixed fixture and exact local receipt need no extra app prompt this session. "
                +"The review button commits the displayed image locally in Full access. Crop/redaction require explicit button taps in every mode. "
                +"Mode changes discard pending work. Android consent cannot be bypassed; no OS route exists here.");
        root.addView(title);
        fresh=button(root,"NEW SYNTHETIC SESSION");request=button(root,"REQUEST SYNTHETIC FIXTURE");
        requestMode=button(root,"Request approval");ruleMode=button(root,"Approve for me");
        fullMode=button(root,"Full access (higher risk, this session)");
        confirmFull=button(root,"CONFIRM FULL ACCESS FOR THIS SYNTHETIC SESSION");
        approveFixture=button(root,"APPROVE FIXTURE ONCE");rejectFixture=button(root,"REJECT FIXTURE");
        image=new ImageView(this);image.setScaleType(ImageView.ScaleType.FIT_CENTER);image.setAdjustViewBounds(true);
        image.setContentDescription("Generated synthetic preview; no external screen content");image.setSaveEnabled(false);
        root.addView(image,new LinearLayout.LayoutParams(-1,(int)(240*getResources().getDisplayMetrics().density)));
        details=new TextView(this);details.setTextIsSelectable(true);details.setSaveEnabled(false);root.addView(details);
        crop=button(root,"CROP TO CENTRAL REGION");redact=button(root,"REDACT CENTRAL RECTANGLE (OPAQUE)");
        review=button(root,"REVIEW EXACT PREVIEW FOR LOCAL APPROVAL");
        approvePreview=button(root,"APPROVE PREVIEW LOCALLY ONCE");rejectPreview=button(root,"REJECT PREVIEW");
        stop=button(root,"STOP SYNTHETIC REVIEW");end=button(root,"END SYNTHETIC SESSION");
        ScrollView scroll=new ScrollView(this);scroll.addView(root);setContentView(scroll);root.requestApplyInsets();
        fresh.setOnClickListener(v->{
            if(!foreground||!hasWindowFocus())return;
            coordinator.close("REPLACED_EXPLICITLY");clearBitmap();
            coordinator=new SyntheticReviewCoordinator(SystemClock::elapsedRealtime);
            coordinator.foreground(true);coordinator.focused(true);ticket=null;approval=null;receipt="";
            fullAccessConfirmationPending=false;render();
        });
        requestMode.setOnClickListener(v->selectMode(SyntheticReviewCoordinator.Mode.REQUEST_APPROVAL,false));
        ruleMode.setOnClickListener(v->selectMode(SyntheticReviewCoordinator.Mode.APPROVE_FOR_ME,false));
        fullMode.setOnClickListener(v->{fullAccessConfirmationPending=true;render();});
        confirmFull.setOnClickListener(v->{if(fullAccessConfirmationPending)
            selectMode(SyntheticReviewCoordinator.Mode.FULL_ACCESS,true);});
        request.setOnClickListener(v->{
            SyntheticReviewCoordinator.Ticket requested=coordinator.requestFixedFixture();
            if(requested!=null)ticket=requested;render();
        });
        approveFixture.setOnClickListener(v->{
            if(coordinator.approveFixture(ticket,true))
                coordinator.acceptSyntheticFrame(ticket,SyntheticReviewRaster.fixture());
            render();
        });
        rejectFixture.setOnClickListener(v->{coordinator.approveFixture(ticket,false);render();});
        crop.setOnClickListener(v->{
            SyntheticReviewCoordinator.Preview preview=coordinator.preview();
            if(preview!=null&&preview.width>=2&&preview.height>=2)
                coordinator.crop(ticket,preview.width/4,preview.height/4,preview.width/2,preview.height/2);
            render();
        });
        redact.setOnClickListener(v->{
            SyntheticReviewCoordinator.Preview preview=coordinator.preview();
            if(preview!=null)coordinator.redact(ticket,preview.width/4,preview.height/4,
                    Math.max(1,preview.width/2),Math.max(1,preview.height/2));
            render();
        });
        review.setOnClickListener(v->{
            if(coordinator.mode()==SyntheticReviewCoordinator.Mode.FULL_ACCESS){
                recordReceipt(coordinator.approveExactByMode(ticket,displayedRevision,displayedHash));
            }else{
                SyntheticReviewCoordinator.Approval requested=coordinator.requestLocalApproval(ticket);
                if(requested!=null)approval=requested;
            }
            render();
        });
        approvePreview.setOnClickListener(v->{
            SyntheticReviewCoordinator.Receipt approved=coordinator.approvePreview(approval,true);
            recordReceipt(approved);
            render();
        });
        rejectPreview.setOnClickListener(v->{coordinator.approvePreview(approval,false);render();});
        stop.setOnClickListener(v->{coordinator.close("STOPPED");render();});
        end.setOnClickListener(v->{coordinator.close("END_SESSION");render();});
        render();
    }
    private void recordReceipt(SyntheticReviewCoordinator.Receipt approved){
        if(approved!=null)receipt="Local approval receipt: revision="+approved.revision+" sha256="+approved.sha256
                +" bytes="+approved.encodedBytes+". Nothing transmitted.";
    }
    private void selectMode(SyntheticReviewCoordinator.Mode selected,boolean confirmed){
        if(coordinator.selectMode(selected,confirmed)){
            ticket=null;approval=null;receipt="";clearBitmap();
        }
        fullAccessConfirmationPending=false;render();
    }
    private Button button(LinearLayout root,String label){Button button=new Button(this);button.setText(label);root.addView(button);return button;}
    private void clearBitmap(){
        if(image!=null)image.setImageDrawable(null);
        if(bitmap!=null){bitmap.recycle();bitmap=null;}displayedRevision=-1;displayedHash=null;
    }
    private void render(){
        if(coordinator==null||image==null)return;
        SyntheticReviewCoordinator.Preview preview=coordinator.preview();
        if(preview==null)clearBitmap();
        else if(displayedRevision!=preview.revision){
            clearBitmap();byte[] png=preview.png();bitmap=BitmapFactory.decodeByteArray(png,0,png.length);
            if(bitmap==null||bitmap.getWidth()!=preview.width||bitmap.getHeight()!=preview.height){
                clearBitmap();coordinator.close("PREVIEW_DECODER_FAILED");preview=null;
            }else{image.setImageBitmap(bitmap);displayedRevision=preview.revision;displayedHash=preview.sha256;}
        }
        SyntheticReviewCoordinator.State state=coordinator.state();
        if(state==SyntheticReviewCoordinator.State.CLOSED||state==SyntheticReviewCoordinator.State.APPROVED_LOCAL){
            preview=null;clearBitmap();
        }
        boolean visible=foreground&&hasWindowFocus();
        boolean policyEditable=visible&&state!=SyntheticReviewCoordinator.State.CLOSED
                &&state!=SyntheticReviewCoordinator.State.APPROVED_LOCAL;
        requestMode.setEnabled(policyEditable&&coordinator.mode()!=SyntheticReviewCoordinator.Mode.REQUEST_APPROVAL);
        ruleMode.setEnabled(policyEditable&&coordinator.mode()!=SyntheticReviewCoordinator.Mode.APPROVE_FOR_ME);
        fullMode.setEnabled(policyEditable&&coordinator.mode()!=SyntheticReviewCoordinator.Mode.FULL_ACCESS);
        if(!policyEditable)fullAccessConfirmationPending=false;
        confirmFull.setVisibility(fullAccessConfirmationPending?View.VISIBLE:View.GONE);
        confirmFull.setEnabled(policyEditable&&fullAccessConfirmationPending);
        fresh.setEnabled(visible);request.setEnabled(visible&&state==SyntheticReviewCoordinator.State.IDLE);
        approveFixture.setEnabled(visible&&state==SyntheticReviewCoordinator.State.FIXTURE_APPROVAL);
        rejectFixture.setEnabled(approveFixture.isEnabled());
        boolean editable=visible&&coordinator.editsRemaining()>0
                &&(state==SyntheticReviewCoordinator.State.PREVIEW||state==SyntheticReviewCoordinator.State.PREVIEW_APPROVAL);
        crop.setEnabled(editable&&preview!=null&&preview.width>=2&&preview.height>=2);redact.setEnabled(editable);
        review.setEnabled(visible&&state==SyntheticReviewCoordinator.State.PREVIEW);
        approvePreview.setEnabled(visible&&state==SyntheticReviewCoordinator.State.PREVIEW_APPROVAL);
        rejectPreview.setEnabled(approvePreview.isEnabled());
        stop.setEnabled(visible&&state!=SyntheticReviewCoordinator.State.CLOSED&&state!=SyntheticReviewCoordinator.State.APPROVED_LOCAL);
        end.setEnabled(stop.isEnabled());
        review.setText(coordinator.mode()==SyntheticReviewCoordinator.Mode.FULL_ACCESS
                ?"APPROVE DISPLAYED PREVIEW LOCALLY (FULL ACCESS)":"REVIEW EXACT PREVIEW FOR LOCAL APPROVAL");
        details.setText("Mode: "+coordinator.mode()+" (this synthetic session only)\nState: "+coordinator.status()+"\n"+(preview==null?"No retained preview.":
                "Exact local PNG: "+preview.width+" x "+preview.height+", "+preview.encodedBytes()+" bytes\nSHA-256: "+preview.sha256
                +"\nPreview revision: "+preview.revision+". Editing invalidates the pending local approval.")
                +"\nEdits remaining="+coordinator.editsRemaining()+"\nFixture approvals="+coordinator.fixtureApprovals()+", accepted frames="+coordinator.acceptedFrames()
                +", local preview approvals="+coordinator.localApprovals()+"\n"+receipt);
    }
    @Override protected void onResume(){super.onResume();foreground=true;coordinator.foreground(true);
        main.removeCallbacks(expiration);main.post(expiration);}
    @Override public void onWindowFocusChanged(boolean focused){super.onWindowFocusChanged(focused);
        if(coordinator!=null){coordinator.focused(focused);render();}}
    @Override protected void onStop(){foreground=false;main.removeCallbacks(expiration);
        coordinator.foreground(false);clearBitmap();super.onStop();}
    @Override protected void onDestroy(){main.removeCallbacks(expiration);coordinator.close("DESTROYED");clearBitmap();super.onDestroy();}
}
