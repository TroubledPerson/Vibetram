// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/** One managed sign-in and, only after Send, one bounded turn in the same parent-owned child. */
final class ManagedOneTurnSession {
    static final String APP_SERVER_SHA256="50d655fd709a44dabede21242f3c01aef2c9cf9c78b5fbfeecd1799555750c09";
    static final String VERIFY_URL="https://auth.openai.com/codex/device";
    private static final int MAX_FRAME=65536,MAX_FRAMES=128,MAX_STDERR=131072,MAX_TEXT=256;
    interface Events { void showCode(String code); void ready(); }
    static final class GateException extends Exception {
        final String code;
        GateException(String code){super(code);this.code=code;}
    }
    static final class Result {
        final String status,text;
        final int deltas;
        Result(String status,String text,int deltas){this.status=status;this.text=text;this.deltas=deltas;}
    }
    private final OfflineAppServerAdapter.ProcessFactory factory;
    private final AtomicBoolean started=new AtomicBoolean(),cancelled=new AtomicBoolean(),sendRequested=new AtomicBoolean();
    private final CountDownLatch sendLatch=new CountDownLatch(1);
    private volatile Process child;
    private volatile String pendingPrompt;
    private volatile String stage="NOT_STARTED";
    private volatile int stderrBytes;
    private int frames,deltas;
    private String loginId,completedLoginId,loginFailureCode,threadId,turnId,agentItemId;
    private boolean loginSuccess,loginCompleted;
    private final StringBuilder answer=new StringBuilder();
    ManagedOneTurnSession(OfflineAppServerAdapter.ProcessFactory factory){this.factory=factory;}
    String stage(){return stage;}
    boolean requestSend(String text){
        if(ShortPromptBoundary.check(text)!=null||!"READY_FOR_SEND".equals(stage)
                ||cancelled.get()||!sendRequested.compareAndSet(false,true))return false;
        pendingPrompt=text;
        sendLatch.countDown();return true;
    }
    void cancel(){cancelled.set(true);sendLatch.countDown();Process p=child;
        if(p!=null)try{p.destroyForcibly();}catch(RuntimeException ignored){}
    }
    Result run(File filesDir,File binary,Events events) throws GateException {
        if(!started.compareAndSet(false,true))throw new GateException("ALREADY_RUN");
        File home=null;Process p=null;ExecutorService readers=Executors.newFixedThreadPool(2);
        try{
            stage="HOME_CHECK";
            File privateDir=filesDir.getCanonicalFile();require(privateDir.isDirectory(),"PRIVATE_FILES_MISSING");
            home=new File(privateDir,"managed-one-turn-v49-"+UUID.randomUUID()).getCanonicalFile();
            require(privateDir.equals(home.getParentFile())&&!home.exists(),"HOME_BOUNDARY_INVALID");
            Files.createDirectory(home.toPath());
            require(binary.isFile()&&binary.canExecute()&&binary.length()==253508688,"APP_SERVER_UNAVAILABLE");
            MessageDigest digest=MessageDigest.getInstance("SHA-256");
            try(InputStream input=Files.newInputStream(binary.toPath())){
                byte[] b=new byte[65536];int n;while((n=input.read(b))!=-1)digest.update(b,0,n);
            }
            require(APP_SERVER_SHA256.equals(hex(digest.digest())),"APP_SERVER_MISMATCH");
            String config="model_provider = \"openai-bounded\"\napproval_policy = \"never\"\n"
                    +"sandbox_mode = \"read-only\"\ncli_auth_credentials_store = \"ephemeral\"\n"
                    +"web_search = \"disabled\"\n[history]\npersistence = \"none\"\n"
                    +"[analytics]\nenabled = false\n"
                    +"[features]\nplugins = false\napps = false\nmulti_agent = false\n"
                    +"goals = false\nshell_tool = false\n"
                    +"[tools.experimental_request_user_input]\nenabled = false\n"
                    +"[tools.update_plan]\nenabled = false\n"
                    +"[agents]\nenabled = false\n[orchestrator.skills]\nenabled = false\n"
                    +"[model_providers.openai-bounded]\nname = \"OpenAI\"\nwire_api = \"responses\"\n"
                    +"requires_openai_auth = true\nrequest_max_retries = 0\nstream_max_retries = 0\n"
                    +"supports_websockets = false\nsupports_standalone_web_search = false\n";
            Files.write(home.toPath().resolve("config.toml"),config.getBytes(StandardCharsets.UTF_8));
            Map<String,String> env=new HashMap<>();env.put("PATH","/system/bin");
            env.put("HOME",home.getPath());env.put("CODEX_HOME",home.getPath());
            stage="PROCESS_START";
            p=factory.start(Arrays.asList(binary.getAbsolutePath(),"--listen","stdio://",
                    "-c","cli_auth_credentials_store=\"ephemeral\"",
                    "-c","features.plugins=false","-c","features.remote_plugin=false",
                    "--disable-plugin-startup-tasks-for-tests"),env);
            child=p;final Process running=p;
            readers.submit(()->{byte[] b=new byte[512];int n;
                try{while((n=running.getErrorStream().read(b))!=-1){stderrBytes+=n;
                    if(stderrBytes>MAX_STDERR){cancel();break;}}}catch(IOException ignored){} });
            InputStream in=p.getInputStream();OutputStream out=p.getOutputStream();
            stage="INITIALIZE";long deadline=afterSeconds(30);
            send(out,"{\"id\":1,\"method\":\"initialize\",\"params\":{\"clientInfo\":{\"name\":\"coretest_one_turn\",\"title\":\"Core Test One Turn\",\"version\":\"0.1\"},\"capabilities\":{\"experimentalApi\":true}}}");
            Map<?,?> init=obj(reply(in,readers,deadline,1).get("result"),"INIT_INVALID");
            require("android".equals(init.get("platformOs"))&&home.getPath().equals(init.get("codexHome")),"INIT_BOUNDARY_INVALID");
            send(out,"{\"method\":\"initialized\"}");
            stage="ACCOUNT_EMPTY";
            send(out,"{\"id\":2,\"method\":\"account/read\",\"params\":{\"refreshToken\":false}}");
            Map<?,?> empty=obj(reply(in,readers,deadline,2).get("result"),"ACCOUNT_INVALID");
            require(empty.containsKey("account")&&empty.get("account")==null,"ACCOUNT_NOT_EMPTY");
            stage="DEVICE_CODE";deadline=afterSeconds(30);
            send(out,"{\"id\":3,\"method\":\"account/login/start\",\"params\":{\"type\":\"chatgptDeviceCode\"}}");
            Map<?,?> login=obj(reply(in,readers,deadline,3).get("result"),"DEVICE_CODE_UNAVAILABLE");
            require("chatgptDeviceCode".equals(login.get("type"))&&VERIFY_URL.equals(login.get("verificationUrl")),"DEVICE_CODE_INVALID");
            loginId=string(login.get("loginId"),"LOGIN_ID_INVALID");
            try{UUID.fromString(loginId);}catch(IllegalArgumentException e){throw new GateException("LOGIN_ID_INVALID");}
            String code=string(login.get("userCode"),"USER_CODE_INVALID");
            require(code.matches("[A-Z0-9-]{4,24}"),"USER_CODE_INVALID");
            events.showCode(code);
            stage="WAIT_FOR_USER";deadline=afterSeconds(15*60);
            while(!loginCompleted)notification(frame(in,readers,deadline));
            require(loginId.equals(completedLoginId),"LOGIN_ID_MISMATCH");
            require(loginSuccess,loginFailureCode==null?"LOGIN_NOT_COMPLETED":loginFailureCode);
            stage="ACCOUNT_CONFIRM";deadline=afterSeconds(20);
            send(out,"{\"id\":4,\"method\":\"account/read\",\"params\":{\"refreshToken\":false}}");
            Map<?,?> account=obj(reply(in,readers,deadline,4).get("result"),"ACCOUNT_INVALID");
            require("chatgpt".equals(obj(account.get("account"),"ACCOUNT_INVALID").get("type")),"ACCOUNT_NOT_CHATGPT");
            stage="READY_FOR_SEND";events.ready();
            require(sendLatch.await(3,TimeUnit.MINUTES)&&sendRequested.get()&&!cancelled.get(),"SEND_NOT_REQUESTED");
            String requestText=pendingPrompt;
            pendingPrompt=null;
            require(ShortPromptBoundary.check(requestText)==null,"PROMPT_INVALID");
            stage="THREAD_START";deadline=afterSeconds(30);
            send(out,"{\"id\":5,\"method\":\"thread/start\",\"params\":{\"cwd\":"+quote(home.getPath())
                    +",\"approvalPolicy\":\"never\",\"sandbox\":\"read-only\",\"ephemeral\":true,\"environments\":[],"
                    +"\"developerInstructions\":\"Reply concisely in at most 256 characters. No tools or file access.\"}}");
            Map<?,?> thread=obj(reply(in,readers,deadline,5).get("result"),"THREAD_INVALID");
            threadId=string(obj(thread.get("thread"),"THREAD_INVALID").get("id"),"THREAD_INVALID");
            require(threadId.length()<=64,"THREAD_INVALID");
            stage="TURN_START";deadline=afterSeconds(60);
            send(out,"{\"id\":6,\"method\":\"turn/start\",\"params\":{\"threadId\":"+quote(threadId)
                    +",\"input\":[{\"type\":\"text\",\"text\":"+quote(requestText)+",\"textElements\":[]}]}}");
            Map<?,?> turn=obj(reply(in,readers,deadline,6).get("result"),"TURN_INVALID");
            turnId=string(obj(turn.get("turn"),"TURN_INVALID").get("id"),"TURN_INVALID");
            require(turnId.length()<=64,"TURN_INVALID");
            stage="STREAM";String status=null;
            for(int i=0;i<MAX_FRAMES&&status==null;i++)status=notification(frame(in,readers,deadline));
            require("completed".equals(status),"TURN_NOT_COMPLETED");
            require(answer.length()>0&&answer.length()<=MAX_TEXT&&stderrBytes<=MAX_STDERR,"ANSWER_INVALID");
            stage="COMPLETE";return new Result(status,answer.toString(),deltas);
        }catch(GateException e){throw e;}
        catch(Exception e){throw new GateException(cancelled.get()?"CANCELLED":"SESSION_STOPPED");}
        finally{
            pendingPrompt=null;
            if(p!=null){p.destroyForcibly();try{if(!p.waitFor(2,TimeUnit.SECONDS)||p.isAlive())throw new GateException("CHILD_STILL_RUNNING");}
                catch(InterruptedException e){Thread.currentThread().interrupt();throw new GateException("CHILD_STILL_RUNNING");}}
            child=null;readers.shutdownNow();
            if(home!=null&&new File(home,"auth.json").exists()){
                try{Files.deleteIfExists(new File(home,"auth.json").toPath());}catch(IOException ignored){}
                throw new GateException("CREDENTIAL_FILE_CREATED");
            }
        }
    }
    private Map<?,?> reply(InputStream in,ExecutorService readers,long deadline,int id) throws Exception{
        for(int i=0;i<MAX_FRAMES;i++){
            Map<?,?> frame=frame(in,readers,deadline);
            if(frame.containsKey("id")){
                require(BigDecimal.valueOf(id).equals(frame.get("id"))&&!frame.containsKey("error"),"RPC_REJECTED");
                return frame;
            }
            require(notification(frame)==null,"PREMATURE_COMPLETION");
        }
        throw new GateException("REPLY_MISSING");
    }
    private String notification(Map<?,?> frame) throws GateException{
        require(!frame.containsKey("id"),"UNREQUESTED_SERVER_CALL");
        String method=string(frame.get("method"),"METHOD_INVALID");
        Map<?,?> params=obj(frame.get("params"),"NOTIFICATION_INVALID");
        if("account/login/completed".equals(method)){
            completedLoginId=string(params.get("loginId"),"LOGIN_ID_INVALID");
            loginSuccess=Boolean.TRUE.equals(params.get("success"));
            if(!loginSuccess)loginFailureCode=completionFailureCode(params.get("error"));
            loginCompleted=true;return null;
        }
        if("item/started".equals(method)||"item/completed".equals(method)){
            require(threadId!=null&&turnId!=null&&threadId.equals(params.get("threadId"))
                    &&turnId.equals(params.get("turnId")),"ITEM_IDS_INVALID");
            Map<?,?> item=obj(params.get("item"),"ITEM_INVALID");
            String type=string(item.get("type"),"ITEM_INVALID");
            require("userMessage".equals(type)||"agentMessage".equals(type)||"reasoning".equals(type),"TOOL_ITEM_REJECTED");
            if("agentMessage".equals(type)){
                String id=string(item.get("id"),"ITEM_ID_INVALID");require(id.length()<=64,"ITEM_ID_INVALID");
                if("item/started".equals(method))agentItemId=id;
                else{require(id.equals(agentItemId),"ITEM_ID_INVALID");
                    Object text=item.get("text");if(text instanceof String){
                        require(((String)text).length()<=MAX_TEXT,"ANSWER_OVERSIZE");
                        if(answer.length()==0)answer.append((String)text);
                        else require(answer.toString().equals(text),"ANSWER_MISMATCH");
                    }}
            }
            return null;
        }
        if("item/agentMessage/delta".equals(method)){
            require(threadId!=null&&turnId!=null&&threadId.equals(params.get("threadId"))
                    &&turnId.equals(params.get("turnId"))&&agentItemId!=null
                    &&agentItemId.equals(params.get("itemId")),"DELTA_IDS_INVALID");
            String delta=string(params.get("delta"),"DELTA_INVALID");
            require(delta.length()<=MAX_TEXT&&++deltas<=32&&answer.length()+delta.length()<=MAX_TEXT,"ANSWER_OVERSIZE");
            answer.append(delta);return null;
        }
        if("turn/completed".equals(method)){
            require(threadId!=null&&threadId.equals(params.get("threadId")),"COMPLETION_ID_INVALID");
            Map<?,?> turn=obj(params.get("turn"),"COMPLETION_INVALID");
            require(turnId!=null&&turnId.equals(turn.get("id")),"COMPLETION_ID_INVALID");
            return string(turn.get("status"),"COMPLETION_INVALID");
        }
        require("remoteControl/status/changed".equals(method)||"account/updated".equals(method)
                ||"thread/started".equals(method)||"warning".equals(method)||"configWarning".equals(method)
                ||"thread/status/changed".equals(method)||"turn/started".equals(method)
                ||"thread/tokenUsage/updated".equals(method)||"account/rateLimits/updated".equals(method)
                ||method.startsWith("item/reasoning/"),"UNEXPECTED_NOTIFICATION");
        return null;
    }
    private Map<?,?> frame(InputStream in,ExecutorService readers,long deadline) throws Exception{
        require(!cancelled.get()&&++frames<=MAX_FRAMES,"CANCELLED_OR_TOO_MANY_FRAMES");
        long remaining=deadline-System.nanoTime();require(remaining>0,"SESSION_TIMEOUT");
        byte[] line=readers.submit(()->readLine(in)).get(remaining,TimeUnit.NANOSECONDS);
        return obj(BoundedJson.parse(line),"FRAME_INVALID");
    }
    private static byte[] readLine(InputStream in) throws IOException{
        ByteArrayOutputStream bytes=new ByteArrayOutputStream();
        while(bytes.size()<MAX_FRAME){int b=in.read();if(b<0)throw new IOException("EOF");
            if(b=='\n')return bytes.toByteArray();bytes.write(b);}
        throw new IOException("FRAME_OVERSIZE");
    }
    private static void send(OutputStream out,String value) throws IOException{
        out.write((value+"\n").getBytes(StandardCharsets.UTF_8));out.flush();
    }
    private static long afterSeconds(long seconds){return System.nanoTime()+TimeUnit.SECONDS.toNanos(seconds);}
    private static String quote(String value){return "\""+value.replace("\\","\\\\").replace("\"","\\\"")+"\"";}
    private static Map<?,?> obj(Object value,String code) throws GateException{
        if(!(value instanceof Map))throw new GateException(code);return (Map<?,?>)value;
    }
    private static String string(Object value,String code) throws GateException{
        if(!(value instanceof String))throw new GateException(code);return (String)value;
    }
    private static String completionFailureCode(Object rawError){
        if(!(rawError instanceof String))return "LOGIN_NOT_COMPLETED";
        String error=(String)rawError;
        String typed=NativePollDetail.classify(error);
        if(typed!=null)return typed;
        // These fixed phase markers are emitted by the pinned diagnostic native
        // build. They carry no HTTP body, token, account value, or error text.
        if("CORETEST_AUTH_CLIENT_INIT_FAILED".equals(error))return "AUTH_CLIENT_INIT_FAILED";
        if("CORETEST_DEVICE_POLL_FAILED".equals(error))return "DEVICE_POLL_FAILED";
        if("CORETEST_POLL_REQUEST_BUILD_FAILED".equals(error))return "POLL_REQUEST_BUILD_FAILED";
        if("CORETEST_POLL_TRANSPORT_FAILED".equals(error))return "POLL_TRANSPORT_FAILED";
        if("CORETEST_POLL_TRANSPORT_TIMEOUT".equals(error))return "POLL_TRANSPORT_TIMEOUT";
        if("CORETEST_POLL_CONNECT_AFTER_REDIRECT".equals(error))return "POLL_CONNECT_AFTER_REDIRECT";
        if("CORETEST_POLL_CONNECT_NO_REDIRECT".equals(error))return "POLL_CONNECT_NO_REDIRECT";
        if("CORETEST_POLL_CONNECT_FIRST_SEND_NO_REDIRECT".equals(error))return "POLL_CONNECT_FIRST_SEND_NO_REDIRECT";
        if("CORETEST_POLL_CONNECT_AFTER_PENDING_NO_REDIRECT".equals(error))return "POLL_CONNECT_AFTER_PENDING_NO_REDIRECT";
        if("CORETEST_POLL_CONNECT_FIRST_SEND_AFTER_REDIRECT".equals(error))return "POLL_CONNECT_FIRST_SEND_AFTER_REDIRECT";
        if("CORETEST_POLL_CONNECT_AFTER_PENDING_AFTER_REDIRECT".equals(error))return "POLL_CONNECT_AFTER_PENDING_AFTER_REDIRECT";
        if("CORETEST_POLL_TRANSPORT_OTHER_FAILED".equals(error))return "POLL_TRANSPORT_OTHER_FAILED";
        if("CORETEST_POLL_RESPONSE_SCHEMA_FAILED".equals(error))return "POLL_RESPONSE_SCHEMA_FAILED";
        if("CORETEST_POLL_EXPIRED".equals(error))return "POLL_EXPIRED";
        if("CORETEST_POLL_RATE_LIMITED".equals(error))return "POLL_RATE_LIMITED";
        if("CORETEST_POLL_HTTP_REJECTED".equals(error))return "POLL_HTTP_REJECTED";
        if("CORETEST_TOKEN_EXCHANGE_FAILED".equals(error))return "TOKEN_EXCHANGE_FAILED";
        if("CORETEST_WORKSPACE_REJECTED".equals(error))return "WORKSPACE_REJECTED";
        if("CORETEST_EPHEMERAL_STORE_FAILED".equals(error))return "EPHEMERAL_STORE_FAILED";
        // The pinned server supplies this text. Match known source phrases only;
        // never log, retain, or display its raw content, which may contain secrets.
        if("Login was not completed".equals(error))return "SERVER_CANCELLED_LOGIN";
        if("account changed before sign-in completed".equals(error))return "ACCOUNT_CHANGED_AFTER_AUTH";
        if("device auth timed out after 15 minutes".equals(error))return "DEVICE_POLL_TIMEOUT";
        if(error.startsWith("device auth failed with status "))return "DEVICE_POLL_REJECTED";
        if(error.startsWith("device code exchange failed:"))return "TOKEN_EXCHANGE_FAILED";
        if(error.startsWith("workspace routing ")
                || error.startsWith("selected workspace ")
                || error.startsWith("failed to load workspace requirements")
                || error.startsWith("failed to reload workspace requirements")
                || error.startsWith("configuration changed during workspace routing discovery")){
            return "POST_LOGIN_ACCOUNT_CHECK_FAILED";
        }
        return "LOGIN_NOT_COMPLETED";
    }
    private static void require(boolean ok,String code) throws GateException{if(!ok)throw new GateException(code);}
    private static String hex(byte[] bytes){StringBuilder out=new StringBuilder();
        for(byte b:bytes)out.append(String.format(java.util.Locale.ROOT,"%02x",b&255));return out.toString();}
}
