// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

import java.util.Base64;
import java.util.zip.CRC32;

/** Bounded inline PNG content for a dynamic-tool reply; no capture or network fetch. */
final class PngImageContent {
    static final int MAX_PNG_BYTES=32*1024;
    static final String PREFIX="data:image/png;base64,";
    private static final byte[] SIGNATURE={(byte)137,80,78,71,13,10,26,10};
    private static final String FIXTURE_BASE64=
            "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR4nGP4z8DwHwAFAAH/iZk9HQAAAABJRU5ErkJggg==";

    private PngImageContent(){}

    static String fixedDataUrl(){
        return fromPng(Base64.getDecoder().decode(FIXTURE_BASE64));
    }

    static String fromPng(byte[] png){
        if(png==null||png.length<57||png.length>MAX_PNG_BYTES)throw invalid();
        for(int i=0;i<SIGNATURE.length;i++)if(png[i]!=SIGNATURE[i])throw invalid();
        int offset=SIGNATURE.length,chunks=0;
        boolean hasIdat=false,hasIend=false;
        while(offset<png.length){
            if(png.length-offset<12||++chunks>64)throw invalid();
            long dataLength=u32(png,offset);
            if(dataLength>MAX_PNG_BYTES||dataLength>png.length-offset-12)throw invalid();
            int type=offset+4,data=offset+8,end=data+(int)dataLength;
            for(int i=type;i<type+4;i++){
                int c=png[i]&255;
                if(!((c>='A'&&c<='Z')||(c>='a'&&c<='z')))throw invalid();
            }
            CRC32 crc=new CRC32();crc.update(png,type,4+(int)dataLength);
            if(crc.getValue()!=u32(png,end))throw invalid();
            if(chunks==1){
                if(!chunk(png,type,"IHDR")||dataLength!=13)throw invalid();
                long width=u32(png,data),height=u32(png,data+4);
                if(width<1||width>4096||height<1||height>4096)throw invalid();
            }else if(chunk(png,type,"IHDR"))throw invalid();
            if(chunk(png,type,"IDAT")){
                if(dataLength==0||hasIend)throw invalid();
                hasIdat=true;
            }
            if(chunk(png,type,"IEND")){
                if(dataLength!=0||!hasIdat||end+4!=png.length)throw invalid();
                hasIend=true;
            }
            offset=end+4;
        }
        if(!hasIend)throw invalid();
        return PREFIX+Base64.getEncoder().encodeToString(png);
    }

    static String requireDataUrl(String url){
        int maxLength=PREFIX.length()+((MAX_PNG_BYTES+2)/3)*4;
        if(url==null||!url.startsWith(PREFIX)||url.length()>maxLength)throw invalid();
        try{
            byte[] png=Base64.getDecoder().decode(url.substring(PREFIX.length()));
            String canonical=fromPng(png);
            if(!canonical.equals(url))throw invalid();
            return canonical;
        }catch(IllegalArgumentException error){throw invalid();}
    }

    private static boolean chunk(byte[] png,int offset,String name){
        for(int i=0;i<4;i++)if(png[offset+i]!=(byte)name.charAt(i))return false;
        return true;
    }
    private static long u32(byte[] bytes,int offset){
        return ((long)(bytes[offset]&255)<<24)|((long)(bytes[offset+1]&255)<<16)
                |((long)(bytes[offset+2]&255)<<8)|(bytes[offset+3]&255);
    }
    private static IllegalArgumentException invalid(){return new IllegalArgumentException("PNG_IMAGE_INVALID");}
}
