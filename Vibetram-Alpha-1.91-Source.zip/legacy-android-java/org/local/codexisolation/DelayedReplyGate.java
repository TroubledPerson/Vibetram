// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;
import java.util.Arrays;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/** Test-only second-reply hold. No capability lock is held while waiting. */
final class DelayedReplyGate {
    static final long WAIT_MS=1200,DELAY_MS=200;
    private final GrantState.Clock clock;
    private final CountDownLatch release=new CountDownLatch(1);
    private boolean entered,revoked,released,returned,timedOut,aborted,invalid,rejectionConfirmed;
    private int sequence,entryOrder,revokeOrder,releaseOrder,commitOrder,rejectOrder,sinkEntries;
    private long entryMs=-1,revokeMs=-1,releaseMs=-1,returnMs=-1;
    private byte[] noteHash;
    DelayedReplyGate(GrantState.Clock clock){this.clock=clock;}
    boolean hold(ModelState state,byte[] reply,Runnable announce){
        synchronized(this){
            if(entered||aborted){invalid=true;return false;}
            ModelPolicy.validateReply(2,reply);entered=true;entryOrder=++sequence;entryMs=clock.now();
            noteHash=GrantState.digest(Arrays.copyOfRange(reply,16,92));
        }
        try{
            announce.run();
            if(!release.await(WAIT_MS,TimeUnit.MILLISECONDS)){timeout(state);return false;}
        }catch(InterruptedException interrupted){Thread.currentThread().interrupt();cleanup(state);return false;
        }catch(RuntimeException rejected){cleanup(state);return false;}
        synchronized(this){
            returnMs=clock.now();
            if(returnMs-entryMs>=WAIT_MS){timedOut=true;aborted=true;}
            returned=revoked&&released&&!aborted&&!invalid;return returned;
        }
    }
    boolean revokeAndRelease(ModelState state){
        // Never hold the gate lock while acquiring the capability lock.
        state.revoke();
        synchronized(this){
            long now=clock.now();
            if(!entered||released||aborted||now-entryMs<DELAY_MS||now-entryMs>=WAIT_MS){invalid=true;aborted=true;if(entered&&now-entryMs>=WAIT_MS)timedOut=true;release.countDown();return false;}
            revoked=true;revokeOrder=++sequence;revokeMs=now;
            released=true;releaseOrder=++sequence;releaseMs=clock.now();release.countDown();return true;
        }
    }
    private void timeout(ModelState state){state.revoke();synchronized(this){timedOut=true;aborted=true;release.countDown();}}
    void cleanup(ModelState state){state.revoke();synchronized(this){if(!released)aborted=true;release.countDown();}}
    boolean waitSignalled(){return release.getCount()==0;}
    synchronized void beforeCommit(boolean revokedUnexpired){
        if(!returned||!revokedUnexpired||commitOrder!=0){invalid=true;throw new SecurityException("Delayed commit unavailable");}
        commitOrder=++sequence;
    }
    synchronized void sinkEntered(){sinkEntries++;invalid=true;throw new SecurityException("Late reply sink reached");}
    synchronized void rejected(boolean confirmed){
        if(commitOrder==0||rejectOrder!=0){invalid=true;return;}
        rejectOrder=++sequence;rejectionConfirmed=confirmed;
    }
    synchronized boolean proven(byte[] expectedNote){
        return entered&&revoked&&released&&returned&&!timedOut&&!aborted&&!invalid&&rejectionConfirmed&&sinkEntries==0
            &&entryOrder==1&&revokeOrder==2&&releaseOrder==3&&commitOrder==4&&rejectOrder==5
            &&expectedNote!=null&&Arrays.equals(noteHash,expectedNote);
    }
    synchronized String report(){return "held="+entered+" revoked="+revoked+" released="+released+" returned="+returned
        +" timedOut="+timedOut+" aborted="+aborted+" order="+entryOrder+","+revokeOrder+","+releaseOrder+","+commitOrder+","+rejectOrder
        +" rejectionConfirmed="+rejectionConfirmed+" secondSinkEntries="+sinkEntries
        +" holdMs="+(returnMs<0||entryMs<0?-1:returnMs-entryMs)+" revokeAfterMs="+(revokeMs<0||entryMs<0?-1:revokeMs-entryMs)
        +" releaseAfterMs="+(releaseMs<0||entryMs<0?-1:releaseMs-entryMs);}
}
