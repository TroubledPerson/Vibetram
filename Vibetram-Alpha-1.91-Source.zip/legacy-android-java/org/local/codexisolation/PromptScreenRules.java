// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

/** Small host-testable rules for the prompt field and explicit Send control. */
final class PromptScreenRules {
    private PromptScreenRules(){}
    static boolean inputEnabled(boolean sent){return !sent;}
    static boolean sendEnabled(boolean ready,boolean sent,boolean done){
        return ready&&!sent&&!done;
    }
    static boolean resetEnabled(boolean settled,boolean restoredWithoutProcess){
        return settled||restoredWithoutProcess;
    }
}
