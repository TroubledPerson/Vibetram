// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

/** Decides when a user-requested system picker may open without changing a live tool scope. */
final class FolderPickerFlow {
    enum Action { OPEN_NOW, WAIT_FOR_TURN, WAIT_FOR_APPROVAL, CONFIRM_END, QUEUE_AFTER_END }
    private FolderPickerFlow(){}
    static Action action(boolean active,boolean settled,boolean inFlight,boolean approvalPending,boolean userEnded){
        if(!active||settled)return Action.OPEN_NOW;
        if(inFlight)return Action.WAIT_FOR_TURN;
        if(approvalPending)return Action.WAIT_FOR_APPROVAL;
        return userEnded?Action.QUEUE_AFTER_END:Action.CONFIRM_END;
    }
    static boolean acceptPickerResult(boolean active,boolean settled){return !active||settled;}
    static boolean openAfterEnd(boolean requested,boolean settled,boolean hasScreen){
        return requested&&settled&&hasScreen;
    }
}
