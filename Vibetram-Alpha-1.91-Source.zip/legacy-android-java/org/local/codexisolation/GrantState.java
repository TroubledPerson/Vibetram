// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Shared authority state; test-only expiry transitions are explicit and synchronized. */
final class GrantState {
    interface Clock { long now(); }
    interface ExpiryClock extends Clock { Advance advanceIfBefore(long deadline); }
    static final class Advance {
        final long before, after;
        final boolean applied;
        Advance(long before, long after, boolean applied) {
            this.before = before; this.after = after; this.applied = applied;
        }
    }
    static final class Gate {
        final String outcome;
        final long decisionMs, expiryMs, afterMs;
        Gate(String outcome, long decisionMs, long expiryMs, long afterMs) {
            this.outcome = outcome; this.decisionMs = decisionMs;
            this.expiryMs = expiryMs; this.afterMs = afterMs;
        }
        boolean applied() { return outcome.equals("CANCEL_APPLIED") || outcome.equals("EXPIRY_APPLIED"); }
        public String toString() { return outcome + " decisionGrantMs=" + decisionMs
                + " expiryGrantMs=" + expiryMs + " afterGrantMs=" + afterMs; }
    }
    interface Reply { void serialize(byte[] note); }
    private final Clock clock;
    private final long expiry;
    private final long generation;
    private final int parentUid;
    private final byte[] token, expected;
    private byte[] note;
    private boolean active = true, traceOverflow;
    private int uid = -1, attempts, reads, serialized, denied, accepted;
    private final List<String> events = new ArrayList<>();
    GrantState(Clock clock, long generation, int parentUid, byte[] token, byte[] note) {
        this.clock = clock; this.expiry = clock.now() + 15000;
        this.generation = generation; this.parentUid = parentUid;
        this.token = token.clone(); this.note = note.clone(); this.expected = digest(note);
    }
    static byte[] digest(byte[] bytes) {
        try { return MessageDigest.getInstance("SHA-256").digest(bytes); }
        catch (java.security.NoSuchAlgorithmException impossible) { throw new AssertionError(impossible); }
    }
    private void event(String value) {
        eventAt(value, clock.now());
    }
    private void eventAt(String value, long decisionMs) {
        if (events.size() >= 64) {
            traceOverflow = true; active = false;
            if (note != null) Arrays.fill(note, (byte) 0);
            note = null;
            events.set(63, "TRACE_OVERFLOW");
            throw new SecurityException("TRACE_OVERFLOW");
        }
        events.add("monoMs=" + System.nanoTime() / 1000000 + ":grantMs=" + decisionMs + ":" + value);
    }
    private void reject(String reason) {
        denied++; event("DENY:" + reason); throw new SecurityException(reason);
    }
    synchronized void malformed() { attempts++; reject("PARCEL"); }
    synchronized void read(byte[] supplied, long requestedGeneration, int request, int caller,
                           int flags, Reply reply) {
        attempts++; event("READ_ENTER");
        if ((flags & 1) != 0) reject("ONEWAY");
        if (!active) reject("REVOKED");
        if (clock.now() >= expiry) reject("EXPIRED");
        if (requestedGeneration != generation) reject("GENERATION");
        if (request != 1) reject("REQUEST");
        if (!MessageDigest.isEqual(token, supplied)) reject("TOKEN");
        if (caller == parentUid || (uid != -1 && uid != caller)) reject("UID");
        if (reads != 0) reject("REPLAY");
        uid = caller; reads++; event("AUTHORIZED");
        // Serialization remains inside the authority lock, exactly as in 1.1.
        // The adapter must not block; no test gate is placed in this callback.
        reply.serialize(note.clone());
        serialized++; event("SERIALIZED");
    }
    synchronized void revoke() {
        if (active) {
            active = false;
            if (note != null) Arrays.fill(note, (byte) 0);
            note = null;
            // Cleanup must remain non-throwing even if diagnostic capacity is exhausted.
            try { event("REVOKED"); } catch (SecurityException overflow) { /* Already inactive/cleared. */ }
        }
    }
    synchronized boolean preliminary(byte[] hash) {
        return active && clock.now() < expiry && reads == 1 && serialized == 1 && uid >= 0
                && hash != null && MessageDigest.isEqual(expected, hash);
    }
    private String invalidTransition(byte[] hash, long currentGeneration) {
        return traceOverflow ? "TRACE_FAILED" : currentGeneration != generation ? "GENERATION"
                : !active ? "REVOKED" : accepted != 0 ? "ALREADY_ACCEPTED"
                : reads != 1 || serialized != 1 || uid < 0 || hash == null
                || !MessageDigest.isEqual(expected, hash) ? "HASH_OR_READ" : null;
    }
    private Gate recordGate(String outcome, long before, long after) {
        Gate gate = new Gate(outcome, before, expiry, after);
        try { eventAt("GATE:" + gate, before); }
        catch (SecurityException overflow) { return new Gate("TRACE_FAILED", before, expiry, after); }
        return gate;
    }
    synchronized Gate cancelIfEligible(byte[] hash, long currentGeneration) {
        String invalid = invalidTransition(hash, currentGeneration);
        long decision = clock.now();
        if (invalid != null) return recordGate(invalid, decision, decision);
        if (decision >= expiry) return recordGate("NATURAL_EXPIRY", decision, decision);
        // The eligibility sample is the transition's linearization point, under this lock.
        active = false;
        Arrays.fill(note, (byte) 0); note = null;
        return recordGate("CANCEL_APPLIED", decision, decision);
    }
    synchronized Gate expireIfEligible(byte[] hash, long currentGeneration) {
        String invalid = invalidTransition(hash, currentGeneration);
        if (invalid != null) { long now = clock.now(); return recordGate(invalid, now, now); }
        if (!(clock instanceof ExpiryClock adjustable)) {
            long now = clock.now(); return recordGate("CLOCK_NOT_ADJUSTABLE", now, now);
        }
        // The clock samples eligibility and mutates its offset in one clock critical section.
        Advance step = adjustable.advanceIfBefore(expiry);
        return recordGate(step.applied ? "EXPIRY_APPLIED" : "NATURAL_EXPIRY", step.before, step.after);
    }
    synchronized boolean finish(byte[] hash, long currentGeneration) {
        if (traceOverflow) return false;
        String reason = currentGeneration != generation ? "GENERATION"
                : !active ? "REVOKED" : clock.now() >= expiry ? "EXPIRED"
                : accepted != 0 ? "DUPLICATE_RESULT" : !preliminary(hash) ? "HASH_OR_READ" : null;
        if (reason != null) {
            try { event("SUPPRESS:" + reason); } catch (SecurityException overflow) { /* Fail closed. */ }
            return false;
        }
        try { event("ACCEPTED"); } catch (SecurityException overflow) { return false; }
        accepted++; return true;
    }
    synchronized int[] counts() { return new int[]{attempts, reads, serialized, denied, accepted}; }
    synchronized int pinnedUid() { return uid; }
    synchronized boolean traceOverflowed() { return traceOverflow; }
    synchronized String trace() { return String.join(",", events); }
}
