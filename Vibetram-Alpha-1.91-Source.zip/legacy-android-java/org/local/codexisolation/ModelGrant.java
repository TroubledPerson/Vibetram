// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;
import android.os.*;
import java.security.SecureRandom;

final class ModelGrant extends Binder {
    static final String DESCRIPTOR="org.local.codexisolation.model.fixture.v1";
    static final int EXCHANGE=IBinder.FIRST_CALL_TRANSACTION,MAX_PARCEL=70000;
    final byte[] token=new byte[32];final long generation;final ModelState state;
    private final DelayedReplyGate gate;private final Runnable onHeld;
    ModelGrant(long generation,DelayedReplyGate gate,Runnable onHeld){new SecureRandom().nextBytes(token);this.generation=generation;state=new ModelState(token,generation,android.os.Process.myUid(),SystemClock::elapsedRealtime);this.gate=gate;this.onHeld=onHeld;}
    @Override protected boolean onTransact(int code,Parcel in,Parcel out,int flags)throws RemoteException {
        ModelState.Stage stage=ModelState.Stage.TRANSACTION;state.observeTransaction(flags);
        try{
            if(code!=EXCHANGE||out==null||!ModelState.synchronousFlags(flags)||in.dataSize()>MAX_PARCEL)throw new SecurityException("Model transaction");
            stage=ModelState.Stage.ENVELOPE;
            in.enforceInterface(DESCRIPTOR);byte[] supplied=new byte[32];in.readByteArray(supplied);long gen=in.readLong();int id=in.readInt();int length=in.readInt();
            if(length<10||length>ModelPolicy.MAX_WIRE||in.dataAvail()!=4+((length+3)&~3))throw new SecurityException("Model request bounds");
            byte[] request=new byte[length];in.readByteArray(request);if(in.dataAvail()!=0)throw new SecurityException("Model trailing request");
            stage=ModelState.Stage.AUTHORITY;int ticket=state.begin(supplied,gen,id,Binder.getCallingUid(),flags,request);
            stage=ModelState.Stage.POLICY;
            byte[] reply=ModelPolicy.reply(id,request);
            if(id==2){stage=ModelState.Stage.HOLD;if(!gate.hold(state,reply,onHeld))throw new SecurityException("Second reply hold ended");}
            stage=ModelState.Stage.COMMIT;
            if(id==2)gate.beforeCommit(state.revokedPendingSecond());
            try{state.commit(ticket,reply,bytes->{if(id==2)gate.sinkEntered();out.writeNoException();out.writeLong(gen);out.writeInt(id);out.writeInt(bytes.length);out.writeByteArray(bytes);});}
            catch(SecurityException rejected){if(id==2)gate.rejected(state.revokedSecondRejected());throw rejected;}return true;
        }catch(RuntimeException e){state.malformed(stage);throw new SecurityException("Model capability rejected");}
    }
}
