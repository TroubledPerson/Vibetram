// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Parcel;
import android.os.RemoteException;
import android.os.SystemClock;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.UUID;

/** One synthetic auth/parser test per Activity lifetime; no browser or network access. */
public final class OfflineFixtureActivity extends Activity {
    private final Handler main=new Handler(Looper.getMainLooper());
    private final Runnable deadline=()->finish(false,"PARENT_DEADLINE_8S");
    private RunOnceState once;
    private ReportBuffer buffer;
    private TextView report;
    private Button run;
    private ServiceConnection connection;
    private boolean bound,completed,destroyed,invoked;
    private long started;

    private void log(String line){
        if(destroyed)return;
        if(!buffer.append("+"+(SystemClock.elapsedRealtime()-started)+"ms "+line)){
            completed=true;cleanup();return;
        }
        report.setText(buffer.snapshot());
    }
    @Override public void onCreate(Bundle saved){
        super.onCreate(saved);
        boolean restored=saved!=null && saved.getBoolean("attempted",false);
        once=new RunOnceState(restored);if(!restored)once.select();
        String header="1.15 offline fixture; JavaSHA="+BuildEvidence.SOURCE_ID
                +"\nSynthetic callback and split UTF-8 SSE; no browser, listener, token, or provider.";
        buffer=new ReportBuffer(restored?saved.getString("report",header):header);
        LinearLayout layout=new LinearLayout(this);layout.setOrientation(LinearLayout.VERTICAL);layout.setFitsSystemWindows(true);
        run=new Button(this);run.setText(restored?"REPORT ONLY":"RUN OFFLINE FIXTURE ONCE");run.setEnabled(!restored);
        run.setOnClickListener(v->start());layout.addView(run);
        Button stop=new Button(this);stop.setText("STOP (inconclusive)");
        stop.setOnClickListener(v->{if(once.attempted())finish(false,"MANUAL_STOP");});layout.addView(stop);
        Button copy=new Button(this);copy.setText("COPY OFFLINE REPORT");copy.setOnClickListener(v->{
            ClipboardManager clipboard=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
            clipboard.setPrimaryClip(ClipData.newPlainText("Codex offline fixture report",buffer.snapshot()));
            Toast.makeText(this,"Report copied",Toast.LENGTH_SHORT).show();
        });layout.addView(copy);
        report=new TextView(this);report.setTextSize(14);report.setText(buffer.snapshot());
        int pad=(int)(12*getResources().getDisplayMetrics().density);report.setPadding(pad,pad,pad,pad);
        ScrollView scroll=new ScrollView(this);scroll.addView(report);layout.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(layout);
        started=SystemClock.elapsedRealtime();
        if(restored){completed=true;log("RESTORED_REPORT_ONLY; no rerun");}
    }
    @Override protected void onSaveInstanceState(Bundle saved){
        saved.putBoolean("attempted",once.attempted());saved.putString("report",buffer.snapshot());super.onSaveInstanceState(saved);
    }
    private void start(){
        if(!once.begin())return;
        run.setEnabled(false);started=SystemClock.elapsedRealtime();
        OfflineFixtureProtocol.Packet packet;
        try { packet=OfflineFixtureProtocol.synthetic(()->System.currentTimeMillis()/1000,new SecureRandom()); }
        catch(RuntimeException e){finish(false,"PARENT_FIXTURE_REJECTED");return;}
        log("PARENT AUTH callbackAccepted=true replayRejected=true cancelRejected=true");
        log("PARENT SSE splitUtf8=true messages="+packet.messages.size()+" textBytes="
                +OfflineFixtureProtocol.EXPECTED_TEXT.getBytes(StandardCharsets.UTF_8).length);
        connection=new ServiceConnection(){
            @Override public void onServiceConnected(ComponentName name,IBinder service){
                if(completed||destroyed)return;
                if(invoked){finish(false,"RECONNECT_NO_RETRY");return;}invoked=true;
                try { service.linkToDeath(()->main.post(()->{
                    log("WORKER BINDER DEATH observed");if(!completed)finish(false,"EARLY_DEATH");
                }),0); }catch(RemoteException e){finish(false,"DEAD_BEFORE_RUN");return;}
                new Thread(()->invoke(service,packet),"offline-fixture-request").start();
            }
            @Override public void onServiceDisconnected(ComponentName name){if(!completed)finish(false,"DISCONNECTED");}
            @Override public void onNullBinding(ComponentName name){finish(false,"NULL_BINDING");}
            @Override public void onBindingDied(ComponentName name){if(!completed)finish(false,"BINDING_DIED");}
        };
        try {
            bound=bindIsolatedService(new Intent(this,OfflineFixtureService.class),Context.BIND_AUTO_CREATE,
                    "offline_"+UUID.randomUUID().toString().replace("-",""),getMainExecutor(),connection);
            if(!bound){finish(false,"BIND_FAILED");return;}
            main.postDelayed(deadline,8000);
        }catch(RuntimeException e){finish(false,"BIND_ERROR");}
    }
    private void invoke(IBinder service,OfflineFixtureProtocol.Packet packet){
        Parcel in=Parcel.obtain(),out=Parcel.obtain();boolean ok=false;
        try {
            in.writeInterfaceToken(OfflineFixtureService.DESCRIPTOR);
            in.writeLong(packet.requestId);in.writeInt(packet.authFlags);in.writeInt(packet.messages.size());
            for(OfflineSseAdapter.Message message:packet.messages){
                in.writeLong(message.requestId);in.writeInt(message.sequence);
                in.writeString(message.kind);in.writeString(message.text);
            }
            if(in.dataSize()>OfflineFixtureProtocol.MAX_PARCEL)throw new SecurityException("Parent parcel bound");
            if(!service.transact(OfflineFixtureService.RUN,in,out,0)||out.dataSize()>128)
                throw new RemoteException("Offline reply bound");
            out.readException();
            ok=out.readLong()==packet.requestId && out.readInt()==1
                    && out.readInt()==OfflineFixtureProtocol.EXPECTED_TEXT.getBytes(StandardCharsets.UTF_8).length
                    && out.dataAvail()==0;
        }catch(RemoteException|RuntimeException ignored){/* Bounded result below; no exception text in report. */}
        finally{in.recycle();out.recycle();}
        final boolean accepted=ok;
        main.post(()->finish(accepted,accepted?"ISOLATED_WORKER_ACCEPTED":"WORKER_REJECTED"));
    }
    private void finish(boolean ok,String reason){
        if(completed||destroyed)return;
        completed=true;main.removeCallbacks(deadline);
        log("WORKER "+reason);cleanup();
        log(ok&&!buffer.overflowed()?"TEST PASS OFFLINE_AUTH_SSE":"TEST FAIL/INCONCLUSIVE OFFLINE_AUTH_SSE");
    }
    private void cleanup(){
        main.removeCallbacks(deadline);
        if(bound){bound=false;ServiceConnection old=connection;connection=null;
            try{unbindService(old);log("UNBOUND; awaiting Binder death");}catch(RuntimeException ignored){log("UNBIND_FAILED");}
        }
    }
    @Override protected void onDestroy(){destroyed=true;cleanup();super.onDestroy();}
}
