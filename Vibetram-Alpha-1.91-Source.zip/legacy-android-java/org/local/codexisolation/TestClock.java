// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

/** Grant-local monotonic offset for explicit expiry cases; never changes OS time. */
final class TestClock implements GrantState.ExpiryClock {
    private final GrantState.Clock real;
    private long offset;
    TestClock(GrantState.Clock real) { this.real = real; }
    public synchronized long now() { return real.now() + offset; }
    synchronized void expire() { offset += 15000; }
    public synchronized GrantState.Advance advanceIfBefore(long deadline) {
        long before = real.now() + offset;
        if (before >= deadline) return new GrantState.Advance(before, before, false);
        offset += deadline - before;
        return new GrantState.Advance(before, deadline, true);
    }
}
