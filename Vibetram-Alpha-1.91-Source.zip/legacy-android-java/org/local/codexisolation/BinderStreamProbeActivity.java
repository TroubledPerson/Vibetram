// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;
import android.app.Activity;
import android.content.*;
import android.os.*;
import android.widget.*;
import java.util.Arrays;
import java.util.UUID;

/** One selected bounded offline streaming case per Activity lifetime. */
public final class BinderStreamProbeActivity extends Activity {
    private final Handler main=new Handler(Looper.getMainLooper());
    private final ReleaseGuard guard=new ReleaseGuard();
    private TextView report,status;private Button select,run;
    private RunOnceState once;private ReportBuffer buffer;
    private boolean completed,destroyed,bound,failed,invoked;
    private long started;private int generation;
    private StreamGrant modelGrant;private NoteGrant grant;private StreamGate gate;private Spinner modes;private int mode;
    private ServiceConnection connection;private Runnable releaseTask;
    private final Runnable deadline=()->fail("PARENT_DEADLINE_15S");
    private void log(String value){
        if(destroyed)return;
        if(!buffer.append("+"+(SystemClock.elapsedRealtime()-started)+"ms "+value)){failed=true;cleanup();return;}
        report.setText(buffer.snapshot());
    }
    @Override public void onCreate(Bundle saved){super.onCreate(saved);
        boolean restored=saved!=null&&saved.getBoolean("attempted",false);once=new RunOnceState(restored);
        LinearLayout layout=new LinearLayout(this);layout.setOrientation(LinearLayout.VERTICAL);
        layout.setOnApplyWindowInsetsListener((v,insets)->{
            if(Build.VERSION.SDK_INT>=30){
                android.graphics.Insets bars=insets.getInsets(android.view.WindowInsets.Type.systemBars()|android.view.WindowInsets.Type.displayCutout());
                v.setPadding(bars.left,bars.top,bars.right,bars.bottom);
            }else v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),
                    insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());
            return insets;
        });
        status=new TextView(this);status.setTextSize(18);status.setText(restored?"Restored report only; no rerun":"Selected: NONE");
        select=new Button(this);select.setText("SELECT STREAM CASE");select.setEnabled(!restored);
        run=new Button(this);run.setText("Select test first");run.setEnabled(false);
        modes=new Spinner(this);modes.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"STREAM SUCCESS","STREAM REVOKE","STREAM TIMEOUT"}));modes.setEnabled(!restored); select.setOnClickListener(v->{if(once.select()){mode=modes.getSelectedItemPosition();modes.setEnabled(false);status.setText("Selected: "+caseName());run.setText("RUN STREAM ONCE");run.setEnabled(true);}});
        run.setOnClickListener(v->start());
        Button stop=new Button(this);stop.setText("STOP (inconclusive)");stop.setOnClickListener(v->{if(once.attempted()&&!completed)fail("MANUAL_STOP");});
        Button copy=new Button(this);copy.setText("COPY REPORT");copy.setOnClickListener(v->{
            android.content.ClipboardManager clipboard=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
            clipboard.setPrimaryClip(ClipData.newPlainText("Codex offline report",buffer.snapshot()));
            Toast.makeText(this,"Report copied",Toast.LENGTH_SHORT).show();
        });
        LinearLayout row1=new LinearLayout(this);row1.addView(select,new LinearLayout.LayoutParams(0,-2,1));row1.addView(run,new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout row2=new LinearLayout(this);row2.addView(stop,new LinearLayout.LayoutParams(0,-2,1));row2.addView(copy,new LinearLayout.LayoutParams(0,-2,1));
        layout.addView(status,new LinearLayout.LayoutParams(-1,-2));layout.addView(modes,new LinearLayout.LayoutParams(-1,-2));layout.addView(row1,new LinearLayout.LayoutParams(-1,-2));layout.addView(row2,new LinearLayout.LayoutParams(-1,-2));
        report=new TextView(this);report.setTextIsSelectable(false);report.setHorizontallyScrolling(false);report.setTextSize(14);
        int pad=(int)(12*getResources().getDisplayMetrics().density);report.setPadding(pad,pad,pad,pad);
        String header;
        try{android.content.pm.PackageInfo p=getPackageManager().getPackageInfo(getPackageName(),0);header=p.packageName+" "+p.versionName+" code="+p.getLongVersionCode()+"\nJavaSHA="+BuildEvidence.SOURCE_ID+"\nDevice="+Build.MODEL+" Android="+Build.VERSION.RELEASE+"\nOffline incremental Binder events. No provider. One selected case; separate worker death required.";}catch(Exception e){throw new IllegalStateException(e);}
        buffer=new ReportBuffer(restored?saved.getString("report",header):header);report.setText(buffer.snapshot());
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setVerticalScrollBarEnabled(true);
        scroll.addView(report,new ScrollView.LayoutParams(-1,-2));layout.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));setContentView(layout);layout.requestApplyInsets();
        if(restored){completed=true;failed=true;started=SystemClock.elapsedRealtime();log("RESTORED_REPORT_ONLY; previous attempt cannot be rerun");}
    }
    @Override protected void onSaveInstanceState(Bundle saved){saved.putBoolean("attempted",once.attempted());saved.putString("report",buffer.snapshot());super.onSaveInstanceState(saved);}
    private String caseName(){return mode==0?"STREAM_SUCCESS":mode==1?"STREAM_REVOKE":"STREAM_TIMEOUT";}
    private void start(){
        if(!once.begin())return;select.setEnabled(false);run.setEnabled(false);started=SystemClock.elapsedRealtime();
        final int job=++generation;final NoteGrant selected=new NoteGrant(job,SystemClock::elapsedRealtime);grant=selected;
        
        modelGrant=new StreamGrant(job,mode,()->{if(!main.post(()->onHeld(job)))throw new SecurityException("Hold notification unavailable");});
        gate=modelGrant.gate;log("START "+caseName()+" run="+UUID.randomUUID()+" expectedNoteSHA256="+NoteGrant.hex(selected.expectedHash));
        connection=new ServiceConnection(){
            public void onServiceConnected(ComponentName n,IBinder service){if(completed||destroyed)return;if(invoked){fail("RECONNECT_NO_RETRY");return;}invoked=true;
                try{service.linkToDeath(()->main.post(()->{log("WORKER BINDER DEATH observed");if(!completed)fail("EARLY_DEATH");}),0);}catch(RemoteException e){fail("DEAD_BEFORE_RUN");return;}
                new Thread(()->invoke(service,selected,job),"model-stream-request").start();}
            public void onServiceDisconnected(ComponentName n){if(!completed)fail("DISCONNECTED");}
            public void onNullBinding(ComponentName n){fail("NULL_BINDING");}
            public void onBindingDied(ComponentName n){if(!completed)fail("BINDING_DIED");}
        };
        try{bound=bindIsolatedService(new Intent(this,CoreProbeService.class),Context.BIND_AUTO_CREATE,"stream_"+UUID.randomUUID().toString().replace("-",""),getMainExecutor(),connection);if(!bound){fail("BIND_FAILED");return;}main.postDelayed(deadline,15000);}catch(RuntimeException e){fail("BIND_ERROR");}
    }
    private void onHeld(int job){
        if(completed||destroyed||job!=generation){gate.cleanup(modelGrant.state);return;}
        log("CONTROL heldRequest=2 heldSequence=2 mode="+caseName()+" delayMs=200 gateTimeoutMs=1200");if(mode==StreamGate.TIMEOUT)return;
        releaseTask=()->{
            if(completed||destroyed||job!=generation){gate.cleanup(modelGrant.state);return;}
            boolean released=gate.revokeAndRelease(modelGrant.state);
            log("CONTROL explicitRevokeThenRelease="+released);
            if(!released)fail("REVOKE_RELEASE_INCONCLUSIVE");
        };
        if(!main.postDelayed(releaseTask,StreamGate.DELAY_MS))fail("RELEASE_SCHEDULE_FAILED");
    }
    private void invoke(IBinder service,NoteGrant selected,int job){
        Parcel in=Parcel.obtain(),out=Parcel.obtain();byte[] frame=null;boolean valid=false;int workerStatus=-1;String stage="REQUEST";
        try{in.writeInterfaceToken(CoreProbeService.DESCRIPTOR);in.writeStrongBinder(selected);in.writeByteArray(selected.token);in.writeLong(job);in.writeInt(23);in.writeStrongBinder(modelGrant);in.writeByteArray(modelGrant.token);
            stage="TRANSACT";if(!service.transact(CoreProbeService.RUN,in,out,0)||out.dataSize()>256)throw new RemoteException("Proof reply bounds");
            stage="REMOTE_EXCEPTION";out.readException();stage="GENERATION";if(out.dataAvail()<16||out.readLong()!=job)throw new RemoteException("Proof generation");
            stage="ENVELOPE";workerStatus=out.readInt();ProbeReply.validate(workerStatus,out.dataAvail());
            if(workerStatus!=ProbeReply.OK){if(out.readInt()!=-1||out.dataAvail()!=0)throw new RemoteException("Failure payload");stage="WORKER_FAILURE";}
            else{frame=new byte[OutputProof.LENGTH];out.readByteArray(frame);if(out.dataAvail()!=0)throw new RemoteException("Trailing proof");stage="COMPLETE";}
            valid=true;
        }catch(RemoteException|RuntimeException e){/* Closed diagnostic below; never print exception text. */}finally{in.recycle();out.recycle();}
        final byte[] proof=frame;final boolean returned=valid;final int resultStatus=workerStatus;final String transportStage=stage;
        main.post(()->{if(completed||destroyed||job!=generation)return;
            boolean ok=!failed&&!buffer.overflowed()&&StreamProof.accept(mode,returned,resultStatus,proof,modelGrant.state,gate,selected.state,selected.expectedHash,job);
            log("DIAG transport="+transportStage+" worker="+ProbeReply.status(resultStatus)+" proofBytes="+(proof==null?0:proof.length));
            log("STREAM "+modelGrant.state.report()+" noteUID="+selected.state.pinnedUid());
            log("GATE "+gate.report());
            log("NOTE A/R/S/D/P="+Arrays.toString(selected.state.counts())+" outputDependencyVerified="+ok);
            log("STREAM_PROOF="+ok+" finalAccepted="+(selected.state.counts()[4]==1)+" case="+caseName());
            completed=true;cleanup();ok=ok&&!failed&&!buffer.overflowed()&&!selected.state.traceOverflowed();
            log(ok?"TEST PASS "+caseName()+"; separate Binder death required":"TEST FAIL/INCONCLUSIVE "+caseName());
        });
    }
    private void fail(String why){if(completed)return;failed=true;completed=true;log("TEST FAIL/INCONCLUSIVE "+why);if(gate!=null)log("GATE "+gate.report());cleanup();}
    private void cleanup(){guard.run(()->{ServiceConnection old=bound?connection:null;bound=false;connection=null;++generation;main.removeCallbacks(deadline);if(releaseTask!=null)main.removeCallbacks(releaseTask);if(grant!=null)grant.revoke();if(modelGrant!=null){gate.cleanup(modelGrant.state);log("CLEANUP modelRevoked="+modelGrant.state.revoked()+" gateWaitSignalled="+gate.signalled());}if(old!=null){unbindService(old);log("UNBOUND; awaiting Binder death");}});}
    @Override protected void onDestroy(){destroyed=true;failed=true;cleanup();super.onDestroy();}
}




