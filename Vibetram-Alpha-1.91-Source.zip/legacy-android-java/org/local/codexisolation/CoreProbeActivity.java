// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;
import android.os.Bundle;

/** Existing launcher; only streaming controls and entries moved to the debug submenu. */
public final class CoreProbeActivity extends DebugMenuActivity {
    @Override public void onCreate(Bundle saved){
        super.onCreate(saved);
        showMenu("Codex Core Test 1.83 — source candidate",
            "Opening a screen does not run its test. Existing sign-in, capture and connection approvals remain separate.",
            DebugNavigationCatalog.home());
    }
}
