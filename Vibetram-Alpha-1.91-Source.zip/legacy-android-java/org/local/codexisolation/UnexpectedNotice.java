// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Locale;

/** Fixed category and digest of a rejected protocol method; never includes params or raw method text. */
final class UnexpectedNotice {
    private UnexpectedNotice(){}
    static String code(String method){
        String category;
        if(method.startsWith("turn/"))category="TURN";
        else if(method.startsWith("thread/"))category="THREAD";
        else if(method.startsWith("item/"))category="ITEM";
        else if(method.startsWith("model/")||method.startsWith("modelProvider/"))category="MODEL";
        else if(method.startsWith("account/"))category="ACCOUNT";
        else if(method.startsWith("mcpServer/"))category="MCP";
        else if(method.startsWith("fs/"))category="FS";
        else if("error".equals(method)||"guardianWarning".equals(method))category="ERROR";
        else category="OTHER";
        try{
            byte[] digest=MessageDigest.getInstance("SHA-256").digest(method.getBytes(StandardCharsets.UTF_8));
            StringBuilder shortHash=new StringBuilder(12);
            for(int i=0;i<6;i++)shortHash.append(String.format(Locale.ROOT,"%02x",digest[i]&255));
            return "UNEXPECTED_NOTIFICATION_"+category+"_"+shortHash;
        }catch(NoSuchAlgorithmException e){return "UNEXPECTED_NOTIFICATION_"+category+"_HASH_UNAVAILABLE";}
    }
}
