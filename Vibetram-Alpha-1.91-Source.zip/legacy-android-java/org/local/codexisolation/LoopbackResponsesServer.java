// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

/** One localhost-only canned Responses stream. Never forwards a request. */
final class LoopbackResponsesServer implements AutoCloseable {
    private static final String TEXT="Offline local response.";
    private final ServerSocket listener;
    private final Thread worker;
    private volatile int requests;
    private volatile String failure;
    private final boolean stall;
    LoopbackResponsesServer(boolean stall) throws Exception{
        this.stall=stall;
        listener=new ServerSocket(0,1,InetAddress.getByName("127.0.0.1"));
        listener.setSoTimeout(30000);
        worker=new Thread(this::serve,"coretest-loopback-responses");worker.setDaemon(true);worker.start();
    }
    int port(){return listener.getLocalPort();}
    int requests(){return requests;}
    String failure(){return failure;}
    private void serve(){
        try(Socket client=listener.accept()){
            client.setSoTimeout(10000);
            if(!client.getInetAddress().isLoopbackAddress())throw new IllegalStateException("NON_LOOPBACK_CLIENT");
            InputStream in=client.getInputStream();OutputStream out=client.getOutputStream();
            ByteArrayOutputStream header=new ByteArrayOutputStream();
            while(header.size()<8192){
                int b=in.read();if(b<0)throw new IllegalStateException("EARLY_EOF");header.write(b);
                byte[] bytes=header.toByteArray();int n=bytes.length;
                if(n>=4&&bytes[n-4]=='\r'&&bytes[n-3]=='\n'&&bytes[n-2]=='\r'&&bytes[n-1]=='\n')break;
            }
            String headers=new String(header.toByteArray(),StandardCharsets.US_ASCII);
            if(!headers.startsWith("POST /v1/responses "))throw new IllegalStateException("UNEXPECTED_PATH");
            int length=-1;
            for(String line:headers.split("\r\n")){
                if(line.toLowerCase(java.util.Locale.ROOT).startsWith("content-length:"))
                    length=Integer.parseInt(line.substring(line.indexOf(':')+1).trim());
                if(line.toLowerCase(java.util.Locale.ROOT).startsWith("authorization:")&&
                        !line.equals("Authorization: Bearer sk-coretest-local-only"))
                    throw new IllegalStateException("UNEXPECTED_AUTH_HEADER");
            }
            if(length<0||length>1024*1024)throw new IllegalStateException("BODY_SIZE_INVALID");
            byte[] body=new byte[length];int got=0;
            while(got<length){int n=in.read(body,got,length-got);if(n<0)throw new IllegalStateException("BODY_EOF");got+=n;}
            String request=new String(body,StandardCharsets.UTF_8);
            if(!request.contains("offline synthetic ping"))throw new IllegalStateException("PROMPT_MISSING");
            requests++;
            if(stall){Thread.sleep(30000);return;}
            String created="event: response.created\ndata: {\"type\":\"response.created\",\"response\":{\"id\":\"resp-local-1\"}}\n\n";
            String message="event: response.output_item.done\ndata: {\"type\":\"response.output_item.done\",\"item\":{\"type\":\"message\",\"role\":\"assistant\",\"id\":\"msg-local-1\",\"content\":[{\"type\":\"output_text\",\"text\":\""+TEXT+"\"}]}}\n\n";
            String done="event: response.completed\ndata: {\"type\":\"response.completed\",\"response\":{\"id\":\"resp-local-1\",\"usage\":{\"input_tokens\":0,\"input_tokens_details\":null,\"output_tokens\":0,\"output_tokens_details\":null,\"total_tokens\":0}}}\n\n";
            String events=created+message+done;
            byte[] payload=events.getBytes(StandardCharsets.UTF_8);
            String response="HTTP/1.1 200 OK\r\nContent-Type: text/event-stream\r\nCache-Control: no-cache\r\nContent-Length: "+payload.length+"\r\nConnection: close\r\n\r\n";
            out.write(response.getBytes(StandardCharsets.US_ASCII));out.write(payload);out.flush();
        }catch(Exception e){if(!listener.isClosed())failure=e.getClass().getSimpleName()+":"+e.getMessage();}
        finally{try{listener.close();}catch(Exception ignored){}}
    }
    @Override public void close() throws Exception{listener.close();worker.interrupt();worker.join(2000);}
}
