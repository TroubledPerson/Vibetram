// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import javax.net.ssl.HttpsURLConnection;

/** One-time owner-created pairing code exchange. Credentials stay in process memory. */
final class RemotePhoneEnrollment {
    static final class Pairing {
        final String origin,ownerId,deviceId,token;
        Pairing(String origin,String ownerId,String deviceId,String token){
            this.origin=origin;this.ownerId=ownerId;this.deviceId=deviceId;this.token=token;
        }
    }
    private RemotePhoneEnrollment(){}
    static URL origin(String value) throws Exception {
        URL url=new URL(value);
        String path=url.getPath();
        if(!"https".equals(url.getProtocol())||url.getHost().isEmpty()||url.getUserInfo()!=null
                ||!(path.isEmpty()||"/".equals(path))||url.getQuery()!=null||url.getRef()!=null)
            throw new IllegalArgumentException("HTTPS_ORIGIN_INVALID");
        return url;
    }
    private static String field(Map<?,?> map,String name,String pattern){
        Object value=map.get(name);
        if(!(value instanceof String)||!((String)value).matches(pattern))throw new IllegalArgumentException("PAIRING_INVALID");
        return (String)value;
    }
    static Pairing enroll(String httpsOrigin,String code) throws Exception {
        URL base=origin(httpsOrigin);
        if(code==null||!code.matches("[0-9a-f]{32}"))throw new IllegalArgumentException("PAIRING_INVALID");
        Map<?,?> result=post(base,"/phone/enroll",new JSONObject().put("code",code),null);
        return new Pairing(base.toExternalForm(),field(result,"ownerId","[A-Za-z0-9_-]{1,64}"),
                field(result,"deviceId","[0-9a-f]{32}"),field(result,"token","[A-Za-z0-9_-]{43}"));
    }
    static void revoke(Pairing pairing) throws Exception {
        post(origin(pairing.origin),"/phone/disconnect",new JSONObject().put("ownerId",pairing.ownerId).put("deviceId",pairing.deviceId),pairing.token);
    }
    private static Map<?,?> post(URL base,String path,JSONObject body,String token) throws Exception {
        HttpsURLConnection connection=(HttpsURLConnection)new URL(base,path).openConnection();
        try{
            connection.setInstanceFollowRedirects(false);connection.setRequestMethod("POST");connection.setDoOutput(true);
            connection.setConnectTimeout(5000);connection.setReadTimeout(5000);
            connection.setRequestProperty("Content-Type","application/json");
            if(token!=null)connection.setRequestProperty("Authorization","Bearer "+token);
            byte[] bytes=body.toString().getBytes(StandardCharsets.UTF_8);
            if(bytes.length>2048)throw new IllegalArgumentException("REQUEST_TOO_LARGE");
            try(OutputStream out=connection.getOutputStream()){out.write(bytes);}
            if(connection.getResponseCode()!=200)throw new IllegalStateException("REMOTE_UNAVAILABLE");
            ByteArrayOutputStream result=new ByteArrayOutputStream();byte[] chunk=new byte[512];
            try(InputStream in=connection.getInputStream()){
                int count;while((count=in.read(chunk))!=-1){
                    if(result.size()+count>2048)throw new IllegalStateException("REPLY_TOO_LARGE");
                    result.write(chunk,0,count);
                }
            }
            Object parsed=BoundedJson.parse(result.toByteArray());
            if(!(parsed instanceof Map))throw new IllegalStateException("REPLY_INVALID");
            return (Map<?,?>)parsed;
        }finally{connection.disconnect();}
    }
}
