// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

import android.app.Activity;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.File;

/** Runs a fixed genuine-child fixture while Android reports no validated Internet. */
public final class RealOfflineTurnActivity extends Activity {
    private volatile RealOfflineTurnSession session;
    private volatile boolean destroyed,networkAppeared;
    private boolean attempted;
    private ConnectivityManager connectivity;
    private ConnectivityManager.NetworkCallback networkCallback;
    @Override public void onCreate(Bundle saved){
        super.onCreate(saved);
        attempted=saved!=null&&saved.getBoolean("attempted");
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setOnApplyWindowInsetsListener((v,insets)->{
            if(Build.VERSION.SDK_INT>=30){
                android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout());
                v.setPadding(bars.left,bars.top,bars.right,bars.bottom);
            }else v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),
                    insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());
            return insets;
        });
        Button run=new Button(this);run.setText("RUN OFFLINE AUTH + STREAM");run.setEnabled(!attempted);
        TextView report=new TextView(this);report.setTextIsSelectable(true);
        report.setText("1.42 synthetic, memory-only callback lifecycle gates a genuine app-server with a fake API key and canned localhost text deltas. It checks replay, cancel, modeled Activity destruction, loopback closure, split UTF-8, and turn interruption. The separate lifecycle screen tests actual Android recreation during a stream. Turn off Wi-Fi, cellular data, VPN, and other Internet connections first. Local-only networks are allowed; validated Internet is blocked. No real account or model is used.\n");
        root.addView(run);ScrollView scroll=new ScrollView(this);scroll.addView(report);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);root.requestApplyInsets();
        connectivity=(ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);
        run.setOnClickListener(v->{
            if(attempted)return;attempted=true;run.setEnabled(false);
            if(Build.VERSION.SDK_INT<29||!"arm64-v8a".equals(Build.SUPPORTED_ABIS[0])){
                report.append("FAIL code=UNSUPPORTED_DEVICE\n");return;
            }
            try{
                if(connectivity==null||validatedInternetPresent()){
                    report.append("FAIL code=VALIDATED_INTERNET_PRESENT\n");return;
                }
                networkCallback=new ConnectivityManager.NetworkCallback(){
                    @Override public void onCapabilitiesChanged(Network network,NetworkCapabilities capabilities){
                        if(hasValidatedInternet(capabilities)){
                            networkAppeared=true;RealOfflineTurnSession s=session;if(s!=null)s.cancel();
                        }
                    }
                };
                connectivity.registerNetworkCallback(new NetworkRequest.Builder().clearCapabilities()
                        .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).build(),networkCallback);
                if(validatedInternetPresent()){
                    networkAppeared=true;report.append("FAIL code=VALIDATED_INTERNET_PRESENT\n");return;
                }
            }catch(RuntimeException e){report.append("FAIL code=OFFLINE_CHECK_UNAVAILABLE\n");return;}
            File appServer=new File(getApplicationInfo().nativeLibraryDir,"libcodex_app_server.so");
            new Thread(()->{
                try{
                    for(OfflineAuthStreamGate.Abort abort:OfflineAuthStreamGate.Abort.values()){
                        if(networkAppeared||validatedInternetPresent()){
                            post(report,"FAIL code=VALIDATED_INTERNET_PRESENT");return;
                        }
                        OfflineAuthStreamGate.Result result=OfflineAuthStreamGate.abort(abort);
                        if(result.accepted||!result.callbackRejected||!result.closed)
                            throw new SecurityException("ABORT_GATE_INVALID");
                        post(report,"PASS authAbort="+abort+" callback=REJECTED streamStarts=0");
                    }
                    for(RealOfflineTurnSession.Mode mode:new RealOfflineTurnSession.Mode[]{
                            RealOfflineTurnSession.Mode.COMPLETE,RealOfflineTurnSession.Mode.INTERRUPT}){
                        if(networkAppeared||validatedInternetPresent()){
                            post(report,"FAIL code=VALIDATED_INTERNET_PRESENT");break;
                        }
                        OfflineAuthStreamGate.Result auth=OfflineAuthStreamGate.accept();
                        if(!auth.accepted||!auth.replayRejected||!auth.closed)
                            throw new SecurityException("AUTH_GATE_INVALID");
                        session=new RealOfflineTurnSession(OfflineAppServerAdapter.SYSTEM);
                        String line;
                        try{
                            RealOfflineTurnSession.Result result=session.run(getFilesDir(),appServer,mode);
                            if(networkAppeared||validatedInternetPresent())
                                line="FAIL mode="+mode+" code=VALIDATED_INTERNET_PRESENT";
                            else line="PASS mode="+mode+" auth=ACCEPT replay=REJECTED stage="+session.stage()+" turn="+result.status
                                    +" localRequests="+result.localRequests+" deltas="+result.deltaCount
                                    +" utf8Split="+result.utf8Split+" authJson=ABSENT realAccount=NONE";
                        }catch(RealOfflineTurnSession.GateException e){
                            line="FAIL mode="+mode+" stage="+session.stage()+" code="+e.code;
                        }
                        post(report,line);
                        if(line.startsWith("FAIL"))break;
                    }
                }catch(SecurityException e){
                    RealOfflineTurnSession active=session;if(active!=null)active.cancel();
                    post(report,"FAIL code=AUTH_STREAM_GATE_INVALID");
                }catch(RuntimeException e){
                    RealOfflineTurnSession active=session;if(active!=null)active.cancel();
                    post(report,"FAIL code=OFFLINE_CHECK_UNAVAILABLE");
                }finally{session=null;}
            },"real-offline-turn-parent").start();
        });
    }
    private boolean validatedInternetPresent(){
        for(Network network:connectivity.getAllNetworks()){
            NetworkCapabilities capabilities=connectivity.getNetworkCapabilities(network);
            if(capabilities==null)throw new IllegalStateException("NETWORK_CAPABILITIES_UNAVAILABLE");
            if(hasValidatedInternet(capabilities))return true;
        }
        return false;
    }
    private static boolean hasValidatedInternet(NetworkCapabilities capabilities){
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                &&capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED);
    }
    private void post(TextView report,String line){runOnUiThread(()->{if(!destroyed)report.append(line+"\n");});}
    @Override protected void onSaveInstanceState(Bundle out){out.putBoolean("attempted",attempted);super.onSaveInstanceState(out);}
    @Override protected void onDestroy(){destroyed=true;if(session!=null)session.cancel();
        if(connectivity!=null&&networkCallback!=null)try{connectivity.unregisterNetworkCallback(networkCallback);}catch(RuntimeException ignored){}
        super.onDestroy();}
}
