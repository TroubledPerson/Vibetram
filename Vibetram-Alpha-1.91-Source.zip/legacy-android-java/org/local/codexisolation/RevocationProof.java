// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;
import java.util.Arrays;
final class RevocationProof {
    static boolean accept(boolean envelope,int workerStatus,byte[] proof,DelayedReplyGate gate,ModelState model,GrantState note,byte[] expected){
        return envelope&&workerStatus==ProbeReply.NATIVE_NULL&&proof==null&&gate.proven(expected)&&model.revocationEvidence()
            &&model.pinnedUid()==note.pinnedUid()&&note.preliminary(expected)&&!note.traceOverflowed()
            &&Arrays.equals(note.counts(),new int[]{1,1,1,0,0});
    }
}
