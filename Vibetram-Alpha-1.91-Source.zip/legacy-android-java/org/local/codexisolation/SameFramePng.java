// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;
import java.nio.ByteBuffer;
import java.util.function.BooleanSupplier;

/** At most four bounded PNG encodes of one detached frame; no Android/resource acquisition. */
final class SameFramePng {
 static final class Exhausted extends IllegalArgumentException{
  final int inputWidth,inputHeight,lastWidth,lastHeight,attempts;
  private Exhausted(int w,int h,int lastW,int lastH,int n){super("PNG_LADDER_EXHAUSTED");inputWidth=w;inputHeight=h;lastWidth=lastW;lastHeight=lastH;attempts=n;}
 }
 static final class Result{
  final CapturedPng image;final int inputWidth,inputHeight,attempts;
  private Result(CapturedPng image,int w,int h,int attempts){this.image=image;inputWidth=w;inputHeight=h;this.attempts=attempts;}
  boolean reduced(){return image.width!=inputWidth||image.height!=inputHeight;}
 }
 static Result encode(byte[] original,int w,int h,BooleanSupplier allowed){
  if(allowed==null)throw new IllegalArgumentException("PROCESSING_GUARD_REQUIRED");
  Runnable guard=()->{if(!allowed.getAsBoolean())throw new IllegalStateException("SAME_FRAME_PROCESSING_REVOKED");};
  guard.run();
  if(w<1||h<1||w>640||h>640||original==null||(long)w*h*4!=original.length)throw new IllegalArgumentException("RGBA_BOUNDS_REJECTED");
  int longEdge=Math.max(w,h),lastW=0,lastH=0,attempts=0;
  for(int edge:new int[]{640,480,360,240}){
   guard.run();int target=Math.min(edge,longEdge),nw=Math.max(1,(int)((long)w*target/longEdge)),nh=Math.max(1,(int)((long)h*target/longEdge));
   if(nw==lastW&&nh==lastH)continue;lastW=nw;lastH=nh;
   byte[] pixels=nw==w&&nh==h?original:reduce(original,w,h,nw,nh,guard);
   guard.run();attempts++;
   try{
    CapturedPng image=CapturedPng.rgba(ByteBuffer.wrap(pixels),nw,nh,nw*4,4,guard);
    guard.run();return new Result(image,w,h,attempts);
   }catch(IllegalArgumentException failure){
    if(!"PNG_SIZE_LIMIT".equals(failure.getMessage()))throw failure;
    guard.run(); // Only overflow can continue; canceled/expired ownership terminates here too.
   }
  }
  guard.run();throw new Exhausted(w,h,lastW,lastH,attempts);
 }
 static byte[] reduce(byte[] original,int w,int h,int nw,int nh,Runnable guard){
  guard.run();if(original==null||w<1||h<1||w>640||h>640||(long)w*h*4!=original.length||nw<1||nh<1||nw>w||nh>h)throw new IllegalArgumentException("RGBA_BOUNDS_REJECTED");
  byte[] out=new byte[nw*nh*4];
  for(int y=0;y<nh;y++){
   guard.run();int y0=y*h/nh,y1=(y+1)*h/nh;
   for(int x=0;x<nw;x++){
    int x0=x*w/nw,x1=(x+1)*w/nw,count=(x1-x0)*(y1-y0);long r=0,g=0,b=0;
    for(int yy=y0;yy<y1;yy++){
     guard.run();for(int xx=x0;xx<x1;xx++){
      int o=(yy*w+xx)*4,a=original[o+3]&255;
      r+=(original[o]&255)*a/255;g+=(original[o+1]&255)*a/255;b+=(original[o+2]&255)*a/255;
     }
    }
    int o=(y*nw+x)*4;out[o]=(byte)(r/count);out[o+1]=(byte)(g/count);out[o+2]=(byte)(b/count);out[o+3]=(byte)255;
   }
  }
  guard.run();return out;
 }
}
