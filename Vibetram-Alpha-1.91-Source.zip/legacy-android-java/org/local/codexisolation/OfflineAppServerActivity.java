// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.File;

/** Manual app-UID stdio check. Only bounded status reaches the UI; no Binder or network. */
public final class OfflineAppServerActivity extends Activity {
    private OfflineAppServerAdapter adapter;
    private boolean attempted, destroyed;
    private TextView report;
    private Button normal, cancel, death;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        attempted=saved!=null && saved.getBoolean("attempted");
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setOnApplyWindowInsetsListener((v,insets)->{
            if(Build.VERSION.SDK_INT>=30){
                android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout());
                v.setPadding(bars.left,bars.top,bars.right,bars.bottom);
            }else{
                v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),
                        insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());
            }
            return insets;
        });
        normal=new Button(this);normal.setText("RUN INITIALIZE ONCE");normal.setEnabled(!attempted);
        cancel=new Button(this);cancel.setText("RUN CANCEL AFTER REQUEST ONCE");cancel.setEnabled(!attempted);
        death=new Button(this);death.setText("RUN PROCESS DEATH AFTER REQUEST ONCE");death.setEnabled(!attempted);
        Button stop=new Button(this);stop.setText("STOP (inconclusive)");
        report=new TextView(this);report.setText("1.18 offline app-server lifecycle\nChoose one case per screen. No login, provider, model, or network request.\n");
        report.setTextIsSelectable(true);
        root.addView(normal);root.addView(cancel);root.addView(death);root.addView(stop);
        ScrollView scroll=new ScrollView(this);scroll.addView(report);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);root.requestApplyInsets();
        normal.setOnClickListener(v->start(OfflineAppServerAdapter.Mode.INITIALIZE));
        cancel.setOnClickListener(v->start(OfflineAppServerAdapter.Mode.CANCEL_AFTER_REQUEST));
        death.setOnClickListener(v->start(OfflineAppServerAdapter.Mode.PROCESS_DEATH_AFTER_REQUEST));
        stop.setOnClickListener(v->{if(adapter!=null){adapter.cancel();report.append("MANUAL_STOP_INCONCLUSIVE\n");}});
    }
    @Override protected void onSaveInstanceState(Bundle out){out.putBoolean("attempted",attempted);super.onSaveInstanceState(out);}
    private void start(OfflineAppServerAdapter.Mode mode){
        if(attempted)return; attempted=true;
        normal.setEnabled(false);cancel.setEnabled(false);death.setEnabled(false);
        report.append("CASE="+mode+"\n");
        if(Build.VERSION.SDK_INT<29 || !"arm64-v8a".equals(Build.SUPPORTED_ABIS[0])){
            report.append("FAIL UNSUPPORTED_DEVICE\n");return;
        }
        adapter=new OfflineAppServerAdapter(OfflineAppServerAdapter.SYSTEM);
        File binary=new File(getApplicationInfo().nativeLibraryDir,"libcodex_app_server.so");
        new Thread(()->{
            String outcome;
            try {
                OfflineAppServerAdapter.Result result=adapter.run(getFilesDir(),binary,mode);
                if(result.mode!=mode)throw new IllegalStateException("MODE_MISMATCH");
                outcome="PASS case="+mode+" stage="+adapter.stage()+" stderr="
                        +(result.stderrBytes<0?"CLOSED_AFTER_KILL":Integer.toString(result.stderrBytes));
            } catch(Exception e) {
                // Exception details and native output never enter UI or Binder.
                outcome="FAIL/INCONCLUSIVE case="+mode+" stage="+adapter.stage()
                        +" code="+safeCode(e);
            }
            String line=outcome;
            runOnUiThread(()->{if(!destroyed)report.append(line+"\n");});
        },"offline-appserver-parent").start();
    }
    private static String safeCode(Throwable error){
        while(error!=null){
            String code=error.getMessage();
            if(code!=null && (code.equals("CANCELLED") || code.equals("EARLY_STDOUT_EOF")
                    || code.equals("STDOUT_FRAME_OVERSIZE") || code.equals("STDOUT_TAIL_OVERSIZE")
                    || code.equals("STDERR_OVERSIZE") || code.equals("INITIALIZE_HOME_MISMATCH")
                    || code.equals("INITIALIZE_PLATFORM_INVALID") || code.equals("INITIALIZE_RPC_ERROR")
                    || code.equals("EXIT_TIMEOUT") || code.equals("NONZERO_EXIT")
                    || code.equals("EARLY_PROCESS_EXIT") || code.equals("KILL_TIMEOUT")
                    || code.equals("UNEXPECTED_CLEAN_EXIT") || code.equals("STDIN_CLOSE_ERROR")
                    || code.equals("STDERR_DRAIN_TIMEOUT")
                    || code.equals("HOME_OUTSIDE_PRIVATE_FILES") || code.equals("NATIVE_BINARY_UNAVAILABLE")))
                return code;
            error=error.getCause();
        }
        return "ADAPTER_STOPPED";
    }
    @Override protected void onDestroy(){destroyed=true;if(adapter!=null)adapter.cancel();super.onDestroy();}
}
