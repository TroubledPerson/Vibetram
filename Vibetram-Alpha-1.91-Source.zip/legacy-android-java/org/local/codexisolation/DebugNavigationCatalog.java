// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

import java.util.List;

/** Fixed in-app destinations only. Choosing a destination never runs its test. */
final class DebugNavigationCatalog {
    static final class Route {
        final String label, activity;
        private Route(String label, String name) {
            this.label=label; this.activity="org.local.codexisolation."+name;
        }
    }
    private DebugNavigationCatalog() {}
    static List<Route> home() { return List.of(
        new Route("OPEN CONNECTIVITY CHECK (NO SIGN-IN)","ConnectivityProbeActivity"),
        new Route("OPEN MANAGED DEVICE-CODE SIGN-IN","ManagedDeviceCodeActivity"),
        new Route("OPEN ONE-SHOT LOCAL SCREENSHOT TEST","OneShotCaptureActivity"),
        new Route("OPEN SIMULATED HANDOFF TEST (NO CAPTURE)","SimulatedHandoffActivity"),
        new Route("OPEN SYNTHETIC MODES REVIEW (NO TRANSMISSION)","SyntheticReviewActivity"),
        new Route("OPEN PHONE PROJECT (1.63)","ManagedChatActivity"),
        new Route("Stream debug tools","StreamDebugToolsActivity"),
        new Route("OPEN 1.15 OFFLINE FIXTURES","OfflineFixtureActivity"),
        new Route("OPEN OFFLINE APP-SERVER ADAPTER","OfflineAppServerActivity"),
        new Route("OPEN OFFLINE AUTH PREFLIGHT","OfflineManagedAuthActivity"),
        new Route("OPEN OFFLINE NATIVE LOG CHECK","NativeLogBoundaryActivity")); }
    static List<Route> stream() { return List.of(
        new Route("OPEN BINDER STREAM CASES","BinderStreamProbeActivity"),
        new Route("OPEN ONE-TURN CHATGPT TEST","ManagedOneTurnActivity"),
        new Route("OPEN REAL SCREEN LIFECYCLE PROBE","LifecycleStreamActivity"),
        new Route("OPEN OFFLINE AUTH + STREAM","RealOfflineTurnActivity"),
        new Route("OPEN OFFLINE SYNTHETIC TURN","OfflineSyntheticTurnActivity")); }
}
