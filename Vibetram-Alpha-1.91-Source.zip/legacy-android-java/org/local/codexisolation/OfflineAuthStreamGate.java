// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

import java.security.SecureRandom;

/** Synthetic, memory-only callback gate before the localhost stream fixture. */
final class OfflineAuthStreamGate {
    enum Abort { CANCEL, ACTIVITY_DESTROYED, LOOPBACK_CLOSED }
    static final class Result {
        final boolean accepted, replayRejected, callbackRejected, closed;
        Result(boolean accepted, boolean replayRejected, boolean callbackRejected, boolean closed) {
            this.accepted=accepted;this.replayRejected=replayRejected;
            this.callbackRejected=callbackRejected;this.closed=closed;
        }
    }
    private static final String DUMMY_CODE="offline_fixture_only";
    private static final int SYNTHETIC_PORT=43127; // No socket is opened on this port.
    private OfflineAuthStreamGate() {}
    private static final class Fixture {
        final OfflineBrowserLifecycle lifecycle=new OfflineBrowserLifecycle();
        final OfflineAuthBoundary.Clock clock=()->System.currentTimeMillis()/1000;
        final OfflineAuthBoundary.Attempt attempt=lifecycle.prepare(SYNTHETIC_PORT,clock,new SecureRandom());
        final String callback=attempt.redirectUri+"?code="+DUMMY_CODE+"&state="+attempt.state;
        Fixture(){lifecycle.browserOpened();}
    }
    static Result accept() {
        Fixture f=new Fixture();
        if(!DUMMY_CODE.equals(f.lifecycle.callback(f.callback,f.clock)))
            throw new SecurityException("Synthetic callback code mismatch");
        boolean replayRejected=false;
        try {f.lifecycle.callback(f.callback,f.clock);} catch(SecurityException expected){replayRejected=true;}
        if(!replayRejected||!f.lifecycle.closed()||!f.attempt.closed())
            throw new SecurityException("Synthetic callback replay accepted");
        // The dummy code is deliberately discarded. It cannot be used as a credential.
        return new Result(true,true,false,true);
    }
    static Result abort(Abort reason) {
        Fixture f=new Fixture();
        switch(reason){
            case CANCEL: f.attempt.cancel(); break;
            case ACTIVITY_DESTROYED: f.lifecycle.activityDestroyed(); break;
            case LOOPBACK_CLOSED: f.lifecycle.loopbackClosed(); break;
            default: throw new SecurityException("Unknown synthetic abort");
        }
        boolean callbackRejected=false;
        try {f.lifecycle.callback(f.callback,f.clock);} catch(SecurityException expected){callbackRejected=true;}
        if(!callbackRejected||!f.attempt.closed())
            throw new SecurityException("Callback accepted after synthetic abort");
        return new Result(false,false,true,f.lifecycle.closed());
    }
}
