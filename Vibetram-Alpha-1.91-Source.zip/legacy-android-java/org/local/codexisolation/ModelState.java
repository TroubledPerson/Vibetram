// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;
import java.security.MessageDigest;

/** Separate two-request capability. No lock is held while parsing model JSON. */
final class ModelState {
    interface Sink {void write(byte[] reply);}
    enum Stage { NONE, TRANSACTION, ENVELOPE, AUTHORITY, POLICY, HOLD, COMMIT }
    private int transactions,observedFlags;private Stage firstFailure=Stage.NONE;
    // Android16 IBinder/BinderProxy: synchronous AppOps collection metadata is 0x02.
    // Native IPCThreadState adds TF_ACCEPT_FDS (0x10). Neither bit grants capability authority.
    // Allow only their four combinations; FLAG_ONEWAY (0x01) and every other bit reject.
    private static final int SYNCHRONOUS_METADATA=0x02|0x10;
    static boolean synchronousFlags(int flags){return (flags & ~SYNCHRONOUS_METADATA)==0;}
    synchronized void observeTransaction(int flags){transactions=Math.min(3,transactions+1);observedFlags=flags;}
    private final byte[] token;private final long generation,expires;private final GrantState.Clock clock;private final int parentUid;
    private boolean revoked,inFlight;private int next=1,pinned=-1,attempts,replies,denials;private final String[] requestHashes=new String[2];
    ModelState(byte[] token,long generation,int parentUid,GrantState.Clock clock){this.token=token.clone();this.generation=generation;this.parentUid=parentUid;this.clock=clock;this.expires=clock.now()+12000;}
    private SecurityException reject(){revoked=true;denials++;return new SecurityException("Model capability rejected");}
    synchronized int begin(byte[] supplied,long gen,int id,int uid,int flags,byte[] request){
        attempts++;if(revoked||clock.now()>=expires||!synchronousFlags(flags)||supplied==null||!MessageDigest.isEqual(token,supplied)||gen!=generation||uid<0||uid==parentUid||id!=next||id>2||inFlight||request==null||request.length<10||request.length>ModelPolicy.MAX_WIRE)throw reject();
        if(pinned!=-1&&pinned!=uid)throw reject();pinned=uid;inFlight=true;requestHashes[id-1]=hex(GrantState.digest(request));return id;
    }
    synchronized void commit(int ticket,byte[] reply,Sink sink){
        if(revoked||clock.now()>=expires||!inFlight||ticket!=next)throw reject();
        try{ModelPolicy.validateReply(ticket,reply);sink.write(reply);}catch(RuntimeException e){throw reject();}
        replies++;next++;inFlight=false;
    }
    synchronized void revoke(){revoked=true;}
    synchronized boolean isRevoked(){return revoked;}
    synchronized boolean revokedPendingSecond(){return revoked&&clock.now()<expires&&inFlight&&next==2&&attempts==2&&replies==1&&denials==0;}
    synchronized boolean revokedSecondRejected(){return revoked&&clock.now()<expires&&inFlight&&next==2&&attempts==2&&replies==1&&denials==1;}
    synchronized boolean revocationEvidence(){return revokedSecondRejected()&&transactions==2&&synchronousFlags(observedFlags)&&firstFailure==Stage.COMMIT&&pinned>=0&&requestHashes[0]!=null&&requestHashes[1]!=null;}
    synchronized int pinnedUid(){return pinned;}
    synchronized void malformed(){if(!revoked){revoked=true;denials++;}}
    synchronized void malformed(Stage stage){if(firstFailure==Stage.NONE)firstFailure=stage;malformed();}
    synchronized boolean success(){return !revoked&&!inFlight&&clock.now()<expires&&attempts==2&&replies==2&&denials==0&&next==3;}
    synchronized String report(){return "modelRequests="+attempts+" modelReplies="+replies+" modelDenials="+denials+" modelUID="+pinned+" request1SHA256="+requestHashes[0]+" request2SHA256="+requestHashes[1]+" modelTransactions="+transactions+" modelFlags=0x"+Integer.toHexString(observedFlags)+" modelFirstFailure="+firstFailure;}
    static String hex(byte[] bytes){StringBuilder s=new StringBuilder();for(byte b:bytes)s.append(String.format(java.util.Locale.ROOT,"%02x",b&255));return s.toString();}
}
