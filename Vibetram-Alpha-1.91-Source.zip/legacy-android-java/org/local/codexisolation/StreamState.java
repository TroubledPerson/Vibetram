// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;
import java.security.MessageDigest;

/** Grant authority and serialization share a lock; no waiting or Binder calls under it. */
final class StreamState {
    interface Sink {void write(byte[] frame);}
    final long generation;private final byte[] token;private final int parentUid;private final GrantState.Clock clock;private final long expires;
    private int uid=-1,id=1,seq,requests,frames,bytes,denials,transactions,cancellations,flags,completedRequests,lateSinkEntries;
    private boolean inFlight,terminal;private String reason="NONE";private byte[] payload;private long requestExpiry;
    private final String[] hashes=new String[2];private byte[] noteHash;
    StreamState(byte[] token,long generation,int parentUid,GrantState.Clock clock){this.token=token.clone();this.generation=generation;this.parentUid=parentUid;this.clock=clock;expires=clock.now()+12000;}
    private SecurityException reject(String why){if(reason.equals("NONE"))reason=why;terminal=true;denials=Math.min(99,denials+1);return new SecurityException("Stream rejected");}
    private void authority(byte[] supplied,long gen,int caller,int f){if(!ModelState.synchronousFlags(f)||supplied==null||!MessageDigest.isEqual(token,supplied)||gen!=generation||caller<0||caller==parentUid||(uid!=-1&&uid!=caller))throw reject("AUTHORITY");if(uid==-1)uid=caller;}
    synchronized int begin(byte[] supplied,long gen,int caller,int f,byte[] wire){
        transactions=Math.min(99,transactions+1);flags=f;authority(supplied,gen,caller,f);
        if(terminal||clock.now()>=expires||inFlight||id>2||wire==null||wire.length<10||wire.length>ModelPolicy.MAX_WIRE)throw reject("AUTHORITY");
        if(seq==0){if(!StreamProtocol.magic(wire,"MBQ1")||wire[4]!=id)throw reject("ORDER");requests++;hashes[id-1]=ModelState.hex(GrantState.digest(wire));requestExpiry=clock.now()+5000;}
        else if(!StreamProtocol.magic(wire,"MBN1")||wire.length!=10||wire[4]!=id||StreamProtocol.sequence(wire)!=seq||wire[9]!=0)throw reject("ORDER");
        if(clock.now()>=requestExpiry||seq>=StreamProtocol.MAX_FRAMES||frames>=32)throw reject("BUDGET");inFlight=true;return (id<<8)|seq;
    }
    synchronized void setPayload(int ticket,byte[] reply){check(ticket);if(seq!=0||payload!=null)throw reject("ORDER");payload=StreamProtocol.payload(id,reply);if(id==2)noteHash=GrantState.digest(java.util.Arrays.copyOfRange(payload,10,payload.length));}
    private void check(int ticket){if(terminal||clock.now()>=expires||clock.now()>=requestExpiry||!inFlight||ticket!=((id<<8)|seq))throw reject("COMMIT");}
    synchronized void commit(int ticket,Sink sink){check(ticket);if(payload==null)throw reject("POLICY");byte[] frame=StreamProtocol.frame(id,seq,payload);int n=frame.length-12;
        if(bytes+n>2*StreamProtocol.MAX_TOTAL)throw reject("BUDGET");
        try{if(terminal){lateSinkEntries++;throw reject("LATE_SINK");}sink.write(frame);}catch(RuntimeException e){throw reject("SINK");}
        frames++;bytes+=n;inFlight=false;seq++;if(frame[9]==StreamProtocol.COMPLETED){completedRequests++;id++;seq=0;payload=null;}
    }
    synchronized void cancel(String why){terminal=true;if(reason.equals("NONE"))reason=why;}
    synchronized void authenticatedCancel(byte[] supplied,long gen,int caller,int f){authority(supplied,gen,caller,f);cancellations=Math.min(99,cancellations+1);cancel("CANCELLED");}
    synchronized void malformed(){cancel("MALFORMED");}
    synchronized int pinnedUid(){return uid;}
    synchronized boolean revoked(){return terminal;}
    synchronized boolean pendingHeld(){return id==2&&seq==2&&inFlight&&frames==7&&requests==2&&completedRequests==1;}
    synchronized boolean success(){return !terminal&&clock.now()<expires&&id==3&&!inFlight&&frames==14&&bytes==105&&requests==2&&completedRequests==2&&denials==0&&transactions==14;}
    synchronized boolean negative(String expectedReason,byte[] expectedHash){return terminal&&reason.equals(expectedReason)&&pendingHeld()&&denials==1&&transactions==8&&bytes==35&&lateSinkEntries==0&&clock.now()<expires&&clock.now()<requestExpiry&&noteHash!=null&&MessageDigest.isEqual(noteHash,expectedHash);}
    synchronized String report(){return "requests="+requests+" frames="+frames+" payloadBytes="+bytes+" completedRequests="+completedRequests+" denials="+denials+" transactions="+transactions+" cancellations="+cancellations+" UID="+uid+" flags=0x"+Integer.toHexString(flags)+" reason="+reason+" lateSinkEntries="+lateSinkEntries+" request1SHA256="+hashes[0]+" request2SHA256="+hashes[1];}
}
