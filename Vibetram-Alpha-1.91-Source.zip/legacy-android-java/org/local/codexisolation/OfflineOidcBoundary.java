// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.PublicKey;
import java.security.Signature;
import java.util.Base64;
import java.util.Map;

/** Offline validation boundary. TLS provenance must be supplied by the parent transport. */
final class OfflineOidcBoundary {
    static final class TransportEvidence {
        final boolean https, hostnameVerified, chainVerified;
        final String issuerOrigin;
        TransportEvidence(boolean https, boolean hostnameVerified, boolean chainVerified, String issuerOrigin) {
            this.https=https; this.hostnameVerified=hostnameVerified; this.chainVerified=chainVerified; this.issuerOrigin=issuerOrigin;
        }
    }
    @SuppressWarnings("unchecked")
    static void validate(String jwt, String issuer, String clientId, String nonce,
                         long nowSeconds, PublicKey trustedKey, TransportEvidence tls) {
        if(tls==null || !tls.https || !tls.hostnameVerified || !tls.chainVerified ||
                !issuer.equals(tls.issuerOrigin) || !issuer.startsWith("https://") ||
                trustedKey==null || jwt==null || jwt.length()>8192)
            throw new SecurityException("OIDC transport or key untrusted");
        String[] parts=jwt.split("\\.",-1);
        if(parts.length!=3) throw new SecurityException("Invalid ID token");
        try {
            byte[] header=Base64.getUrlDecoder().decode(parts[0]);
            byte[] body=Base64.getUrlDecoder().decode(parts[1]);
            byte[] signature=Base64.getUrlDecoder().decode(parts[2]);
            if(header.length>1024 || body.length>4096 || signature.length>512) throw new SecurityException("ID token bounds");
            Map<String,Object> h=(Map<String,Object>)BoundedJson.parse(header);
            Map<String,Object> claims=(Map<String,Object>)BoundedJson.parse(body);
            if(!"RS256".equals(h.get("alg")) ||
                    !(h.size()==1 || (h.size()==2 && "JWT".equals(h.get("typ")))))
                throw new SecurityException("ID token algorithm or key source");
            Signature verifier=Signature.getInstance("SHA256withRSA");
            verifier.initVerify(trustedKey);
            verifier.update((parts[0]+"."+parts[1]).getBytes(StandardCharsets.US_ASCII));
            if(!verifier.verify(signature) || !issuer.equals(claims.get("iss")) ||
                    !clientId.equals(claims.get("aud")) ||
                    !MessageDigest.isEqual(nonce.getBytes(StandardCharsets.US_ASCII),
                            String.valueOf(claims.get("nonce")).getBytes(StandardCharsets.US_ASCII)))
                throw new SecurityException("ID token signature or claims");
            Object subject=claims.get("sub");
            if(!(subject instanceof String) || ((String)subject).isEmpty() || ((String)subject).length()>256)
                throw new SecurityException("ID token subject");
            long exp=number(claims.get("exp")), iat=number(claims.get("iat"));
            if(exp<=nowSeconds || exp>nowSeconds+3600 || iat>=exp || iat>nowSeconds+60 || iat<nowSeconds-3600)
                throw new SecurityException("ID token time");
        } catch(SecurityException e) { throw e; }
        catch(Exception e) { throw new SecurityException("Invalid ID token",e); }
    }
    private static long number(Object value) {
        if(!(value instanceof java.math.BigDecimal)) throw new SecurityException("ID token number");
        return ((java.math.BigDecimal)value).longValueExact();
    }
}
