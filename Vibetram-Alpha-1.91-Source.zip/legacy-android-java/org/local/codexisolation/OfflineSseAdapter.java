// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Parent-side UTF-8/SSE parser. Emits small, provider-free capability messages. */
final class OfflineSseAdapter {
    interface Mapper { Mapped map(String eventName,String payload); }
    static final class Mapped {
        final String kind,text;
        Mapped(String kind,String text) { this.kind=kind;this.text=text; }
    }
    static final class Message {
        final long requestId; final int sequence; final String kind, text;
        Message(long requestId,int sequence,String kind,String text) {
            this.requestId=requestId; this.sequence=sequence; this.kind=kind; this.text=text;
        }
    }
    private final long requestId;
    private final Mapper mapper;
    private final ByteArrayOutputStream line=new ByteArrayOutputStream();
    private final StringBuilder data=new StringBuilder();
    private String event="";
    private int bytes, sequence, textBytes;
    private boolean finished, cancelled;
    OfflineSseAdapter(long requestId) { this(requestId,new FixtureMapper()); }
    OfflineSseAdapter(long requestId,Mapper mapper) {
        if(requestId<=0 || mapper==null)throw new IllegalArgumentException();
        this.requestId=requestId;this.mapper=mapper;
    }
    List<Message> feed(byte[] chunk) {
        if(finished || cancelled) throw new SecurityException("Stream closed");
        if(chunk==null || chunk.length>8192 || bytes+chunk.length>65536) { cancel(); throw new SecurityException("Stream bounds"); }
        bytes+=chunk.length;
        List<Message> out=new ArrayList<>();
        try {
            for(byte b:chunk) {
                if(finished)throw new SecurityException("Trailing stream bytes");
                if(b=='\n') { parseLine(out); line.reset(); }
                else { if(line.size()>=8192)throw new SecurityException("SSE line bound"); line.write(b); }
            }
        } catch(SecurityException e) { cancel(); throw e; }
        return out;
    }
    private void parseLine(List<Message> out) {
        byte[] raw=line.toByteArray();
        int n=raw.length;
        if(n>0 && raw[n-1]=='\r')n--;
        String value;
        try { value=StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(raw,0,n)).toString(); }
        catch(CharacterCodingException e) { throw new SecurityException("Invalid SSE UTF-8"); }
        if(value.isEmpty()) { dispatch(out); return; }
        if(value.charAt(0)==':')return;
        int colon=value.indexOf(':');
        String field=colon<0?value:value.substring(0,colon);
        String v=colon<0?"":value.substring(colon+1);
        if(v.startsWith(" "))v=v.substring(1);
        if("data".equals(field)) { if(data.length()+v.length()>16384)throw new SecurityException("SSE event bound");
            if(data.length()>0)data.append('\n'); data.append(v); }
        else if("event".equals(field)) { if(v.length()>128)throw new SecurityException("SSE event name"); event=v; }
        else if(!"id".equals(field) && !"retry".equals(field))throw new SecurityException("Unsupported SSE field");
    }
    private void dispatch(List<Message> out) {
        if(data.length()==0) { event=""; return; }
        String payload=data.toString(), eventName=event; data.setLength(0); event="";
        if("[DONE]".equals(payload)) { emit(out,"done",""); finished=true; return; }
        Mapped mapped=mapper.map(eventName,payload);
        if(mapped==null)return;
        if("done".equals(mapped.kind) && "".equals(mapped.text)) { emit(out,"done",""); finished=true; return; }
        if(!"text".equals(mapped.kind) || mapped.text==null)throw new SecurityException("SSE mapping shape");
        int count=mapped.text.getBytes(StandardCharsets.UTF_8).length;
        if(count>2048 || textBytes+count>32768)throw new SecurityException("SSE text bound");
        textBytes+=count; emit(out,"text",mapped.text);
    }
    private static final class FixtureMapper implements Mapper {
        @SuppressWarnings("unchecked") public Mapped map(String eventName,String payload) {
            Object parsed=BoundedJson.parse(payload.getBytes(StandardCharsets.UTF_8));
            if(!(parsed instanceof Map))throw new SecurityException("SSE event shape");
            Map<String,Object> obj=(Map<String,Object>)parsed;
            Object type=obj.get("type");
            if(!(type instanceof String) || (!eventName.isEmpty() && !eventName.equals(type)))
                throw new SecurityException("SSE event/type mismatch");
            if("response.output_text.delta".equals(type)) {
                Object delta=obj.get("delta");
                if(!(delta instanceof String))throw new SecurityException("SSE delta shape");
                return new Mapped("text",(String)delta);
            }
            if("response.completed".equals(type))return new Mapped("done","");
            if("response.created".equals(type) || "response.in_progress".equals(type))return null;
            throw new SecurityException("Unsupported SSE event");
        }
    }
    private void emit(List<Message> out,String kind,String text) {
        if(sequence>=256)throw new SecurityException("SSE message bound");
        out.add(new Message(requestId,++sequence,kind,text));
    }
    void cancel() { cancelled=true; line.reset(); data.setLength(0); event=""; }
    void endOfInput() { if(!finished || line.size()!=0 || data.length()!=0) { cancel(); throw new SecurityException("Incomplete SSE stream"); } }
    boolean closed() { return finished || cancelled; }
}
