// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;
import java.util.Arrays;
final class StreamProof {
    static boolean accept(int mode,boolean envelope,int status,byte[] proof,StreamState model,StreamGate gate,GrantState note,byte[] expected,long generation){
        if(!envelope||model.pinnedUid()<0||model.pinnedUid()!=note.pinnedUid()||note.traceOverflowed()||!note.preliminary(expected)||!Arrays.equals(note.counts(),new int[]{1,1,1,0,0}))return false;
        if(mode==StreamGate.SUCCESS){
            if(status!=ProbeReply.OK||!model.success())return false;
            try{OutputProof decoded=OutputProof.parse(proof,expected);return note.finish(decoded.noteHash,generation)&&Arrays.equals(note.counts(),new int[]{1,1,1,0,1});}catch(RuntimeException e){return false;}
        }
        return (mode==StreamGate.REVOKE||mode==StreamGate.TIMEOUT)&&gate.mode==mode&&status==ProbeReply.NATIVE_NULL&&proof==null&&gate.proven()&&model.negative(mode==StreamGate.REVOKE?"REVOKED":"TIMEOUT",expected);
    }
}
