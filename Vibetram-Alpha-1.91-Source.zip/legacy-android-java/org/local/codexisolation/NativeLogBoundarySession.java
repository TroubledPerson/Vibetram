// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.stream.Stream;

/** Offline-only native trace fixture. Never issues an account/login request. */
final class NativeLogBoundarySession {
    private static final String MARKER="CORETEST_DUMMY_TRACE_9C6D28AF_20261010";
    private static final byte[] MARKER_BYTES=MARKER.getBytes(StandardCharsets.UTF_8);
    private static final byte[] INIT=("{\"id\":1,\"method\":\"initialize\",\"params\":{\"clientInfo\":{\"name\":\"native-log-boundary\",\"title\":\"Offline Native Log Fixture\",\"version\":\"1\"}}}\n").getBytes(StandardCharsets.UTF_8);
    private static final byte[] INITIALIZED="{\"method\":\"initialized\"}\n".getBytes(StandardCharsets.UTF_8);
    private static final byte[] ACCOUNT_READ="{\"id\":2,\"method\":\"account/read\",\"params\":{\"refreshToken\":false}}\n".getBytes(StandardCharsets.UTF_8);
    enum Mode { GRACEFUL, CANCELLED }
    static final class GateException extends Exception {
        final String code;
        GateException(String code){super(code);this.code=code;}
    }
    static final class Result {
        final Mode mode;final int files,sidecars;
        Result(Mode mode,int files,int sidecars){this.mode=mode;this.files=files;this.sidecars=sidecars;}
    }
    private final OfflineAppServerAdapter.ProcessFactory factory;
    private volatile Process activeChild;
    private volatile boolean stoppedByUser;
    NativeLogBoundarySession(OfflineAppServerAdapter.ProcessFactory factory){this.factory=factory;}
    void cancel(){
        stoppedByUser=true;
        Process child=activeChild;
        if(child!=null)try{child.destroyForcibly();}catch(RuntimeException ignored){}
    }

    Result run(File filesDir,File binary,Mode mode) throws GateException {
        Process child=null;
        ExecutorService readers=Executors.newFixedThreadPool(2);
        String phase="HOME";
        try {
            File parent=filesDir.getCanonicalFile();
            require(parent.isDirectory(),"PRIVATE_FILES_MISSING");
            File fixtureRoot=new File(parent,"native-log-fixture-homes").getCanonicalFile();
            require(parent.equals(fixtureRoot.getParentFile()),"FIXTURE_ROOT_INVALID");
            Files.createDirectories(fixtureRoot.toPath());
            File home=new File(fixtureRoot,UUID.randomUUID().toString()).getCanonicalFile();
            require(fixtureRoot.equals(home.getParentFile())&&!home.exists(),"FIXTURE_HOME_INVALID");
            Files.createDirectory(home.toPath());
            require(binary.isFile()&&binary.canExecute(),"NATIVE_BINARY_UNAVAILABLE");
            // Verify the scanner with a dummy file, then remove it before the child starts.
            Path control=new File(home,"scanner-control.bin").toPath();
            Files.write(control,MARKER_BYTES);
            require(containsMarker(Files.readAllBytes(control)),"SCANNER_CONTROL_FAILED");
            Files.delete(control);
            Map<String,String> env=new HashMap<>();
            env.put("PATH","/system/bin");env.put("HOME",home.getPath());
            env.put("CODEX_HOME",home.getPath());env.put("RUST_LOG","warn");
            env.put("CODEX_CORETEST_OFFLINE_TRACE_MARKER","1");
            phase="PROCESS_START";
            child=factory.start(Arrays.asList(binary.getAbsolutePath(),"--listen","stdio://","-c",
                    "cli_auth_credentials_store=\"ephemeral\"","-c","features.plugins=false",
                    "-c","features.remote_plugin=false","--disable-plugin-startup-tasks-for-tests"),env);
            activeChild=child;
            require(!stoppedByUser,"CANCELLED");
            final Process running=child;
            AtomicBoolean killRequested=new AtomicBoolean();
            Future<StderrCapture> stderr=readers.submit(()->readBounded(running.getErrorStream(),
                    64*1024,killRequested));
            OutputStream stdin=child.getOutputStream();
            InputStream stdout=child.getInputStream();
            phase="INITIALIZE";
            stdin.write(INIT);stdin.flush();
            Map<?,?> init=reply(stdout,readers,1);
            Map<?,?> result=object(init.get("result"),"INITIALIZE_FAILED");
            require(home.getPath().equals(result.get("codexHome"))
                    &&"android".equals(result.get("platformOs")),"INITIALIZE_BOUNDARY_FAILED");
            phase="ACCOUNT_READ";
            stdin.write(INITIALIZED);stdin.write(ACCOUNT_READ);stdin.flush();
            Map<?,?> account=object(reply(stdout,readers,2).get("result"),"ACCOUNT_READ_FAILED");
            require(account.containsKey("account")&&account.get("account")==null,"ACCOUNT_NOT_EMPTY");
            phase="EXIT";
            if(mode==Mode.GRACEFUL){
                stdin.close();
                require(child.waitFor(8,TimeUnit.SECONDS)&&child.exitValue()==0,"GRACEFUL_EXIT_FAILED");
            }else{
                require(child.isAlive(),"CHILD_EXITED_EARLY");
                killRequested.set(true);
                child.destroyForcibly();
                require(child.waitFor(3,TimeUnit.SECONDS)&&!child.isAlive(),"CANCEL_EXIT_FAILED");
            }
            phase="STDERR";
            StderrCapture captured=stderr.get(3,TimeUnit.SECONDS);
            // Android may close a killed child's pipe with IOException. Accept
            // only after confirmed cancellation exit and a captured marker.
            require(!captured.readError||mode==Mode.CANCELLED,"STDERR_READ_FAILED");
            require(containsMarker(captured.bytes),"NATIVE_MARKER_NOT_EMITTED");
            phase="SCAN";
            Scan scan=scan(home.toPath());
            require(scan.logsDb,"LOG_DB_NOT_CREATED");
            require(!scan.markerOnDisk,"MARKER_ON_DISK");
            require(!new File(home,"auth.json").exists(),"AUTH_JSON_CREATED");
            return new Result(mode,scan.files,scan.sidecars);
        } catch(GateException e){throw e;}
        catch(Exception e){throw new GateException(phase+"_FAILED");}
        finally {
            if(child!=null&&child.isAlive()){
                try {child.destroyForcibly();
                    if(!child.waitFor(3,TimeUnit.SECONDS)||child.isAlive())
                    throw new GateException("CHILD_STILL_RUNNING");}
                catch(InterruptedException e){Thread.currentThread().interrupt();throw new GateException("CHILD_STILL_RUNNING");}
                catch(RuntimeException e){throw new GateException("CHILD_STILL_RUNNING");}
            }
            readers.shutdownNow();
            activeChild=null;
        }
    }
    private static Map<?,?> reply(InputStream in,ExecutorService readers,int id) throws Exception {
        for(int i=0;i<8;i++){
            byte[] line=readers.submit(()->readLine(in)).get(15,TimeUnit.SECONDS);
            Map<?,?> frame=object(BoundedJson.parse(line),"NON_OBJECT_FRAME");
            if(BigDecimal.valueOf(id).equals(frame.get("id"))){
                require(!frame.containsKey("error"),"RPC_REJECTED");return frame;
            }
            require(!frame.containsKey("id")&&frame.get("method") instanceof String,
                    "UNEXPECTED_FRAME");
        }
        throw new GateException("REPLY_MISSING");
    }
    private static byte[] readLine(InputStream in) throws IOException {
        ByteArrayOutputStream bytes=new ByteArrayOutputStream();
        while(true){int b=in.read();if(b<0)throw new IOException("EOF");if(b=='\n')return bytes.toByteArray();
            if(bytes.size()>=16*1024)throw new IOException("FRAME_OVERSIZE");bytes.write(b);}
    }
    private static final class StderrCapture {
        final byte[] bytes;final boolean readError;
        StderrCapture(byte[] bytes,boolean readError){this.bytes=bytes;this.readError=readError;}
    }
    private static StderrCapture readBounded(InputStream in,int limit,
            AtomicBoolean killRequested) throws IOException {
        ByteArrayOutputStream bytes=new ByteArrayOutputStream();byte[] buffer=new byte[1024];int n;
        try {
            while((n=in.read(buffer))!=-1){if(n>limit-bytes.size())throw new IOException("STDERR_OVERSIZE");
                bytes.write(buffer,0,n);}
        }catch(IOException e){
            if("STDERR_OVERSIZE".equals(e.getMessage()))throw e;
            if(!killRequested.get())throw e;
            return new StderrCapture(bytes.toByteArray(),true);
        }
        return new StderrCapture(bytes.toByteArray(),false);
    }
    private static final class Scan {
        int files,sidecars;boolean logsDb,markerOnDisk;
    }
    private static Scan scan(Path home) throws Exception {
        Scan result=new Scan();long total=0;
        try(Stream<Path> paths=Files.walk(home)){
            for(Path path:(Iterable<Path>)paths::iterator){
                if(path.equals(home)||Files.isDirectory(path,LinkOption.NOFOLLOW_LINKS))continue;
                require(!Files.isSymbolicLink(path)&&Files.isRegularFile(path,LinkOption.NOFOLLOW_LINKS),
                        "UNEXPECTED_FIXTURE_ENTRY");
                long size=Files.size(path);total+=size;
                require(size<=32L*1024*1024&&total<=128L*1024*1024,"FIXTURE_FILE_OVERSIZE");
                result.files++;
                String name=path.getFileName().toString();
                if("logs_2.sqlite".equals(name))result.logsDb=true;
                if(name.endsWith("-wal")||name.endsWith("-shm"))result.sidecars++;
                if(containsMarker(Files.readAllBytes(path)))result.markerOnDisk=true;
            }
        }
        return result;
    }
    private static boolean containsMarker(byte[] bytes){
        outer:for(int i=0;i<=bytes.length-MARKER_BYTES.length;i++){
            for(int j=0;j<MARKER_BYTES.length;j++)if(bytes[i+j]!=MARKER_BYTES[j])continue outer;
            return true;
        }
        return false;
    }
    private static Map<?,?> object(Object value,String code) throws GateException {
        if(!(value instanceof Map))throw new GateException(code);return (Map<?,?>)value;
    }
    private static void require(boolean ok,String code) throws GateException {if(!ok)throw new GateException(code);}
}
