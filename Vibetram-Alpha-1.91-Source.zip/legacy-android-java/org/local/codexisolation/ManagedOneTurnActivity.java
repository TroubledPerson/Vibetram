// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.WindowInsets;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.File;

/** One explicit sign-in, then one separate explicit Send in the same native child. */
public final class ManagedOneTurnActivity extends Activity {
    private static final Handler MAIN=new Handler(Looper.getMainLooper());
    private static Attempt active;
    private static String pendingDraft="";
    private static final class Attempt {
        final ManagedOneTurnSession session=new ManagedOneTurnSession(OfflineAppServerAdapter.SYSTEM);
        ManagedOneTurnActivity screen;
        String code="",draft="",answer="",line="STATE=STARTING";
        boolean ready,sent,done,settled;
        volatile boolean foreground,browserOpened;
        void render(){if(screen!=null)screen.render(this);}
    }
    private Button start,open,send,cancel,reset;
    private TextView code,report,answer;
    private EditText promptInput;
    private boolean destroyed,restoredWithoutProcess;
    @Override public void onCreate(Bundle saved){
        super.onCreate(saved);
        restoredWithoutProcess=active==null&&saved!=null&&saved.getBoolean("attempted");
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setOnApplyWindowInsetsListener((v,insets)->{
            if(Build.VERSION.SDK_INT>=30){
                android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout());
                v.setPadding(bars.left,bars.top,bars.right,bars.bottom);
            }else v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),
                    insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());
            return insets;
        });
        start=new Button(this);start.setText("START ONE CHATGPT SIGN-IN");
        open=new Button(this);open.setText("OPEN OPENAI VERIFICATION PAGE");
        send=new Button(this);send.setText("SEND ONE SHORT MODEL REQUEST");
        cancel=new Button(this);cancel.setText("CANCEL AND CLOSE SESSION");
        reset=new Button(this);reset.setText("RESET AFTER RESULT");
        code=new TextView(this);code.setTextSize(22);code.setTextIsSelectable(false);
        promptInput=new EditText(this);promptInput.setHint("Your prompt (1–256 characters)");
        promptInput.setSingleLine(true);promptInput.setSaveEnabled(false);
        promptInput.setFocusableInTouchMode(true);promptInput.setShowSoftInputOnFocus(true);
        promptInput.setFilters(new InputFilter[]{new InputFilter.LengthFilter(ShortPromptBoundary.MAX_UTF16_UNITS)});
        promptInput.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            public void onTextChanged(CharSequence s,int start,int before,int count){}
            public void afterTextChanged(Editable s){
                if(destroyed)return;
                Attempt attempt=active;
                if(attempt==null)pendingDraft=s.toString();
                else if(attempt.screen==ManagedOneTurnActivity.this&&!attempt.sent)
                    attempt.draft=s.toString();
            }
        });
        answer=new TextView(this);answer.setTextIsSelectable(true);
        report=new TextView(this);report.setTextIsSelectable(true);
        root.addView(start);root.addView(open);root.addView(code);root.addView(promptInput);
        root.addView(send);root.addView(cancel);root.addView(reset);root.addView(answer);
        ScrollView scroll=new ScrollView(this);scroll.addView(report);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);root.requestApplyInsets();
        if(active!=null){active.screen=this;active.render();}else render(null);
        start.setOnClickListener(v->{
            if(active!=null||restoredWithoutProcess)return;
            if(Build.VERSION.SDK_INT<29||!"arm64-v8a".equals(Build.SUPPORTED_ABIS[0])){
                report.append("FAIL code=UNSUPPORTED_DEVICE\n");start.setEnabled(false);return;
            }
            Attempt attempt=new Attempt();attempt.draft=promptInput.getText().toString();
            active=attempt;pendingDraft="";attempt.screen=this;attempt.foreground=true;attempt.render();
            File binary=new File(getApplicationInfo().nativeLibraryDir,"libcodex_app_server.so");
            File filesDir=getFilesDir();
            new Thread(()->runAttempt(attempt,filesDir,binary),"managed-one-turn-parent").start();
        });
        open.setOnClickListener(v->{
            Attempt attempt=active;if(attempt==null||attempt.code.isEmpty()||attempt.done)return;
            attempt.browserOpened=true;
            startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(ManagedOneTurnSession.VERIFY_URL)));
        });
        send.setOnClickListener(v->{
            Attempt attempt=active;if(attempt==null||!attempt.ready||attempt.sent||attempt.done)return;
            String text=promptInput.getText().toString();
            String issue=ShortPromptBoundary.check(text);
            if(issue!=null){attempt.line="STATE=SIGNED_IN_EPHEMERAL_READY_TO_SEND code="+issue;
                attempt.render();return;}
            if(attempt.session.requestSend(text)){
                attempt.sent=true;attempt.draft="";attempt.code="";
                promptInput.setText("");attempt.line="STATE=ONE_TURN_REQUESTED";attempt.render();
            }
        });
        cancel.setOnClickListener(v->{
            Attempt attempt=active;if(attempt!=null&&!attempt.done){
                attempt.code="";attempt.draft="";promptInput.setText("");
                attempt.line="STATE=CANCELLED";attempt.done=true;attempt.render();
                attempt.session.cancel();
            }
        });
        reset.setOnClickListener(v->{
            if(active!=null&&!active.settled)return;
            pendingDraft=promptInput.getText().toString();
            active=null;restoredWithoutProcess=false;render(null);
        });
    }
    private static void runAttempt(Attempt attempt,File filesDir,File binary){
        String outcome,response="";
        try{
            ManagedOneTurnSession.Result result=attempt.session.run(filesDir,binary,new ManagedOneTurnSession.Events(){
                public void showCode(String userCode){
                    MAIN.post(()->{if(active==attempt&&!attempt.done){
                        attempt.code=userCode;attempt.line="STATE=AWAITING_USER_ON_OPENAI_PAGE";attempt.render();
                    }});
                }
                public void ready(){
                    MAIN.post(()->{if(active==attempt&&!attempt.done){
                        attempt.code="";attempt.ready=true;attempt.line="STATE=SIGNED_IN_EPHEMERAL_READY_TO_SEND";
                        attempt.render();
                    }});
                }
            });
            response=result.text;
            outcome="PASS stage="+attempt.session.stage()+" turn="+result.status+" deltas="+result.deltas
                    +" answer="+("READY".equals(result.text.trim())?"READY":"OTHER_BOUNDED")
                    +" answerChars="+result.text.length()
                    +" authJson=ABSENT credentials=EPHEMERAL turnStarts=1";
        }catch(ManagedOneTurnSession.GateException e){
            outcome="FAIL/INCONCLUSIVE stage="+attempt.session.stage()+" code="+e.code
                    +" browserOpened="+attempt.browserOpened+" foregroundAtFailure="+attempt.foreground;
        }
        final String line=outcome;
        final String responseText=response;
        MAIN.post(()->{if(active==attempt){
            attempt.code="";if(attempt.sent)attempt.draft="";attempt.answer=responseText;
            attempt.done=true;attempt.settled=true;
            if(!"STATE=CANCELLED".equals(attempt.line))attempt.line=line;
            attempt.render();
        }});
    }
    private void render(Attempt attempt){
        String header="1.49 user-prompt diagnostic. Sign in first; no model request occurs until you tap Send. "
                +"Enter one short prompt (1–256 characters). One request may use subscription quota. "
                +"No tools, file edits, saved login, or automatic retry.\n";
        if(attempt==null){
            code.setText("");start.setEnabled(!restoredWithoutProcess);open.setEnabled(false);
            if(!promptInput.getText().toString().equals(pendingDraft))promptInput.setText(pendingDraft);
            promptInput.setEnabled(PromptScreenRules.inputEnabled(false));answer.setText("");
            send.setEnabled(false);cancel.setEnabled(false);
            reset.setEnabled(PromptScreenRules.resetEnabled(false,restoredWithoutProcess));
            report.setText(header+(restoredWithoutProcess?"STATE=PROCESS_RESTARTED; prior in-memory session is gone.\n":""));
            return;
        }
        code.setText(attempt.code.isEmpty()?"":"Code: "+attempt.code);
        if(!promptInput.getText().toString().equals(attempt.draft))promptInput.setText(attempt.draft);
        promptInput.setEnabled(PromptScreenRules.inputEnabled(attempt.sent));
        answer.setText(attempt.answer.isEmpty()?"":"Response:\n"+attempt.answer);
        start.setEnabled(false);open.setEnabled(!attempt.code.isEmpty()&&!attempt.done);
        send.setEnabled(PromptScreenRules.sendEnabled(attempt.ready,attempt.sent,attempt.done));
        cancel.setEnabled(!attempt.done);
        reset.setEnabled(PromptScreenRules.resetEnabled(attempt.settled,false));
        report.setText(header+attempt.line+"\n");
    }
    @Override protected void onSaveInstanceState(Bundle out){out.putBoolean("attempted",active!=null||restoredWithoutProcess);super.onSaveInstanceState(out);}
    @Override protected void onStart(){
        super.onStart();Attempt attempt=active;
        if(attempt!=null&&attempt.screen==this)attempt.foreground=true;
    }
    @Override protected void onStop(){
        Attempt attempt=active;
        if(attempt!=null&&attempt.screen==this){
            attempt.foreground=false;
            if(attempt.sent&&!attempt.done)attempt.session.cancel();
            else if(!attempt.sent)attempt.draft=promptInput.getText().toString();
        }else if(attempt==null)pendingDraft=promptInput.getText().toString();
        super.onStop();
    }
    @Override protected void onDestroy(){
        destroyed=true;Attempt attempt=active;
        if(attempt!=null&&attempt.screen==this){
            attempt.screen=null;if(isFinishing()&&!attempt.done)attempt.session.cancel();
        }
        code.setText("");promptInput.setText("");super.onDestroy();
    }
}
