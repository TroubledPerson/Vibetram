// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

/** Fixed diagnostic categories only; never displays arbitrary exception text or pixel data. */
final class OneShotPngFailure {
 static String category(RuntimeException error){
  String reason=error==null?null:error.getMessage();
  if("PNG_SIZE_LIMIT".equals(reason))return "LOCAL_PNG_SIZE_LIMIT_REJECTED";
  if("PNG_LADDER_EXHAUSTED".equals(reason))return "LOCAL_PNG_LADDER_EXHAUSTED_REJECTED";
  if("SAME_FRAME_PROCESSING_REVOKED".equals(reason))return "LOCAL_FRAME_PROCESSING_REVOKED";
  if("UNIFORM_OR_BLANK_FRAME_REJECTED".equals(reason))return "LOCAL_PNG_BLANK_FRAME_REJECTED";
  if("PNG_ENCODING_FAILED".equals(reason))return "LOCAL_PNG_ENCODING_REJECTED";
  if("RGBA_BOUNDS_REJECTED".equals(reason)||"RGBA_BUFFER_TOO_SMALL".equals(reason)||"PNG_IMAGE_INVALID".equals(reason))return "LOCAL_PNG_VALIDATION_REJECTED";
  return "LOCAL_PNG_UNEXPECTED_FAILURE_REJECTED";
 }
}
