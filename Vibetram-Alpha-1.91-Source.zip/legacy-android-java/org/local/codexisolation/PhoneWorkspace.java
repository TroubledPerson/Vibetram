// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

import java.io.File;
import java.io.IOException;
import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.Channels;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** One app-private, fixed-file project. Never handles CODEX_HOME or external paths. */
final class PhoneWorkspace {
    static final int MAX_FILE_BYTES=4096,MAX_PREVIEW_CHARS=4096;
    static final String README="README.md",DATA="project.json";
    private final Path root;
    static final class Snapshot {
        final String text,sha256;final boolean truncated;
        Snapshot(String text,String sha256,boolean truncated){this.text=text;this.sha256=sha256;this.truncated=truncated;}
    }
    static final class Proposal {
        final String name,expectedSha256,newText,diff;
        Proposal(String name,String expectedSha256,String newText,String diff){
            this.name=name;this.expectedSha256=expectedSha256;this.newText=newText;this.diff=diff;
        }
    }
    PhoneWorkspace(File privateFiles) throws Exception {
        Path base=privateFiles.toPath().toRealPath();
        if(!Files.isDirectory(base,LinkOption.NOFOLLOW_LINKS)||Files.isSymbolicLink(base))throw new IOException("PRIVATE_ROOT_INVALID");
        Path projects=base.resolve("phone-projects");
        createDir(projects,base);
        root=projects.resolve("project-one");createDir(root,projects);
        initialize(README,"# Phone project\n\nEdit project.json, then run the built-in JSON check.\n");
        initialize(DATA,"{\"name\":\"Phone project\",\"tasks\":[]}\n");
    }
    Path root(){return root;}
    private static void createDir(Path path,Path parent) throws IOException {
        if(!path.getParent().equals(parent))throw new IOException("DIR_BOUNDARY");
        if(!Files.exists(path,LinkOption.NOFOLLOW_LINKS))Files.createDirectory(path);
        if(Files.isSymbolicLink(path)||!Files.isDirectory(path,LinkOption.NOFOLLOW_LINKS)
                ||!path.toRealPath().equals(path))throw new IOException("DIR_BOUNDARY");
    }
    private Path file(String name) throws IOException {
        if(!README.equals(name)&&!DATA.equals(name))throw new IOException("PATH_NOT_ALLOWED");
        if(Files.isSymbolicLink(root)||!root.toRealPath().equals(root))throw new IOException("ROOT_BOUNDARY");
        Path path=root.resolve(name);
        if(!path.getParent().equals(root)||Files.isSymbolicLink(path))throw new IOException("FILE_BOUNDARY");
        return path;
    }
    private void initialize(String name,String content) throws IOException {
        Path path=file(name);
        if(!Files.exists(path,LinkOption.NOFOLLOW_LINKS))Files.write(path,content.getBytes(StandardCharsets.UTF_8),StandardOpenOption.CREATE_NEW);
        if(!Files.isRegularFile(path,LinkOption.NOFOLLOW_LINKS))throw new IOException("FILE_BOUNDARY");
    }
    Snapshot read(String name) throws Exception {
        Path path=file(name);
        byte[] bytes=readBounded(path);
        String value=decode(bytes);
        int end=Math.min(value.length(),MAX_PREVIEW_CHARS);
        if(end>0&&end<value.length()&&Character.isHighSurrogate(value.charAt(end-1)))end--;
        return new Snapshot(value.substring(0,end),sha(bytes),end<value.length());
    }
    synchronized Proposal propose(String name,String expectedSha256,String replacement) throws Exception {
        Snapshot current=read(name);
        if(expectedSha256==null||!expectedSha256.equals(current.sha256))throw new IOException("STALE_FILE");
        byte[] bytes=validatedText(replacement);
        if(bytes.length>MAX_FILE_BYTES)throw new IOException("REPLACEMENT_TOO_LARGE");
        String diff="--- "+name+" (current)\n"+current.text+"\n+++ "+name+" (proposed)\n"+replacement;
        return new Proposal(name,current.sha256,replacement,diff);
    }
    synchronized String apply(Proposal proposal) throws Exception {
        Path target=file(proposal.name);
        if(!read(proposal.name).sha256.equals(proposal.expectedSha256))throw new IOException("STALE_FILE");
        byte[] bytes=validatedText(proposal.newText);
        Path temp=root.resolve(".workspace-tmp-"+UUID.randomUUID());
        if(!temp.getParent().equals(root))throw new IOException("TEMP_BOUNDARY");
        try {
            try(FileChannel out=FileChannel.open(temp,StandardOpenOption.CREATE_NEW,StandardOpenOption.WRITE)){
                ByteBuffer data=ByteBuffer.wrap(bytes);while(data.hasRemaining())out.write(data);out.force(true);
            }
            if(Files.isSymbolicLink(target)||!Files.isRegularFile(target,LinkOption.NOFOLLOW_LINKS))throw new IOException("FILE_BOUNDARY");
            Files.move(temp,target,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);
        }finally{Files.deleteIfExists(temp);}
        return sha(bytes);
    }
    String check() throws Exception {
        Path target=file(DATA);
        byte[] bytes=readBounded(target);
        Object parsed;
        try{decode(bytes);parsed=BoundedJson.parse(bytes);}catch(Exception e){return "FAIL: project.json is not valid UTF-8 JSON.";}
        if(!(parsed instanceof Map))return "FAIL: project.json must be a JSON object.";
        Map<?,?> object=(Map<?,?>)parsed;
        Object name=object.get("name"),tasks=object.get("tasks");
        if(!(name instanceof String)||((String)name).isBlank()||((String)name).length()>80)
            return "FAIL: name must be 1-80 characters.";
        if(!(tasks instanceof List)||((List<?>)tasks).size()>20)return "FAIL: tasks must be an array of at most 20 items.";
        for(Object task:(List<?>)tasks)if(!(task instanceof String)||((String)task).length()>160)
            return "FAIL: each task must be text of at most 160 characters.";
        return "PASS: project.json is valid with "+((List<?>)tasks).size()+" tasks.";
    }
    private static byte[] validatedText(String text) throws IOException {
        if(text==null||text.indexOf('\0')>=0)throw new IOException("TEXT_INVALID");
        for(int i=0;i<text.length();i++){
            char c=text.charAt(i);
            if(Character.isHighSurrogate(c)){
                if(i+1>=text.length()||!Character.isLowSurrogate(text.charAt(i+1)))throw new IOException("UNICODE_INVALID");
                i++;
            }else if(Character.isLowSurrogate(c))throw new IOException("UNICODE_INVALID");
        }
        byte[] bytes=text.getBytes(StandardCharsets.UTF_8);
        if(bytes.length>MAX_FILE_BYTES)throw new IOException("TEXT_TOO_LARGE");
        return bytes;
    }
    private static String decode(byte[] bytes) throws CharacterCodingException {
        return StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(bytes)).toString();
    }
    private static byte[] readBounded(Path path) throws IOException {
        if(!Files.isRegularFile(path,LinkOption.NOFOLLOW_LINKS))throw new IOException("FILE_TYPE");
        ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] chunk=new byte[512];
        try(FileChannel file=FileChannel.open(path,StandardOpenOption.READ,LinkOption.NOFOLLOW_LINKS);
            java.io.InputStream in=Channels.newInputStream(file)){
            int n;while((n=in.read(chunk))!=-1){
                if(out.size()+n>MAX_FILE_BYTES)throw new IOException("FILE_TOO_LARGE");
                out.write(chunk,0,n);
            }
        }
        return out.toByteArray();
    }
    private static String sha(byte[] bytes) throws NoSuchAlgorithmException {
        byte[] digest=MessageDigest.getInstance("SHA-256").digest(bytes);
        StringBuilder hex=new StringBuilder(64);for(byte b:digest)hex.append(String.format(java.util.Locale.ROOT,"%02x",b&255));return hex.toString();
    }
}
