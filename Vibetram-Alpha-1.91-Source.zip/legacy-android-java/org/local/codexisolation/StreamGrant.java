// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;
import android.os.*;
import java.security.SecureRandom;
/** Per-run offline producer. Every frame is a separately authenticated Binder pull. */
final class StreamGrant extends Binder {
    static final String DESCRIPTOR="org.local.codexisolation.model.stream.v1";
    static final int EXCHANGE=IBinder.FIRST_CALL_TRANSACTION;
    final byte[] token=new byte[32];final long generation;final StreamState state;final StreamGate gate;private final Runnable onHeld;
    StreamGrant(long generation,int mode,Runnable onHeld){new SecureRandom().nextBytes(token);this.generation=generation;state=new StreamState(token,generation,android.os.Process.myUid(),SystemClock::elapsedRealtime);gate=new StreamGate(mode,SystemClock::elapsedRealtime);this.onHeld=onHeld;}
    @Override protected boolean onTransact(int code,Parcel in,Parcel out,int flags)throws RemoteException {
        try{
            if(code!=EXCHANGE||out==null||!ModelState.synchronousFlags(flags)||in.dataSize()>70000)throw new SecurityException("Stream transaction");
            in.enforceInterface(DESCRIPTOR);byte[] supplied=new byte[32];in.readByteArray(supplied);long gen=in.readLong();int length=in.readInt();
            if(length<10||length>ModelPolicy.MAX_WIRE||in.dataAvail()!=4+((length+3)&~3))throw new SecurityException("Stream request bounds");
            byte[] wire=new byte[length];in.readByteArray(wire);if(in.dataAvail()!=0)throw new SecurityException("Trailing stream request");
            if(StreamProtocol.cancel(wire)){state.authenticatedCancel(supplied,gen,Binder.getCallingUid(),flags);gate.cleanup(state);byte[] ack={'M','B','E','1',0,0,0,0,0,5,0,0};write(out,gen,ack);return true;}
            int ticket=state.begin(supplied,gen,Binder.getCallingUid(),flags,wire),id=ticket>>8,seq=ticket&255;
            if(seq==0)state.setPayload(ticket,ModelPolicy.reply(id,wire));
            boolean held=id==2&&seq==2&&gate.mode!=StreamGate.SUCCESS;
            if(held){gate.hold(state,onHeld);gate.beforeCommit();}
            try{state.commit(ticket,frame->{if(held)gate.sinkEntered();write(out,gen,frame);});}catch(SecurityException e){if(held)gate.rejected();throw e;}
            return true;
        }catch(RuntimeException e){state.malformed();gate.cleanup(state);throw new SecurityException("Stream capability rejected");}
    }
    private static void write(Parcel out,long gen,byte[] frame){out.writeNoException();out.writeLong(gen);out.writeInt(frame.length);out.writeByteArray(frame);}
    void revoke(){gate.cleanup(state);}
}
