// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

/** Narrow folder operations used by the tool bridge; Android supplies the SAF implementation. */
interface SelectedFolderAccess {
    final class Proposal {
        final String name,id,expectedSha256,newText,diff;
        Proposal(String name,String id,String expectedSha256,String newText,String diff){
            this.name=name;this.id=id;this.expectedSha256=expectedSha256;this.newText=newText;this.diff=diff;
        }
    }
    String list() throws Exception;
    PhoneWorkspace.Snapshot read(String name) throws Exception;
    Proposal propose(String name,String expectedHash,String replacement) throws Exception;
    String apply(Proposal proposal) throws Exception;
}
