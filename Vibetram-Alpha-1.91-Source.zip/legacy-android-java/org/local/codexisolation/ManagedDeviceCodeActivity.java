// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.File;

/** One user-triggered managed device-code attempt. Never receives a password or token. */
public final class ManagedDeviceCodeActivity extends Activity {
    private static final String VERIFIED_URL="https://auth.openai.com/codex/device";
    private static final Handler MAIN=new Handler(Looper.getMainLooper());
    // Only a live process can retain the pending code. No Bundle, clipboard, file, or log contains it.
    private static Attempt activeAttempt;
    private static final class Attempt {
        final OfflineManagedAuthSession session=new OfflineManagedAuthSession(OfflineAppServerAdapter.SYSTEM);
        final ManagedDeviceCodeUiState state=new ManagedDeviceCodeUiState();
        ManagedDeviceCodeActivity screen;
        void render(){if(screen!=null)screen.render(this);}
    }
    private TextView report,code;
    private Button start,open;
    private boolean interrupted;

    @Override public void onCreate(Bundle saved){
        super.onCreate(saved);
        if(activeAttempt!=null&&activeAttempt.state.terminal()&&saved==null)activeAttempt=null;
        interrupted=activeAttempt==null&&saved!=null&&saved.getBoolean("attempted");
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setOnApplyWindowInsetsListener((v,insets)->{
            if(Build.VERSION.SDK_INT>=30){
                android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout());
                v.setPadding(bars.left,bars.top,bars.right,bars.bottom);
            }else{
                v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),
                        insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());
            }
            return insets;
        });
        start=new Button(this);start.setText("START ONE CHATGPT DEVICE SIGN-IN");
        open=new Button(this);open.setText("OPEN OPENAI VERIFICATION PAGE");
        Button cancel=new Button(this);cancel.setText("CANCEL AND CLEAR CODE");
        code=new TextView(this);code.setTextSize(22);code.setTextIsSelectable(false);
        report=new TextView(this);report.setTextIsSelectable(true);
        root.addView(start);root.addView(open);root.addView(cancel);root.addView(code);
        ScrollView scroll=new ScrollView(this);scroll.addView(report);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);root.requestApplyInsets();
        if(activeAttempt!=null){activeAttempt.screen=this;activeAttempt.render();}else render(null);

        start.setOnClickListener(v->{
            if(interrupted||activeAttempt!=null)return;
            if(Build.VERSION.SDK_INT<29||!"arm64-v8a".equals(Build.SUPPORTED_ABIS[0])){
                report.append("FAIL code=UNSUPPORTED_DEVICE\n");start.setEnabled(false);return;
            }
            Attempt attempt=new Attempt();activeAttempt=attempt;attempt.screen=this;attempt.render();
            File binary=new File(getApplicationInfo().nativeLibraryDir,"libcodex_app_server.so");
            File filesDir=getFilesDir();
            new Thread(()->runAttempt(attempt,filesDir,binary),"managed-device-code-parent").start();
        });
        open.setOnClickListener(v->{
            Attempt attempt=activeAttempt;
            if(attempt==null||!attempt.state.canOpen())return;
            startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(VERIFIED_URL)));
        });
        cancel.setOnClickListener(v->cancelAttempt(activeAttempt));
    }

    private static void runAttempt(Attempt attempt,File filesDir,File binary){
        String outcome;
        boolean success=false;
        try{
            attempt.session.run(filesDir,binary,(url,userCode)->{
                if(!VERIFIED_URL.equals(url))throw new IllegalStateException("UNVERIFIED_URL");
                MAIN.post(()->{if(activeAttempt==attempt&&attempt.state.showCode(userCode))attempt.render();});
            });
            success=true;
            outcome="PASS case=MANAGED_DEVICE_CODE stage="+attempt.session.stage()
                    +" credentials=EPHEMERAL authJson=ABSENT modelRequests=0";
        }catch(OfflineManagedAuthSession.GateException e){
            outcome="FAIL/INCONCLUSIVE case=MANAGED_DEVICE_CODE stage="+attempt.session.stage()+" code="+e.code;
        }
        final boolean passed=success;
        final String line=outcome;
        MAIN.post(()->{if(activeAttempt==attempt){attempt.state.finish(line,passed);attempt.render();}});
    }

    private static void cancelAttempt(Attempt attempt){
        if(attempt!=null&&attempt.state.cancel()){
            attempt.render();
            attempt.session.cancel();
        }
    }
    private void render(Attempt attempt){
        String header="1.37 managed device-code check. One user-triggered sign-in, process-only credentials, no model requests.\n"
                +"Review the permissions shown by OpenAI before consenting. The device-code wait is capped at 15 minutes.\n";
        if(attempt==null){
            code.setText("");open.setEnabled(false);start.setEnabled(!interrupted);
            report.setText(header+(interrupted
                    ?"STATE=INTERRUPTED_PROCESS_RESTART\nCode cleared. Reopen this screen to start a new attempt.\n":""));
            return;
        }
        code.setText(attempt.state.canOpen()?"Code: "+attempt.state.code():"");
        open.setEnabled(attempt.state.canOpen());start.setEnabled(false);
        report.setText(header+attempt.state.report());
    }
    @Override protected void onSaveInstanceState(Bundle out){
        out.putBoolean("attempted",interrupted||activeAttempt!=null);
        super.onSaveInstanceState(out);
    }
    @Override protected void onDestroy(){
        Attempt attempt=activeAttempt;
        if(attempt!=null&&attempt.screen==this){
            attempt.screen=null;
            if(isFinishing())cancelAttempt(attempt);
        }
        code.setText("");
        super.onDestroy();
    }
}
