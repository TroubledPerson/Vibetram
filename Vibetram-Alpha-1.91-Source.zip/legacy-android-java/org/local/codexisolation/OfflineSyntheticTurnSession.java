// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicBoolean;

/** Fixed offline RPC proof against a pinned fake child, never the live app-server. */
final class OfflineSyntheticTurnSession {
    static final String FAKE_CHILD_SHA256="4de5ed49553d0946560029635b0a274eeccb6501bd24e6fd7ae77cbf885acb16";
    private static final int MAX_FRAME=4096, MAX_STDERR=4096, MAX_FRAMES=9;
    private static final String THREAD="fake-thread-1", TURN="fake-turn-1", ITEM="fake-item-1";
    private static final byte[] INIT=bytes("{\"id\":1,\"method\":\"initialize\",\"params\":{\"clientInfo\":{\"name\":\"offline-synthetic-turn\",\"version\":\"0.1\"}}}\n");
    private static final byte[] INITIALIZED=bytes("{\"method\":\"initialized\"}\n");
    private static final byte[] ACCOUNT=bytes("{\"id\":2,\"method\":\"account/read\",\"params\":{\"refreshToken\":false}}\n");
    private static final byte[] THREAD_START=bytes("{\"id\":3,\"method\":\"thread/start\",\"params\":{\"model\":\"offline-synthetic-only\"}}\n");
    private static final byte[] TURN_START=bytes("{\"id\":4,\"method\":\"turn/start\",\"params\":{\"threadId\":\"fake-thread-1\",\"input\":[{\"type\":\"text\",\"text\":\"offline synthetic ping\"}]}}\n");
    enum Mode { COMPLETE, CANCEL_AFTER_DELTA }
    static final class GateException extends Exception {
        final String code;
        GateException(String code){super(code);this.code=code;}
    }
    static final class Result {
        final Mode mode;final int chunks;
        Result(Mode mode,int chunks){this.mode=mode;this.chunks=chunks;}
    }
    private final OfflineAppServerAdapter.ProcessFactory factory;
    private final String expectedHash;
    private final AtomicBoolean started=new AtomicBoolean(),cancelled=new AtomicBoolean();
    private volatile Process child;
    private volatile String stage="NOT_STARTED";
    private int frames;
    OfflineSyntheticTurnSession(OfflineAppServerAdapter.ProcessFactory factory,String expectedHash){
        this.factory=factory;this.expectedHash=expectedHash;
    }
    String stage(){return stage;}
    void cancel(){
        cancelled.set(true);
        Process p=child;
        if(p!=null)try{p.destroyForcibly();}catch(RuntimeException ignored){}
    }
    Result run(File filesDir,File binary,Mode mode) throws GateException {
        if(!started.compareAndSet(false,true))throw new GateException("ALREADY_RUN");
        File home=null;Process p=null;boolean cleanHome=false;
        ExecutorService readers=Executors.newFixedThreadPool(2);
        try{
            require(!cancelled.get(),"CANCELLED");
            stage="HOME_CHECK";
            File privateDir=filesDir.getCanonicalFile();
            require(privateDir.isDirectory(),"PRIVATE_FILES_MISSING");
            home=new File(privateDir,"synthetic-turn-home-v37").getCanonicalFile();
            require(privateDir.equals(home.getParentFile()),"HOME_OUTSIDE_PRIVATE_FILES");
            Files.createDirectories(home.toPath());
            require(home.list()!=null&&home.list().length==0,"FIXTURE_HOME_NOT_EMPTY");
            cleanHome=true;
            require(binary.isFile()&&binary.canExecute()&&binary.length()<=512*1024,"FAKE_CHILD_UNAVAILABLE");
            byte[] digest=MessageDigest.getInstance("SHA-256").digest(Files.readAllBytes(binary.toPath()));
            require(expectedHash.equalsIgnoreCase(hex(digest)),"FAKE_CHILD_MISMATCH");
            Map<String,String> env=new HashMap<>();
            env.put("PATH","/system/bin");env.put("HOME",home.getPath());env.put("CODEX_HOME",home.getPath());
            env.put("CODEX_CORETEST_FAKE_ONLY","1");
            stage="PROCESS_START";
            p=factory.start(mode==Mode.COMPLETE?Arrays.asList(binary.getAbsolutePath())
                    :Arrays.asList(binary.getAbsolutePath(),"--stall-after-delta"),env);
            child=p;
            require(!cancelled.get(),"CANCELLED");
            final Process running=p;
            Future<Integer> stderr=readers.submit(()->drainStderr(running.getErrorStream()));
            InputStream stdout=p.getInputStream();OutputStream stdin=p.getOutputStream();
            long deadline=System.nanoTime()+TimeUnit.SECONDS.toNanos(20);
            stage="INITIALIZE";
            send(stdin,INIT);Map<?,?> init=reply(stdout,readers,deadline,1);
            require("android".equals(obj(init.get("result"),"INIT_INVALID").get("platformOs")),"INIT_INVALID");
            require("offline-only".equals(obj(init.get("result"),"INIT_INVALID").get("fixture")),"INIT_INVALID");
            send(stdin,INITIALIZED);
            stage="FAKE_ACCOUNT";
            send(stdin,ACCOUNT);Map<?,?> account=obj(reply(stdout,readers,deadline,2).get("result"),"FAKE_ACCOUNT_INVALID");
            require(Boolean.TRUE.equals(obj(account.get("account"),"FAKE_ACCOUNT_INVALID").get("synthetic")),"FAKE_ACCOUNT_INVALID");
            stage="THREAD_START";
            send(stdin,THREAD_START);Map<?,?> thread=obj(reply(stdout,readers,deadline,3).get("result"),"THREAD_INVALID");
            require(THREAD.equals(obj(thread.get("thread"),"THREAD_INVALID").get("id")),"THREAD_INVALID");
            stage="TURN_START";
            send(stdin,TURN_START);Map<?,?> turn=obj(reply(stdout,readers,deadline,4).get("result"),"TURN_INVALID");
            Map<?,?> begun=obj(turn.get("turn"),"TURN_INVALID");
            require(TURN.equals(begun.get("id"))&&"inProgress".equals(begun.get("status")),"TURN_INVALID");
            stage="STREAM";
            Map<?,?> startedEvent=frame(stdout,readers,deadline);
            require("turn/started".equals(startedEvent.get("method")),"STREAM_ORDER_INVALID");
            Map<?,?> startedParams=obj(startedEvent.get("params"),"STREAM_INVALID");
            require(THREAD.equals(startedParams.get("threadId")),"STREAM_INVALID");
            Map<?,?> startedTurn=obj(startedParams.get("turn"),"STREAM_INVALID");
            require(TURN.equals(startedTurn.get("id"))&&"inProgress".equals(startedTurn.get("status")),"STREAM_INVALID");
            int chunks=0;StringBuilder fakeText=new StringBuilder();
            while(true){
                Map<?,?> event=frame(stdout,readers,deadline);
                Map<?,?> params=obj(event.get("params"),"STREAM_INVALID");
                require(!event.containsKey("id")&&THREAD.equals(params.get("threadId")),"STREAM_INVALID");
                if("item/agentMessage/delta".equals(event.get("method"))){
                    require(TURN.equals(params.get("turnId"))&&ITEM.equals(params.get("itemId")),"STREAM_INVALID");
                    require(params.get("delta") instanceof String&&++chunks<=2,"DELTA_INVALID");
                    String delta=(String)params.get("delta");
                    require(delta.length()<=32,"DELTA_OVERSIZE");fakeText.append(delta);
                    if(mode==Mode.CANCEL_AFTER_DELTA){cancel();throw new GateException("CANCELLED");}
                }else if("turn/completed".equals(event.get("method"))){
                    Map<?,?> finalTurn=obj(params.get("turn"),"COMPLETION_INVALID");
                    require(TURN.equals(finalTurn.get("id"))&&"completed".equals(finalTurn.get("status")),"COMPLETION_INVALID");
                    break;
                }else throw new GateException("UNEXPECTED_NOTIFICATION");
            }
            require(chunks==2&&"Synthetic reply.".contentEquals(fakeText),"STREAM_CONTENT_INVALID");
            stage="COMPLETE";
            stdin.close();
            require(p.waitFor(2,TimeUnit.SECONDS)&&p.exitValue()==0,"CHILD_EXIT_INVALID");
            require(stdout.read()==-1,"EXTRA_CHILD_OUTPUT");
            require(stderr.get(2,TimeUnit.SECONDS)==0,"CHILD_STDERR_PRESENT");
            return new Result(mode,chunks);
        }catch(GateException e){throw e;}
        catch(TimeoutException e){throw new GateException(cancelled.get()?"CANCELLED":"SESSION_TIMEOUT");}
        catch(Exception e){throw new GateException(cancelled.get()?"CANCELLED":"SESSION_STOPPED");}
        finally{
            if(p!=null){
                if(p.isAlive())p.destroyForcibly();
                try{if(!p.waitFor(2,TimeUnit.SECONDS)||p.isAlive())throw new GateException("CHILD_STILL_RUNNING");}
                catch(InterruptedException e){Thread.currentThread().interrupt();throw new GateException("CHILD_STILL_RUNNING");}
            }
            child=null;readers.shutdownNow();
            if(cleanHome&&home.isDirectory()&&(home.list()==null||home.list().length!=0))
                throw new GateException("FIXTURE_HOME_CHANGED");
        }
    }
    private Map<?,?> reply(InputStream in,ExecutorService readers,long deadline,int id) throws Exception{
        Map<?,?> value=frame(in,readers,deadline);
        require(BigDecimal.valueOf(id).equals(value.get("id"))&&!value.containsKey("error"),"RPC_REJECTED");
        return value;
    }
    private Map<?,?> frame(InputStream in,ExecutorService readers,long deadline) throws Exception{
        require(!cancelled.get(),"CANCELLED");require(++frames<=MAX_FRAMES,"TOO_MANY_FRAMES");
        long remaining=deadline-System.nanoTime();require(remaining>0,"SESSION_TIMEOUT");
        byte[] line=readers.submit(()->readLine(in)).get(Math.max(1,remaining),TimeUnit.NANOSECONDS);
        return obj(BoundedJson.parse(line),"FRAME_INVALID");
    }
    private static byte[] readLine(InputStream in) throws IOException{
        ByteArrayOutputStream out=new ByteArrayOutputStream();
        while(true){int value=in.read();if(value<0)throw new IOException("EOF");
            if(value=='\n')return out.toByteArray();
            if(out.size()>=MAX_FRAME)throw new IOException("FRAME_OVERSIZE");out.write(value);}
    }
    private static int drainStderr(InputStream in) throws IOException{
        int count=0,n;byte[] b=new byte[256];
        while((n=in.read(b))!=-1){count+=n;if(count>MAX_STDERR)throw new IOException("STDERR_OVERSIZE");}
        return count;
    }
    private static void send(OutputStream out,byte[] value) throws IOException{out.write(value);out.flush();}
    private static Map<?,?> obj(Object value,String code) throws GateException{
        if(!(value instanceof Map))throw new GateException(code);return (Map<?,?>)value;
    }
    private static void require(boolean condition,String code) throws GateException{if(!condition)throw new GateException(code);}
    private static byte[] bytes(String value){return value.getBytes(StandardCharsets.UTF_8);}
    private static String hex(byte[] bytes){StringBuilder out=new StringBuilder();for(byte b:bytes)out.append(String.format("%02x",b&255));return out.toString();}
}
