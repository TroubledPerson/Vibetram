// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.hardware.display.*;
import android.media.*;
import android.media.projection.*;
import android.os.*;
import android.view.Surface;
import java.lang.ref.WeakReference;

/** One in-memory, non-restarting, foreground-only projection attempt. No grant in service Intent. */
public final class OneShotProjectionService extends Service {
 private static final Handler MAIN=new Handler(Looper.getMainLooper());
 private static Job active;private static long serial;
 static boolean launch(OneShotCaptureActivity a,OneShotSession s,OneShotSession.Lease lease){
  if(!a.allowsCaptureNow()||!s.live(lease))return false;
  final Job job;
  synchronized(OneShotProjectionService.class){if(active!=null)return false;job=new Job(a,s,lease,++serial);active=job;}
  if(!s.bind(lease,job))return false;
  try{a.startForegroundService(new Intent(a,OneShotProjectionService.class).putExtra("attempt",job.id));return true;}
  catch(RuntimeException error){s.close("FOREGROUND_SERVICE_START_REJECTED");return false;}
 }
 @Override public IBinder onBind(Intent intent){return null;}
 @Override public int onStartCommand(Intent intent,int flags,int startId){
  Job job;synchronized(OneShotProjectionService.class){job=active;}
  if(job==null){stopSelf(startId);return START_NOT_STICKY;}
  if(intent==null||intent.getLongExtra("attempt",-1)!=job.id)return START_NOT_STICKY;
  if("STOP_ONE_SHOT".equals(intent.getAction())){job.session.close("NOTIFICATION_STOPPED");return START_NOT_STICKY;}
  if(job.service!=null)return START_NOT_STICKY;
  OneShotCaptureActivity a=job.activity.get();
  if(a==null||!a.allowsCaptureNow()||!job.session.live(job.lease)){job.session.close("FOREGROUND_RETURN_REQUIRED");stopSelf(startId);return START_NOT_STICKY;}
  job.service=this;job.startId=startId;
  try{
   NotificationManager manager=getSystemService(NotificationManager.class);
   manager.createNotificationChannel(new NotificationChannel("one_local_frame","One local screenshot",NotificationManager.IMPORTANCE_LOW));
   Intent stop=new Intent(this,OneShotProjectionService.class).setAction("STOP_ONE_SHOT").putExtra("attempt",job.id);
   PendingIntent action=PendingIntent.getService(this,(int)job.id,stop,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
   Notification n=new Notification.Builder(this,"one_local_frame").setSmallIcon(android.R.drawable.ic_menu_camera)
     .setContentTitle("One local screenshot").setContentText("No saving or upload. Stop to cancel.").setOngoing(true)
     .addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel,"Stop",action).build()).build();
   startForeground(179,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
   job.worker.post(job::prepare);
  }catch(RuntimeException error){job.session.close("FOREGROUND_NOTIFICATION_REJECTED");}
  return START_NOT_STICKY;
 }
 @Override public void onDestroy(){
  Job job;synchronized(OneShotProjectionService.class){job=active;}
  if(job!=null&&job.service==this)job.teardown.serviceDestroyed(()->job.session.close("SERVICE_DESTROYED"));super.onDestroy();
 }
 private static final class Job implements OneShotSession.Resource {
  final WeakReference<OneShotCaptureActivity> activity;final OneShotSession session;final OneShotSession.Lease lease;final long id;
  final HandlerThread thread;final Handler worker;final int initialW,initialH,dpi;
  volatile OneShotProjectionService service;int startId;boolean closed,visible,sizeKnown,frameClaimed,cleanupFault;int rawW,rawH,width,height;
  MediaProjection projection;VirtualDisplay display;ImageReader reader;Surface surface;
  final OneShotCleanup cleanupSteps=new OneShotCleanup();
  final OneShotTeardown teardown=new OneShotTeardown();
  final MediaProjection.Callback callback=new MediaProjection.Callback(){
   @Override public void onStop(){if(!closed)fail("ANDROID_PROJECTION_STOPPED");}
   @Override public void onCapturedContentVisibilityChanged(boolean value){
    if(closed)return;if(!value){fail("CAPTURED_CONTENT_NOT_VISIBLE");return;}visible=true;
   }
   @Override public void onCapturedContentResize(int w,int h){
    if(closed)return;
    if(w!=initialW||h!=initialH||w<1||h<1||w>16384||h>16384||(sizeKnown&&(rawW!=w||rawH!=h))){fail("UNEXPECTED_SOURCE_SIZE_OR_RESIZE_REVOKED");return;}
    rawW=w;rawH=h;sizeKnown=true;
    try{resizeReader(w,h);}catch(RuntimeException error){fail("CAPTURE_SURFACE_REJECTED");}
   }
  };
  Job(OneShotCaptureActivity a,OneShotSession s,OneShotSession.Lease lease,long id){
   activity=new WeakReference<>(a);session=s;this.lease=lease;this.id=id;
   android.graphics.Rect bounds=a.getWindowManager().getMaximumWindowMetrics().getBounds();initialW=bounds.width();initialH=bounds.height();dpi=a.getResources().getDisplayMetrics().densityDpi;
   thread=new HandlerThread("one-local-frame");thread.start();worker=new Handler(thread.getLooper());
   worker.postDelayed(()->{if(!closed)fail("ACQUISITION_TIMEOUT");},Math.max(1,s.remaining()));
  }
  @Override public void requestStop(){worker.post(()->cleanup(false));}
  void prepare(){
   if(closed||!session.live(lease)){cleanup(false);return;}
   try{
    Object grant=session.takeGrant(lease);if(!(grant instanceof Intent)||!session.live(lease)){fail("FRESH_CONSENT_REQUIRED");return;}
    projection=service.getSystemService(MediaProjectionManager.class).getMediaProjection(Activity.RESULT_OK,(Intent)grant);
    grant=null;if(projection==null||!session.live(lease)){fail("PROJECTION_GRANT_REJECTED");return;}
    projection.registerCallback(callback,worker);resizeReader(initialW,initialH);
    if(!session.live(lease)){cleanup(false);return;}
    display=projection.createVirtualDisplay("one-local-frame",width,height,dpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,surface,null,worker);
   }catch(RuntimeException error){fail("PROJECTION_START_REJECTED");}
  }
  void resizeReader(int w,int h){
   if(w<1||h<1||w>16384||h>16384)throw new IllegalArgumentException();
   int edge=Math.max(w,h),nw=Math.max(1,(int)((long)w*640/edge)),nh=Math.max(1,(int)((long)h*640/edge));
   if(reader!=null&&nw==width&&nh==height)return;
   ImageReader replacement=ImageReader.newInstance(nw,nh,PixelFormat.RGBA_8888,2);Surface next=replacement.getSurface();boolean installed=false;
   try{
    replacement.setOnImageAvailableListener(this::image,worker);
    if(display!=null){display.resize(nw,nh,dpi);display.setSurface(next);}
    ImageReader old=reader;Surface oldSurface=surface;reader=replacement;surface=next;width=nw;height=nh;installed=true;
    try{if(old!=null)old.close();}catch(RuntimeException e){cleanupFault=true;}
    try{if(oldSurface!=null)oldSurface.release();}catch(RuntimeException e){cleanupFault=true;}
    if(cleanupFault)throw new IllegalStateException();
   }finally{if(!installed){try{replacement.close();}catch(RuntimeException e){cleanupFault=true;}try{next.release();}catch(RuntimeException e){cleanupFault=true;}}}
  }
  void image(ImageReader source){
   if(closed||source!=reader)return;
   CapturedPng.PendingFrame pending=null;
   try(Image image=source.acquireLatestImage()){
    if(image==null)return;
    if(!session.live(lease)){worker.post(()->cleanup(false));return;}
    if(!visible||!sizeKnown||frameClaimed)return;
    frameClaimed=true;
    android.graphics.Rect crop=image.getCropRect();
    Image.Plane[] planes=image.getPlanes();if(planes.length!=1||image.getFormat()!=PixelFormat.RGBA_8888||image.getWidth()!=width||image.getHeight()!=height
      ||crop==null||crop.left!=0||crop.top!=0||crop.right!=width||crop.bottom!=height)throw new IllegalArgumentException();
    pending=CapturedPng.copyPlane(planes[0].getBuffer(),width,height,planes[0].getRowStride(),planes[0].getPixelStride());
   }catch(RuntimeException error){fail("FRAME_BOUNDS_FORMAT_OR_PNG_REJECTED");return;}
   if(pending==null)return;
   if(!session.stopping(lease)){cleanup(false);return;}
   if(!cleanup(true))return;
   final SameFramePng.Result image;
   try{image=pending.encodeBounded(()->session.live(lease));}catch(RuntimeException error){
    session.close(OneShotPngFailure.category(error));
    if(error instanceof SameFramePng.Exhausted){SameFramePng.Exhausted detail=(SameFramePng.Exhausted)error;
     MAIN.post(()->{OneShotCaptureActivity a=activity.get();if(a!=null)a.reportExhausted(session,detail);});}
    return;
   }
   MAIN.post(()->{OneShotCaptureActivity a=activity.get();if(a==null){session.close("OWNER_GONE");return;}a.deliver(session,lease,image);});
  }
  void fail(String code){session.close(code);cleanup(false);}
  boolean cleanup(boolean expectedFrame){
   if(closed)return false;closed=true;
   boolean clean=cleanupSteps.run(
    ()->{if(display!=null)display.release();},()->{if(reader!=null)reader.close();},()->{if(surface!=null)surface.release();},
    ()->{if(projection!=null)projection.unregisterCallback(callback);},()->{if(projection!=null)projection.stop();},
    ()->{if(service!=null)service.stopForeground(STOP_FOREGROUND_REMOVE);},()->{if(service!=null)teardown.plannedStop(()->service.stopSelf(startId));}
   )&&!cleanupFault;
   display=null;reader=null;surface=null;projection=null;
   session.resourcesStopped(lease,this,clean);
   synchronized(OneShotProjectionService.class){if(active==this)active=null;}
   if(!expectedFrame&&session.state()!=OneShotSession.State.CLOSED)session.close("ACQUISITION_CANCELLED");
   MAIN.post(()->{OneShotCaptureActivity a=activity.get();if(a!=null)a.refreshFromAdapter(session);});
   thread.quitSafely();return clean;
  }
 }
}
