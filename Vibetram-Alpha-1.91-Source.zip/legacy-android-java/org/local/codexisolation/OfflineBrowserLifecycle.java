// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

import java.security.SecureRandom;

/** Android Activity/loopback lifecycle model; this offline fixture never launches either. */
final class OfflineBrowserLifecycle {
    private enum Phase { NEW, WAITING, CLOSED }
    private Phase phase=Phase.NEW;
    private OfflineAuthBoundary.Attempt attempt;
    synchronized OfflineAuthBoundary.Attempt prepare(int port, OfflineAuthBoundary.Clock clock, SecureRandom random) {
        if(phase!=Phase.NEW)throw new SecurityException("Browser fixture already used");
        attempt=OfflineAuthBoundary.begin(port,clock,random);
        return attempt;
    }
    synchronized void browserOpened() {
        if(phase!=Phase.NEW || attempt==null)throw new SecurityException("Browser fixture order");
        phase=Phase.WAITING;
    }
    synchronized String callback(String uri,OfflineAuthBoundary.Clock clock) {
        if(phase!=Phase.WAITING)throw new SecurityException("No pending browser callback");
        phase=Phase.CLOSED;
        return attempt.accept(uri,clock);
    }
    synchronized void activityDestroyed() { close(); }
    synchronized void loopbackClosed() { close(); }
    private void close() { phase=Phase.CLOSED; if(attempt!=null)attempt.cancel(); }
    synchronized boolean closed() { return phase==Phase.CLOSED; }
}
