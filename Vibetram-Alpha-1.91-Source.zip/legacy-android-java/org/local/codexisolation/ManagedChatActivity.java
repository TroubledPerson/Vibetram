// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.view.WindowInsets;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.File;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/** One process-memory conversation. Sign-in and every model turn require separate taps. */
public final class ManagedChatActivity extends Activity {
    private static final Handler MAIN=new Handler(Looper.getMainLooper());
    private static Attempt active;
    private static SafFolder selectedFolder;
    private static String pendingDraft="";
    private static final int PICK_FOLDER=1601;
    private static final class Attempt {
        final ManagedChatSession session;
        final ScreenStatusGate screenStatusGate=new ScreenStatusGate();
        final StringBuilder transcript=new StringBuilder();
        volatile ManagedChatActivity screen;
        String code="",draft="",inFlightPrompt="",status="Starting sign-in…",errorCode="";
        boolean ready,inFlight,stopping,settled,loginFailed,userEnded;
        int submitted;
        volatile boolean browserOpened,foreground;
        ManagedChatSession.ToolGate pendingTool;
        String pendingTitle="",pendingReview="";
        boolean pendingPanelAction,regeneratedPendingPanelAction;
        boolean localGuardProbeRun;
        String localGuardProbeText="";
        boolean manualCheckPending;
        boolean pickAfterEnd;
        Attempt(PhoneWorkspace workspace,SafFolder folder){
            session=new ManagedChatSession(OfflineAppServerAdapter.SYSTEM,workspace,folder,screenStatusGate,
                    token->{
                        ManagedChatActivity current=screen;
                        if(current==null)throw new IllegalStateException("OWN_PANEL_UI_UNAVAILABLE");
                        return current.captureOwnPanel(this,token);
                    },(revision,row,column,token)->{
                        ManagedChatActivity current=screen;
                        if(current==null)throw new IllegalStateException("OWN_PANEL_UI_UNAVAILABLE");
                        return current.selectOwnPanelCell(this,revision,row,column,token);
                    });
        }
        void render(){if(screen!=null)screen.render(this);}
    }
    private Button signIn,open,send,stop,end,showReadme,showData,checkProject,approve,reject;
    private Button pickFolder,disconnectFolder,listFolder,showFolderFile,remoteStart,remoteStop;
    private Button screenStatusStart,screenStatusStop,regeneratePanel,missingImageProbe;
    private TextView code,status,transcript,projectPreview,approvalReview,folderScope,folderPreview,remoteStatus;
    private TextView screenStatusLabel,missingImageProbeResult;
    private EditText input,folderName,remoteOrigin,remoteCode;
    private ScrollView scroll;
    private OwnMarkerPanelView ownPanel;
    private PhoneWorkspace workspace;
    private volatile boolean remoteWanted;
    private RemotePhonePoller remotePoller;
    private RemotePhoneEnrollment.Pairing remotePairing;
    private boolean destroyed,restoredWithoutProcess;
    @Override public void onCreate(Bundle saved){
        super.onCreate(saved);
        try{workspace=new PhoneWorkspace(getFilesDir());}catch(Exception ignored){workspace=null;}
        restoredWithoutProcess=active==null&&saved!=null&&saved.getBoolean("attempted");
        scroll=new ScrollView(this);scroll.setFillViewport(true);
        LinearLayout shell=new LinearLayout(this);shell.setOrientation(LinearLayout.VERTICAL);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        shell.setOnApplyWindowInsetsListener((v,insets)->{
            if(Build.VERSION.SDK_INT>=30){
                android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout());
                v.setPadding(bars.left,bars.top,bars.right,bars.bottom);
            }else v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),
                    insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());
            return insets;
        });
        TextView intro=new TextView(this);
        intro.setText("1.72.6 local missing-image guard source test: an idle-only button checks the same image-evidence guard used by panel_select_cell without a model turn. The pending-action marker regeneration test remains available. No Android touch is injected. Built-in two-file toy project plus optional folder chosen in Android's system picker. "
                +"Only immediate .txt, .md, and .json files up to 4 KB can be read by folder tools. "
                +"Selected file contents may go to the model when you tap Send. Review every proposed write; providers may sync or lack atomic writes. "
                +"Choose a folder before sign-in. If signed in already, End session then choose; a new sign-in is needed for folder tools. "
                +"The separate remote bridge needs an approved HTTPS service and a one-time pairing code. Each remote list/read needs Allow once on this phone; its result travels through that service to ChatGPT. Leaving this screen stops the bridge. "
                +"No shell, all-files permission, retained folder grant, or automatic model retry. Each Send may use quota.");
        signIn=new Button(this);signIn.setText("START SIGN-IN");
        open=new Button(this);open.setText("OPEN VERIFICATION PAGE");
        code=new TextView(this);code.setTextSize(22);code.setTextIsSelectable(false);
        status=new TextView(this);status.setTextIsSelectable(true);
        input=new EditText(this);input.setHint("Your next message (1–256 characters)");
        input.setSingleLine(true);input.setSaveEnabled(false);
        input.setFocusableInTouchMode(true);input.setShowSoftInputOnFocus(true);
        input.setFilters(new InputFilter[]{new InputFilter.LengthFilter(ShortPromptBoundary.MAX_UTF16_UNITS)});
        input.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            public void onTextChanged(CharSequence s,int start,int before,int count){}
            public void afterTextChanged(Editable s){
                if(destroyed)return;
                Attempt attempt=active;
                if(attempt==null)pendingDraft=s.toString();
                else if(attempt.screen==ManagedChatActivity.this&&!attempt.inFlight)attempt.draft=s.toString();
            }
        });
        send=new Button(this);send.setText("SEND MESSAGE");
        stop=new Button(this);stop.setText("STOP CURRENT TURN");
        end=new Button(this);end.setText("END SESSION");
        transcript=new TextView(this);transcript.setTextIsSelectable(true);
        showReadme=new Button(this);showReadme.setText("VIEW README.md");
        showData=new Button(this);showData.setText("VIEW project.json");
        checkProject=new Button(this);checkProject.setText("REQUEST PROJECT CHECK");
        projectPreview=new TextView(this);projectPreview.setTextIsSelectable(true);
        pickFolder=new Button(this);pickFolder.setText("CHOOSE FOLDER (SYSTEM PICKER)");
        disconnectFolder=new Button(this);disconnectFolder.setText("DISCONNECT FOLDER");
        folderScope=new TextView(this);folderScope.setTextIsSelectable(true);
        listFolder=new Button(this);listFolder.setText("LIST SELECTED FOLDER");
        folderName=new EditText(this);folderName.setHint("Immediate text file name, e.g. notes.md");
        folderName.setSingleLine(true);folderName.setSaveEnabled(false);
        folderName.setFilters(new InputFilter[]{new InputFilter.LengthFilter(FolderPolicy.MAX_NAME)});
        showFolderFile=new Button(this);showFolderFile.setText("VIEW SELECTED FILE");
        folderPreview=new TextView(this);folderPreview.setTextIsSelectable(true);
        remoteOrigin=new EditText(this);remoteOrigin.setHint("Approved Longhorn HTTPS origin");
        remoteOrigin.setSingleLine(true);remoteOrigin.setSaveEnabled(false);
        remoteOrigin.setFilters(new InputFilter[]{new InputFilter.LengthFilter(256)});
        remoteCode=new EditText(this);remoteCode.setHint("One-time 32-character pairing code");
        remoteCode.setSingleLine(true);remoteCode.setSaveEnabled(false);
        remoteCode.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        remoteCode.setFilters(new InputFilter[]{new InputFilter.LengthFilter(32)});
        remoteStart=new Button(this);remoteStart.setText("PAIR & START REMOTE BRIDGE");
        remoteStop=new Button(this);remoteStop.setText("STOP REMOTE BRIDGE");
        remoteStatus=new TextView(this);remoteStatus.setText("Remote bridge off. Approved HTTPS service and pairing code required.");
        screenStatusStart=new Button(this);screenStatusStart.setText("ENABLE LOCAL SCREEN STATUS");
        screenStatusStop=new Button(this);screenStatusStop.setText("STOP LOCAL SCREEN STATUS");
        missingImageProbe=new Button(this);missingImageProbe.setText("TEST MISSING PANEL IMAGE (LOCAL)");
        missingImageProbeResult=new TextView(this);missingImageProbeResult.setTextIsSelectable(true);
        regeneratePanel=new Button(this);regeneratePanel.setText("REGENERATE TEST MARKER (STALE-ACTION TEST)");
        screenStatusLabel=new TextView(this);
        approvalReview=new TextView(this);approvalReview.setTextIsSelectable(true);
        approve=new Button(this);approve.setText("APPROVE ONCE");
        reject=new Button(this);reject.setText("REJECT");
        root.addView(intro);root.addView(signIn);root.addView(open);root.addView(code);root.addView(status);
        root.addView(showReadme);root.addView(showData);root.addView(checkProject);root.addView(projectPreview);
        root.addView(pickFolder);root.addView(disconnectFolder);root.addView(folderScope);
        root.addView(listFolder);root.addView(folderName);root.addView(showFolderFile);root.addView(folderPreview);
        root.addView(remoteOrigin);root.addView(remoteCode);root.addView(remoteStart);root.addView(remoteStop);root.addView(remoteStatus);
        root.addView(screenStatusStart);root.addView(screenStatusStop);root.addView(screenStatusLabel);
        root.addView(missingImageProbe);root.addView(missingImageProbeResult);
        root.addView(input);root.addView(send);root.addView(stop);root.addView(end);
        root.addView(approvalReview);root.addView(regeneratePanel);root.addView(approve);root.addView(reject);root.addView(transcript);
        scroll.addView(root);
        ownPanel=new OwnMarkerPanelView(this);
        LinearLayout.LayoutParams panelSize=new LinearLayout.LayoutParams(OwnMarkerPanelView.SIDE_PX,OwnMarkerPanelView.SIDE_PX);
        panelSize.gravity=android.view.Gravity.CENTER_HORIZONTAL;
        shell.addView(ownPanel,panelSize);
        shell.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(shell);shell.requestApplyInsets();
        if(active!=null){active.screen=this;active.render();}else render(null);
        signIn.setOnClickListener(v->{
            Attempt old=active;if(old!=null&&!old.settled)return;
            if(Build.VERSION.SDK_INT<29||!"arm64-v8a".equals(Build.SUPPORTED_ABIS[0])){
                status.setText("Unsupported device: Android 10+ arm64 required.");return;
            }
            if(workspace==null){status.setText("Project workspace unavailable.");return;}
            Attempt attempt=new Attempt(workspace,selectedFolder);attempt.draft=input.getText().toString();
            active=attempt;pendingDraft="";restoredWithoutProcess=false;
            attempt.screen=this;attempt.foreground=true;attempt.render();
            attempt.screenStatusGate.setForeground(true);
            attempt.screenStatusGate.setFocused(hasWindowFocus());
            attempt.render();
            File binary=new File(getApplicationInfo().nativeLibraryDir,"libcodex_app_server.so");
            File filesDir=getFilesDir();
            new Thread(()->runAttempt(attempt,filesDir,binary),"managed-chat-parent").start();
        });
        open.setOnClickListener(v->{
            Attempt attempt=active;if(attempt==null||attempt.code.isEmpty()||attempt.settled)return;
            attempt.browserOpened=true;
            startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(ManagedChatSession.VERIFY_URL)));
        });
        send.setOnClickListener(v->{
            Attempt attempt=active;
            if(attempt==null||!ChatScreenRules.send(attempt.ready,attempt.inFlight,attempt.settled,attempt.submitted))return;
            String text=input.getText().toString();String issue=ShortPromptBoundary.check(text);
            if(issue!=null){attempt.status="Message not sent: "+issue+". Edit the draft and tap Send.";
                attempt.render();return;}
            if(attempt.session.requestSend(text)){
                attempt.inFlight=true;attempt.stopping=false;attempt.ready=false;
                attempt.inFlightPrompt=text;attempt.draft="";input.setText("");
                attempt.status="Sending one message. Stop will interrupt this turn.";attempt.render();
            }
        });
        stop.setOnClickListener(v->{
            Attempt attempt=active;
            if(attempt==null||!ChatScreenRules.stop(attempt.inFlight,attempt.stopping,attempt.settled))return;
            if(attempt.session.requestStop()){
                ownPanel.clear();
                attempt.stopping=true;attempt.status="Stopping current turn…";attempt.render();
            }
        });
        end.setOnClickListener(v->{
            Attempt attempt=active;if(attempt==null||attempt.settled)return;
            attempt.userEnded=true;attempt.code="";
            if(attempt.inFlight)attempt.draft=attempt.inFlightPrompt;
            attempt.manualCheckPending=false;attempt.pendingTitle="";attempt.pendingReview="";
            attempt.status="Ending this session. No message will be sent automatically.";
            attempt.session.cancel();attempt.render();
        });
        showReadme.setOnClickListener(v->showFile(PhoneWorkspace.README));
        showData.setOnClickListener(v->showFile(PhoneWorkspace.DATA));
        pickFolder.setOnClickListener(v->{
            Attempt attempt=active;
            boolean pending=attempt!=null&&((attempt.pendingTool!=null&&attempt.pendingTool.isOpen())||attempt.manualCheckPending);
            FolderPickerFlow.Action action=FolderPickerFlow.action(attempt!=null,attempt!=null&&attempt.settled,
                    attempt!=null&&attempt.inFlight,pending,attempt!=null&&attempt.userEnded);
            switch(action){
                case OPEN_NOW: launchFolderPicker();break;
                case WAIT_FOR_TURN:
                    attempt.status="Finish or Stop the current turn before choosing a folder.";attempt.render();break;
                case WAIT_FOR_APPROVAL:
                    attempt.status="Approve or Reject the pending request before choosing a folder.";attempt.render();break;
                case QUEUE_AFTER_END:
                    attempt.pickAfterEnd=true;
                    attempt.status="Waiting for the session to end, then opening the folder picker.";attempt.render();break;
                case CONFIRM_END:
                    new AlertDialog.Builder(this).setTitle("Choose a folder for a new session?")
                            .setMessage("This ends the current sign-in and conversation. After you choose a folder, tap New Sign-in. Nothing is sent automatically.")
                            .setNegativeButton("Keep session",(dialog,which)->{})
                            .setPositiveButton("End session & choose",(dialog,which)->{
                                if(active!=attempt||attempt.settled||attempt.inFlight||attempt.pendingTool!=null)return;
                                attempt.pickAfterEnd=true;attempt.userEnded=true;attempt.code="";
                                attempt.manualCheckPending=false;attempt.pendingTitle="";attempt.pendingReview="";
                                attempt.status="Ending session before the folder picker opens.";
                                attempt.session.cancel();attempt.render();
                            }).show();break;
            }
        });
        disconnectFolder.setOnClickListener(v->{
            Attempt attempt=active;if(attempt!=null&&attempt.inFlight)return;
            stopRemoteBridge();
            SafFolder old=selectedFolder;if(old!=null)old.revoke();selectedFolder=null;
            folderPreview.setText("Folder disconnected. Active turns cannot use it. Select again before a new sign-in.");
            render(active);
        });
        listFolder.setOnClickListener(v->withFolder(folder->folder.list()));
        showFolderFile.setOnClickListener(v->{
            String name=folderName.getText().toString();
            withFolder(folder->{PhoneWorkspace.Snapshot snapshot=folder.read(name);
                return name+"  sha256="+snapshot.sha256+"\n"+snapshot.text;});
        });
        remoteStart.setOnClickListener(v->{
            if(remoteWanted||remotePoller!=null){remoteStatus.setText("Remote bridge already active or pairing.");return;}
            SafFolder folder=selectedFolder;
            if(folder==null){remoteStatus.setText("Choose a folder in Android's system picker first.");return;}
            String origin=remoteOrigin.getText().toString().trim();
            String pairingCode=remoteCode.getText().toString().trim();remoteCode.setText("");
            remoteWanted=true;remoteStatus.setText("Pairing with approved HTTPS service...");
            new Thread(()->{
                try{
                    RemotePhoneEnrollment.Pairing pair=RemotePhoneEnrollment.enroll(origin,pairingCode);
                    MAIN.post(()->{
                        if(destroyed||!remoteWanted||selectedFolder!=folder){revokeUnusedPair(pair);return;}
                        try{
                            RemotePhonePoller poller=new RemotePhonePoller(this,pair.origin,pair.ownerId,
                                    pair.deviceId,pair.token,folder,this::remoteBridgeEnded);
                            remotePairing=pair;remotePoller=poller;poller.start();
                            remoteStatus.setText("Remote bridge active for owner "+pair.ownerId
                                    +" while this screen stays open. Allow each list/read once or deny it.");
                        }catch(Exception ignored){revokeUnusedPair(pair);remoteWanted=false;
                            remoteStatus.setText("Remote bridge could not start. Pairing revoked if reachable.");}
                    });
                }catch(Exception ignored){MAIN.post(()->{if(remoteWanted&&!destroyed){remoteWanted=false;
                    remoteStatus.setText("Pairing failed. Check the HTTPS origin and unused code.");}});}
            },"remote-folder-enroll").start();
        });
        remoteStop.setOnClickListener(v->stopRemoteBridge());
        screenStatusStart.setOnClickListener(v->{
            Attempt attempt=active;
            if(attempt==null||attempt.settled||attempt.userEnded||attempt.screen!=this)return;
            attempt.screenStatusGate.setForeground(attempt.foreground);
            attempt.screenStatusGate.setFocused(hasWindowFocus());
            if(attempt.screenStatusGate.enable()){
                try{ownPanel.showFresh();attempt.status="Local marker panel visible; no image shared until a separate approved tool call.";}
                catch(RuntimeException error){attempt.session.revokeScreenStatus();ownPanel.clear();attempt.status="Local marker panel unavailable.";}
            }else attempt.status="Local screen status requires this visible, focused session.";
            attempt.render();
        });
        screenStatusStop.setOnClickListener(v->{
            Attempt attempt=active;if(attempt==null||attempt.screen!=this)return;
            attempt.session.revokeScreenStatus();
            ownPanel.clear();
            attempt.status="Local screen status stopped.";attempt.render();
        });
        missingImageProbe.setOnClickListener(v->{
            Attempt attempt=active;
            if(attempt==null||attempt.screen!=this||attempt.settled||attempt.userEnded
                    ||attempt.localGuardProbeRun||!attempt.ready||attempt.inFlight||attempt.stopping
                    ||attempt.pendingTool!=null||attempt.manualCheckPending||!attempt.foreground
                    ||!hasWindowFocus()||!attempt.screenStatusGate.active())return;
            long[] before=ownPanel.diagnosticState();
            ManagedChatSession.MissingImageProbe result=attempt.session.probeMissingPanelImage();
            long[] after=ownPanel.diagnosticState();
            boolean unchanged=before[0]==after[0]&&before[1]==after[1];
            attempt.localGuardProbeRun=!"LOCAL_PROBE_UNAVAILABLE".equals(result.guardResult);
            attempt.localGuardProbeText="Local guard result: "+result.guardResult
                    +"; approval requests="+result.approvalRequests
                    +"; panel action attempts="+result.actionAttempts
                    +"; panel unchanged="+unchanged+". No model request sent.";
            attempt.render();
        });
        regeneratePanel.setOnClickListener(v->{
            Attempt attempt=active;
            if(attempt==null||attempt.screen!=this||attempt.settled||attempt.userEnded||!attempt.inFlight
                    ||!attempt.pendingPanelAction||attempt.regeneratedPendingPanelAction
                    ||attempt.pendingTool==null||!attempt.pendingTool.isOpen()
                    ||!attempt.foreground||!hasWindowFocus())return;
            synchronized(attempt.screenStatusGate){
                if(!attempt.screenStatusGate.active()||!attempt.pendingTool.isOpen())return;
                try{
                    ownPanel.regenerateForStaleTest();
                    attempt.regeneratedPendingPanelAction=true;
                    attempt.status="Test marker regenerated. The pending action still targets the earlier image; approving it should report PANEL_REVISION_STALE.";
                }catch(RuntimeException error){attempt.status="Test marker regeneration failed; reject the pending action.";}
            }
            attempt.render();
        });
        checkProject.setOnClickListener(v->{
            Attempt attempt=active;if(attempt==null||attempt.inFlight||attempt.settled||attempt.pendingTool!=null)return;
            attempt.manualCheckPending=true;attempt.pendingTitle="Run fixed project.json check?";
            attempt.pendingReview="Reads project.json and validates name and tasks. No shell or network.";
            attempt.render();
        });
        approve.setOnClickListener(v->resolveApproval(true));
        reject.setOnClickListener(v->resolveApproval(false));
    }
    private void launchFolderPicker(){
        if(destroyed)return;
        stopRemoteBridge();
        Intent picker=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        picker.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        try{startActivityForResult(picker,PICK_FOLDER);}
        catch(RuntimeException e){folderPreview.setText("System folder picker unavailable on this device.");}
    }
    private static void revokeUnusedPair(RemotePhoneEnrollment.Pairing pair){
        new Thread(()->{try{RemotePhoneEnrollment.revoke(pair);}catch(Exception ignored){}},
                "remote-unused-pair-revoke").start();
    }
    private void stopRemoteBridge(){
        remoteWanted=false;
        RemotePhonePoller poller=remotePoller;remotePoller=null;
        RemotePhoneEnrollment.Pairing pair=remotePairing;remotePairing=null;
        if(poller!=null)poller.stop();else if(pair!=null)revokeUnusedPair(pair);
        if(remoteCode!=null)remoteCode.setText("");
        if(remoteStatus!=null)remoteStatus.setText("Remote bridge stopped. If offline, revoke the pairing from the owner chat.");
    }
    private void remoteBridgeEnded(){
        if(remotePoller!=null&&!remotePoller.isRunning()){
            remotePoller=null;remotePairing=null;remoteWanted=false;
            remoteStatus.setText("Remote connection stopped. If offline, revoke the pairing from the owner chat before retrying.");
        }
    }
    private interface FolderAction {String run(SafFolder folder) throws Exception;}
    private void withFolder(FolderAction action){
        SafFolder folder=selectedFolder;if(folder==null)return;
        folderPreview.setText("Reading selected folder...");
        new Thread(()->{
            String result;
            try{result=action.run(folder);}catch(Exception e){
                String code=safeFolderCode(e);
                result="NAME_NOT_ALLOWED".equals(code)
                        ?"Enter a file name above, such as test.txt (NAME_NOT_ALLOWED)."
                        :"TYPE_NOT_ALLOWED".equals(code)
                        ?"Enter a .txt, .md, or .json file name above (TYPE_NOT_ALLOWED)."
                        :"Folder unavailable or outside limits ("+code+").";
            }
            final String shown=result;
            MAIN.post(()->{if(!destroyed&&selectedFolder==folder)folderPreview.setText(shown);});
        },"selected-folder-read").start();
    }
    private static String safeFolderCode(Exception error){
        String code=error.getMessage();
        if(code!=null&&code.matches("[A-Z_]{3,40}"))return code;
        return "PROVIDER_ERROR";
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode!=PICK_FOLDER)return;
        if(resultCode!=RESULT_OK){folderPreview.setText("Folder selection cancelled.");return;}
        if(!FolderPickerFlow.acceptPickerResult(active!=null,active!=null&&active.settled)){
            folderPreview.setText("Session still active. End it, then choose a folder again.");return;
        }
        try{
            SafFolder selected=SafFolder.fromPicker(this,data);
            SafFolder old=selectedFolder;if(old!=null)old.revoke();
            selectedFolder=selected;folderPreview.setText("Folder selected. Use List or View before starting sign-in.");
            render(active);
        }catch(Exception e){folderPreview.setText("Folder selection failed ("+safeFolderCode(e)+").");}
    }
    private void showFile(String name){
        try{if(workspace==null)throw new IllegalStateException();
            PhoneWorkspace.Snapshot s=workspace.read(name);
            projectPreview.setText(name+"  sha256="+s.sha256+"\n"+s.text+(s.truncated?"\n[Preview truncated]":""));
        }catch(Exception ignored){projectPreview.setText("Project file unavailable or outside limits.");}
    }
    private void resolveApproval(boolean allow){
        Attempt attempt=active;if(attempt==null||attempt.settled||attempt.userEnded)return;
        if(attempt.pendingTool!=null){
            attempt.pendingTool.resolve(allow);attempt.pendingTool=null;
            attempt.pendingTitle="";attempt.pendingReview="";
            attempt.pendingPanelAction=false;attempt.regeneratedPendingPanelAction=false;
            attempt.status=allow?"Approved once; waiting for the tool result.":"Tool request rejected.";
        }else if(attempt.manualCheckPending){
            attempt.manualCheckPending=false;attempt.pendingTitle="";attempt.pendingReview="";
            if(allow){try{attempt.status=workspace.check();showFile(PhoneWorkspace.DATA);}
                catch(Exception ignored){attempt.status="Project check failed or exceeded its limits.";}}
            else attempt.status="Project check rejected.";
        }
        attempt.render();
    }
    private ManagedChatSession.PanelImage captureOwnPanel(Attempt attempt,long token) throws Exception {
        if(Looper.myLooper()==Looper.getMainLooper())throw new IllegalStateException("OWN_PANEL_THREAD_INVALID");
        CountDownLatch done=new CountDownLatch(1);
        AtomicBoolean waiting=new AtomicBoolean(true);
        final ManagedChatSession.PanelImage[] result={null};
        final Exception[] failure={null};
        if(!MAIN.post(()->{
            if(!waiting.get())return;
            try{
                if(active!=attempt||attempt.screen!=this||destroyed||!attempt.foreground
                        ||!hasWindowFocus()||!attempt.screenStatusGate.valid(token))
                    throw new IllegalStateException("OWN_PANEL_REVOKED");
                result[0]=ownPanel.snapshot();
                if(!attempt.screenStatusGate.valid(token))throw new IllegalStateException("OWN_PANEL_REVOKED");
            }catch(Exception error){failure[0]=error;result[0]=null;}
            finally{done.countDown();}
        }))throw new IllegalStateException("OWN_PANEL_UI_UNAVAILABLE");
        try{
            if(!done.await(5,TimeUnit.SECONDS))throw new IllegalStateException("OWN_PANEL_TIMEOUT");
        }finally{waiting.set(false);}
        if(failure[0]!=null)throw failure[0];
        if(result[0]==null)throw new IllegalStateException("OWN_PANEL_UNAVAILABLE");
        return result[0];
    }
    private boolean selectOwnPanelCell(Attempt attempt,long revision,int row,int column,long token) throws Exception {
        if(Looper.myLooper()==Looper.getMainLooper())throw new IllegalStateException("OWN_PANEL_THREAD_INVALID");
        CountDownLatch done=new CountDownLatch(1);
        AtomicBoolean waiting=new AtomicBoolean(true);
        final boolean[] applied={false};
        final Exception[] failure={null};
        if(!MAIN.post(()->{
            if(!waiting.get())return;
            try{
                if(active!=attempt||attempt.screen!=this||destroyed||!attempt.foreground||!hasWindowFocus())
                    throw new IllegalStateException("OWN_PANEL_REVOKED");
                synchronized(attempt.screenStatusGate){
                    if(!attempt.screenStatusGate.valid(token))throw new IllegalStateException("OWN_PANEL_REVOKED");
                    applied[0]=ownPanel.selectCell(revision,row,column);
                }
            }catch(Exception error){failure[0]=error;}
            finally{done.countDown();}
        }))throw new IllegalStateException("OWN_PANEL_UI_UNAVAILABLE");
        try{
            if(!done.await(5,TimeUnit.SECONDS))throw new IllegalStateException("OWN_PANEL_TIMEOUT");
        }finally{waiting.set(false);}
        if(failure[0]!=null)throw failure[0];
        return applied[0];
    }
    private static void runAttempt(Attempt attempt,File filesDir,File binary){
        String finalCode="";
        try{
            attempt.session.run(filesDir,binary,new ManagedChatSession.Events(){
                public void showCode(String value){MAIN.post(()->{
                    if(active==attempt&&!attempt.settled){
                        attempt.code=value;attempt.status="Enter this code on the verification page, then return here.";
                        attempt.render();
                    }
                });}
                public void ready(int submittedTurns){MAIN.post(()->{
                    if(active==attempt&&!attempt.settled){
                        attempt.code="";attempt.ready=true;attempt.submitted=submittedTurns;
                        if(!attempt.inFlight&&!attempt.status.startsWith("Stopped.")
                                &&!attempt.status.startsWith("Turn failed."))
                            attempt.status="Signed in for this session. Tap Send for each message. "
                                    +(ManagedChatSession.MAX_TURNS-submittedTurns)+" messages remain.";
                        attempt.render();
                    }
                });}
                public void turnCompleted(String prompt,ManagedChatSession.Result result){MAIN.post(()->{
                    if(active==attempt&&!attempt.settled){
                        boolean lateStop=attempt.stopping;
                        attempt.transcript.append("You: ").append(prompt).append("\nCodex: ")
                                .append(result.text).append("\n\n");
                        if(result.visualExpected!=null)
                            attempt.transcript.append("[Local visual check, shown after reply: ")
                                    .append(result.visualExpected).append(". Compare with Codex's answer.]\n\n");
                        attempt.inFlight=false;attempt.stopping=false;attempt.inFlightPrompt="";
                        attempt.status=lateStop?"Turn completed before Stop took effect. No request was resent."
                                :"Turn completed. Tap Send for another message.";
                        attempt.render();
                    }
                });}
                public void turnStopped(String prompt,boolean started){MAIN.post(()->{
                    if(active==attempt&&!attempt.settled){
                        attempt.transcript.append("You: ").append(prompt).append(started
                                ?"\n[Turn interrupted]\n\n":"\n[Stopped before request]\n\n");
                        attempt.inFlight=false;attempt.stopping=false;attempt.inFlightPrompt="";
                        attempt.draft=prompt;
                        attempt.status="Stopped. Draft restored; tap Send only if you choose to send again.";
                        attempt.render();
                    }
                });}
                public void turnFailed(String prompt){MAIN.post(()->{
                    if(active==attempt&&!attempt.settled){
                        attempt.transcript.append("You: ").append(prompt).append("\n[Turn failed]\n\n");
                        attempt.inFlight=false;attempt.stopping=false;attempt.inFlightPrompt="";
                        attempt.draft=prompt;
                        attempt.status="Turn failed. Draft restored; tap Send only if you choose to try again.";
                        attempt.render();
                    }
                });}
                public void approveTool(String title,String review,ManagedChatSession.ToolGate decision){
                    queueApproval(attempt,title,review,decision,false);
                }
                public void approvePanelAction(String title,String review,ManagedChatSession.ToolGate decision){
                    queueApproval(attempt,title,review,decision,true);
                }
                public void toolNotice(String message){MAIN.post(()->{
                    if(active==attempt&&!attempt.settled){
                        attempt.pendingTool=null;attempt.pendingTitle="";attempt.pendingReview="";
                        attempt.pendingPanelAction=false;attempt.regeneratedPendingPanelAction=false;
                        attempt.transcript.append("[Project tool: ").append(message).append("]\n");
                        attempt.status="Project tool: "+message;
                        attempt.render();
                    }
                });}
            });
        }catch(ManagedChatSession.GateException e){finalCode=e.code;}
        final String codeValue=finalCode;
        MAIN.post(()->{if(active==attempt){
            attempt.session.revokeScreenStatus();
            attempt.code="";attempt.settled=true;attempt.ready=false;
            if(attempt.inFlight){attempt.draft=attempt.inFlightPrompt;attempt.inFlight=false;}
            attempt.stopping=false;attempt.inFlightPrompt="";
            attempt.loginFailed=!attempt.session.authenticated()&&!attempt.userEnded;
            attempt.errorCode=codeValue;
            if(attempt.userEnded||"CANCELLED".equals(codeValue))
                attempt.status="Session ended. Start a new sign-in to begin a new conversation.";
            else if(attempt.loginFailed)
                attempt.status=signInError(codeValue);
            else if("TURN_LIMIT_REACHED".equals(attempt.session.stage()))
                attempt.status="Twelve messages reached. Start a new sign-in for a new conversation.";
            else if("SESSION_IDLE_CLOSED".equals(codeValue))
                attempt.status="Session closed after ten idle minutes. Draft kept in this process.";
            else attempt.status="Session closed during a request ("+codeValue+"). Outcome may be uncertain. "
                    +"A new sign-in will not resend it automatically.";
            attempt.render();
            if(FolderPickerFlow.openAfterEnd(attempt.pickAfterEnd,attempt.settled,attempt.screen!=null)){
                attempt.pickAfterEnd=false;attempt.screen.launchFolderPicker();
            }
        }});
    }
    private static void queueApproval(Attempt attempt,String title,String review,
            ManagedChatSession.ToolGate decision,boolean panelAction){
        MAIN.post(()->{
            if(active!=attempt||attempt.settled||attempt.userEnded||attempt.pendingTool!=null
                    ||!decision.isOpen()){decision.resolve(false);return;}
            attempt.pendingTool=decision;attempt.pendingTitle=title;attempt.pendingReview=review;
            attempt.pendingPanelAction=panelAction;attempt.regeneratedPendingPanelAction=false;
            attempt.status="Tool request needs your approval. Review the complete change below.";
            attempt.render();
            if(attempt.screen!=null)attempt.screen.scroll.post(()->attempt.screen.scroll.smoothScrollTo(0,attempt.screen.approvalReview.getTop()));
        });
    }
    private static String signInError(String code){
        if(code.startsWith("POLL_CONNECT")||"POLL_TRANSPORT_TIMEOUT".equals(code))
            return "Connection interrupted while checking sign-in ("+code+"). Tap Retry Sign-in for a fresh code. No message was sent.";
        if("DEVICE_POLL_TIMEOUT".equals(code)||"POLL_EXPIRED".equals(code))
            return "Sign-in code expired ("+code+"). Tap Retry Sign-in for a fresh code. No message was sent.";
        return "Sign-in did not complete ("+code+"). Tap Retry Sign-in. No message was sent.";
    }
    private void render(Attempt attempt){
        if(ownPanel!=null&&(attempt==null||!attempt.screenStatusGate.active())&&ownPanel.getVisibility()!=View.GONE)
            ownPanel.clear();
        String scope=selectedFolder==null?"No folder selected. The built-in toy project remains available.":selectedFolder.scope();
        folderScope.setText(scope+(attempt!=null&&!attempt.settled?"\nChanging the folder requires ending this session and signing in again.":""));
        pickFolder.setEnabled(true);
        pickFolder.setText(attempt!=null&&!attempt.settled?"END SESSION & CHOOSE FOLDER":"CHOOSE FOLDER (SYSTEM PICKER)");
        disconnectFolder.setEnabled(selectedFolder!=null&&(attempt==null||!attempt.inFlight));
        listFolder.setEnabled(selectedFolder!=null);showFolderFile.setEnabled(selectedFolder!=null);
        showReadme.setEnabled(workspace!=null);showData.setEnabled(workspace!=null);
        if(attempt==null){
            screenStatusStart.setEnabled(false);screenStatusStop.setEnabled(false);
            missingImageProbe.setEnabled(false);missingImageProbe.setVisibility(View.GONE);
            missingImageProbeResult.setText("");
            regeneratePanel.setEnabled(false);regeneratePanel.setVisibility(View.GONE);
            screenStatusLabel.setText("Local screen status off. Start a sign-in session first.");
            code.setText("");transcript.setText("");
            if(!input.getText().toString().equals(pendingDraft))input.setText(pendingDraft);
            input.setEnabled(true);signIn.setEnabled(true);signIn.setText("START SIGN-IN");
            open.setEnabled(false);send.setEnabled(false);stop.setEnabled(false);end.setEnabled(false);
            checkProject.setEnabled(false);approvalReview.setText("");approve.setEnabled(false);reject.setEnabled(false);
            status.setText(restoredWithoutProcess?"Previous in-memory session ended with the app process. Start a new sign-in manually.":
                    "Enter a draft now or after sign-in. Nothing is sent until you tap Send.");return;
        }
        code.setText(attempt.code.isEmpty()?"":"Code: "+attempt.code);
        if(!input.getText().toString().equals(attempt.draft))input.setText(attempt.draft);
        input.setEnabled(ChatScreenRules.input(attempt.inFlight));
        signIn.setEnabled(ChatScreenRules.signIn(true,attempt.settled));
        signIn.setText(attempt.loginFailed?"RETRY SIGN-IN (keeps draft)":"NEW SIGN-IN (new conversation)");
        open.setEnabled(!attempt.code.isEmpty()&&!attempt.settled);
        send.setEnabled(ChatScreenRules.send(attempt.ready,attempt.inFlight,attempt.settled,attempt.submitted));
        stop.setEnabled(ChatScreenRules.stop(attempt.inFlight,attempt.stopping,attempt.settled));
        end.setEnabled(ChatScreenRules.end(true,attempt.settled));
        boolean screenActive=attempt.screenStatusGate.active()&&!attempt.settled&&!attempt.userEnded;
        screenStatusStart.setEnabled(!screenActive&&!attempt.settled&&!attempt.userEnded
                &&attempt.foreground&&hasWindowFocus());
        screenStatusStop.setEnabled(screenActive);
        boolean probeReady=screenActive&&attempt.ready&&!attempt.inFlight&&!attempt.stopping
                &&!attempt.settled&&!attempt.userEnded&&attempt.foreground&&hasWindowFocus()
                &&attempt.pendingTool==null&&!attempt.manualCheckPending;
        missingImageProbe.setVisibility((probeReady||attempt.localGuardProbeRun)?View.VISIBLE:View.GONE);
        missingImageProbe.setEnabled(probeReady&&!attempt.localGuardProbeRun);
        missingImageProbeResult.setText(attempt.localGuardProbeText);
        screenStatusLabel.setText(screenActive?"Local screen status ON. Each tool call needs separate approval."
                :"Local screen status OFF. No capture or tap is available.");
        boolean pending=!attempt.settled&&!attempt.userEnded&&
                ((attempt.pendingTool!=null&&attempt.pendingTool.isOpen())||attempt.manualCheckPending);
        boolean panelActionPending=pending&&attempt.inFlight&&attempt.pendingPanelAction
                &&attempt.pendingTool!=null&&attempt.pendingTool.isOpen();
        regeneratePanel.setVisibility(panelActionPending?View.VISIBLE:View.GONE);
        regeneratePanel.setEnabled(panelActionPending&&!attempt.regeneratedPendingPanelAction
                &&screenActive&&attempt.foreground&&hasWindowFocus());
        checkProject.setEnabled(workspace!=null&&!attempt.inFlight&&!attempt.settled&&!pending);
        approvalReview.setText(pending?attempt.pendingTitle+"\n\n"+attempt.pendingReview:"");
        approve.setEnabled(pending);reject.setEnabled(pending);
        status.setText(attempt.status);transcript.setText(attempt.transcript.toString());
    }
    @Override protected void onSaveInstanceState(Bundle out){out.putBoolean("attempted",active!=null||restoredWithoutProcess);super.onSaveInstanceState(out);}
    @Override protected void onStart(){super.onStart();Attempt attempt=active;
        if(attempt!=null&&attempt.screen==this){
            attempt.foreground=true;attempt.screenStatusGate.setForeground(true);
            attempt.screenStatusGate.setFocused(hasWindowFocus());attempt.render();
        }}
    @Override protected void onStop(){stopRemoteBridge();Attempt attempt=active;
        if(attempt!=null&&attempt.screen==this){
            attempt.foreground=false;
            attempt.screenStatusGate.setForeground(false);attempt.session.revokeScreenStatus();
            ownPanel.clear();
            if(!attempt.inFlight)attempt.draft=input.getText().toString();
        }else if(attempt==null)pendingDraft=input.getText().toString();
        super.onStop();
    }
    @Override protected void onDestroy(){
        stopRemoteBridge();destroyed=true;Attempt attempt=active;
        if(attempt!=null&&attempt.screen==this){
            attempt.session.revokeScreenStatus();
            ownPanel.clear();
            attempt.screen=null;if(isFinishing()&&!attempt.settled)attempt.session.cancel();
        }
        code.setText("");input.setText("");super.onDestroy();
    }
    @Override public void onWindowFocusChanged(boolean hasFocus){
        super.onWindowFocusChanged(hasFocus);
        Attempt attempt=active;
        if(attempt!=null&&attempt.screen==this){
            attempt.screenStatusGate.setFocused(hasFocus&&attempt.foreground);
            if(!hasFocus)attempt.session.revokeScreenStatus();
            attempt.render();
        }
    }
}


