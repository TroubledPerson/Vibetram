// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

/** Process-memory-only display state for one device-code attempt. */
final class ManagedDeviceCodeUiState {
    private String code="";
    private final StringBuilder history=new StringBuilder("CASE=MANAGED_DEVICE_CODE\n");
    private boolean cancelled,terminal;

    boolean showCode(String value){
        if(cancelled||terminal)return false;
        code=value;
        history.append("STATE=AWAITING_USER_ON_OPENAI_PAGE\n");
        return true;
    }
    boolean cancel(){
        if(cancelled||terminal)return false;
        cancelled=true;
        code="";
        history.append("CANCEL_REQUESTED\nCODE_CLEARED=USER_CANCELLED\n");
        return true;
    }
    void finish(String result,boolean success){
        if(terminal)return;
        terminal=true;
        code="";
        history.append(success?"CODE_CLEARED=SIGN_IN_COMPLETE\n":"CODE_CLEARED=ATTEMPT_ENDED\n");
        history.append(result).append('\n');
    }
    String code(){return code;}
    String report(){return history.toString();}
    boolean canOpen(){return !cancelled&&!terminal&&!code.isEmpty();}
    boolean terminal(){return terminal;}
}
