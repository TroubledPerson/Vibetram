// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;
import java.nio.ByteBuffer;
/** Owned bounded pixels; no decoder, file, URI, capture, undo store or delivery path. */
final class LocalReviewImage {
 final int width,height;final CapturedPng png;private final int[] rgb;
 private LocalReviewImage(int w,int h,int[] rgb,Runnable guard){
  if(w<1||h<1||w>640||h>640||(long)w*h!=rgb.length)throw new IllegalArgumentException("LOCAL_PIXEL_BOUNDS");
  width=w;height=h;this.rgb=rgb;byte[] raw=new byte[w*h*4];
  for(int y=0;y<h;y++){guard.run();for(int x=0;x<w;x++){int p=rgb[y*w+x],o=(y*w+x)*4;raw[o]=(byte)(p>>16);raw[o+1]=(byte)(p>>8);raw[o+2]=(byte)p;raw[o+3]=(byte)255;}}
  png=CapturedPng.rgba(ByteBuffer.wrap(raw),w,h,w*4,4,guard,false);guard.run();
 }
 static LocalReviewImage fromArgb(int w,int h,int[] argb,Runnable guard){
  guard.run();if(argb==null||w<1||h<1||w>640||h>640||(long)w*h!=argb.length)throw new IllegalArgumentException("LOCAL_PIXEL_BOUNDS");
  int[] owned=new int[argb.length];for(int y=0;y<h;y++){guard.run();for(int x=0;x<w;x++){int p=argb[y*w+x],a=p>>>24;owned[y*w+x]=(((p>>16&255)*a/255)<<16)|(((p>>8&255)*a/255)<<8)|((p&255)*a/255);}}
  return new LocalReviewImage(w,h,owned,guard);
 }
 private void rectangle(int x,int y,int w,int h){if(x<0||y<0||w<1||h<1||(long)x+w>width||(long)y+h>height)throw new IllegalArgumentException("LOCAL_RECT_BOUNDS");}
 LocalReviewImage crop(int x,int y,int w,int h,Runnable guard){
  guard.run();rectangle(x,y,w,h);int[] out=new int[w*h];for(int row=0;row<h;row++){guard.run();System.arraycopy(rgb,(y+row)*width+x,out,row*w,w);}return new LocalReviewImage(w,h,out,guard);
 }
 LocalReviewImage redact(int x,int y,int w,int h,Runnable guard){
  guard.run();rectangle(x,y,w,h);int[] out=new int[rgb.length];for(int row=0;row<height;row++){guard.run();System.arraycopy(rgb,row*width,out,row*width,width);if(row>=y&&row<y+h)java.util.Arrays.fill(out,row*width+x,row*width+x+w,0);}return new LocalReviewImage(width,height,out,guard);
 }
 int pixel(int x,int y){rectangle(x,y,1,1);return rgb[y*width+x];}
}
