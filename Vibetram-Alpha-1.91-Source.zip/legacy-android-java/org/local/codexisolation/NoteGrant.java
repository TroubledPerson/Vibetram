// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;
import android.os.*;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;

/** Same fixed Binder protocol; authority policy is shared with the host tests. */
final class NoteGrant extends Binder {
    static final String DESCRIPTOR = "org.local.codexisolation.note.read.v1";
    static final int READ = IBinder.FIRST_CALL_TRANSACTION, MAX_PARCEL = 1024;
    final byte[] token = random();
    final long generation;
    final byte[] expectedHash;
    final GrantState state;
    NoteGrant(long generation, GrantState.Clock clock) {
        this.generation = generation;
        byte[] note = ("parent-note-" + hex(random())).getBytes(StandardCharsets.US_ASCII);
        expectedHash = digest(note);
        state = new GrantState(clock, generation, android.os.Process.myUid(), token, note);
    }
    private static byte[] random() { byte[] b = new byte[32]; new SecureRandom().nextBytes(b); return b; }
    static byte[] digest(byte[] bytes) { return GrantState.digest(bytes); }
    static String hex(byte[] bytes) {
        StringBuilder s = new StringBuilder();
        for (byte b : bytes) s.append(String.format(java.util.Locale.ROOT, "%02x", b & 255));
        return s.toString();
    }
    void revoke() { state.revoke(); }
    @Override protected boolean onTransact(int code, Parcel in, Parcel out, int flags) throws RemoteException {
        if (code != READ) throw new SecurityException("Unsupported operation");
        byte[] supplied = new byte[32]; long requestedGeneration; int request;
        try {
            if (out == null || (flags & IBinder.FLAG_ONEWAY) != 0 || in.dataSize() > MAX_PARCEL)
                throw new SecurityException("Malformed request");
            in.enforceInterface(DESCRIPTOR); in.readByteArray(supplied);
            requestedGeneration = in.readLong(); request = in.readInt();
            if (in.dataAvail() != 0) throw new SecurityException("Trailing request");
        } catch (RuntimeException invalid) { state.malformed(); return true; }
        state.read(supplied, requestedGeneration, request, Binder.getCallingUid(), flags, bytes -> {
            out.writeNoException(); out.writeLong(generation); out.writeInt(request); out.writeByteArray(bytes);
        });
        return true;
    }
}
