// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/** Synthetic parent fixture and the exact, credential-free worker capability. */
final class OfflineFixtureProtocol {
    static final int AUTH_CALLBACK=1, AUTH_REPLAY_REJECTED=2, AUTH_CANCEL_REJECTED=4;
    static final int EXPECTED_FLAGS=AUTH_CALLBACK|AUTH_REPLAY_REJECTED|AUTH_CANCEL_REJECTED;
    static final String EXPECTED_TEXT="Hi \uD83C\uDF0D";
    static final int MAX_PARCEL=1024;

    static final class Packet {
        final long requestId;
        final int authFlags;
        final List<OfflineSseAdapter.Message> messages;
        Packet(long requestId,int authFlags,List<OfflineSseAdapter.Message> messages) {
            this.requestId=requestId;this.authFlags=authFlags;
            this.messages=Collections.unmodifiableList(new ArrayList<>(messages));
        }
    }

    static Packet synthetic(OfflineAuthBoundary.Clock clock,SecureRandom random) {
        long requestId=random.nextLong()&Long.MAX_VALUE;
        if(requestId==0)requestId=1;
        OfflineBrowserLifecycle accepted=new OfflineBrowserLifecycle();
        OfflineAuthBoundary.Attempt attempt=accepted.prepare(49152,clock,random);
        accepted.browserOpened();
        String callback=attempt.redirectUri+"?state="+attempt.state+"&code=dummy_offline_code";
        int flags=0;
        if("dummy_offline_code".equals(accepted.callback(callback,clock)) && accepted.closed())flags|=AUTH_CALLBACK;
        try { accepted.callback(callback,clock); } catch(SecurityException expected) { flags|=AUTH_REPLAY_REJECTED; }

        OfflineBrowserLifecycle cancelled=new OfflineBrowserLifecycle();
        OfflineAuthBoundary.Attempt second=cancelled.prepare(49153,clock,random);
        cancelled.browserOpened();cancelled.activityDestroyed();
        try { cancelled.callback(second.redirectUri+"?state="+second.state+"&code=dummy_offline_code",clock); }
        catch(SecurityException expected) { flags|=AUTH_CANCEL_REJECTED; }

        String sse="event: response.output_text.delta\n"
                +"data: {\"type\":\"response.output_text.delta\",\"delta\":\""+EXPECTED_TEXT+"\"}\n\n"
                +"event: response.completed\n"
                +"data: {\"type\":\"response.completed\"}\n\n";
        byte[] bytes=sse.getBytes(StandardCharsets.UTF_8);
        byte[] emoji="\uD83C\uDF0D".getBytes(StandardCharsets.UTF_8);
        int split=-1;
        for(int i=0;i<=bytes.length-emoji.length;i++) {
            if(Arrays.equals(Arrays.copyOfRange(bytes,i,i+emoji.length),emoji)) {split=i+1;break;}
        }
        if(split<0)throw new SecurityException("Fixture split missing");
        OfflineSseAdapter parser=new OfflineSseAdapter(requestId);
        List<OfflineSseAdapter.Message> messages=new ArrayList<>();
        messages.addAll(parser.feed(Arrays.copyOfRange(bytes,0,split)));
        messages.addAll(parser.feed(Arrays.copyOfRange(bytes,split,bytes.length)));
        parser.endOfInput();
        Packet packet=new Packet(requestId,flags,messages);
        validate(packet);
        return packet;
    }

    /** Called again in the isolated worker after Parcel decoding. */
    static void validate(Packet packet) {
        if(packet==null || packet.requestId<=0 || packet.authFlags!=EXPECTED_FLAGS
                || packet.messages.size()!=2)throw new SecurityException("Offline fixture envelope");
        OfflineSseAdapter.Message text=packet.messages.get(0), done=packet.messages.get(1);
        if(text==null || done==null || text.requestId!=packet.requestId || done.requestId!=packet.requestId
                || text.sequence!=1 || done.sequence!=2
                || !"text".equals(text.kind) || !EXPECTED_TEXT.equals(text.text)
                || !"done".equals(done.kind) || !"".equals(done.text))
            throw new SecurityException("Offline fixture message");
    }

    private OfflineFixtureProtocol() {}
}
