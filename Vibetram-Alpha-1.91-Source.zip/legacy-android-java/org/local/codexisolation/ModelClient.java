// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;
import android.os.*;
/** JNI transports one bounded event frame per pull; Rust validates event order. */
public final class ModelClient {
    private final IBinder broker;private final byte[] token;private final long generation;
    ModelClient(IBinder broker,byte[] token,long generation){this.broker=broker;this.token=token.clone();this.generation=generation;}
    // No monitor: a cancellation RPC can revoke a blocked exchange.
    public byte[] exchange(byte[] request)throws RemoteException {
        if(request==null||request.length<10||request.length>ModelPolicy.MAX_WIRE)throw new SecurityException("Stream request");
        Parcel in=Parcel.obtain(),out=Parcel.obtain();
        try{in.writeInterfaceToken(StreamGrant.DESCRIPTOR);in.writeByteArray(token);in.writeLong(generation);in.writeInt(request.length);in.writeByteArray(request);
            if(!broker.transact(StreamGrant.EXCHANGE,in,out,0)||out.dataSize()>80)throw new RemoteException("Stream reply bounds");
            out.readException();if(out.dataAvail()<16||out.readLong()!=generation)throw new RemoteException("Stream generation");int n=out.readInt();
            if(n<12||n>StreamProtocol.MAX_FRAME||out.dataAvail()!=4+((n+3)&~3))throw new RemoteException("Stream frame bounds");byte[] reply=new byte[n];out.readByteArray(reply);if(out.dataAvail()!=0)throw new RemoteException("Trailing stream reply");return reply;
        }finally{in.recycle();out.recycle();}
    }
}
