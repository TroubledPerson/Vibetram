// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

/** Fixed, content-free categories from the pinned native app-server. */
final class PreItemDiagnostic {
    private static final int CALL=1, REGISTERED=2, UNREGISTERED=4, INVALID=8, STARTED=16;
    private static final int PARSED=32,PARSE_FAILED=64,RECEIVED=128,CALLBACK=256;
    private int flags;
    private String schemas="?",response="?";

    void reset(){flags=0;schemas="?";response="?";}

    static boolean isMarker(String message){
        return "CORETEST_DIAG_CALL_SEEN".equals(message)
                ||"CORETEST_DIAG_NAME_REGISTERED".equals(message)
                ||"CORETEST_DIAG_NAME_UNREGISTERED".equals(message)
                ||"CORETEST_DIAG_ARGUMENTS_INVALID".equals(message)
                ||"CORETEST_DIAG_ITEM_STARTED".equals(message)
                ||"CORETEST_DIAG_STREAM_CALL_PARSED".equals(message)
                ||"CORETEST_DIAG_STREAM_CALL_PARSE_FAILED".equals(message)
                ||"CORETEST_DIAG_RESPONSE_DONE_NO_PARSED_CALL".equals(message)
                ||"CORETEST_DIAG_RESPONSE_DONE_WITH_PARSED_CALL".equals(message)
                ||"CORETEST_DIAG_PROJECT_SCHEMAS_0".equals(message)
                ||"CORETEST_DIAG_PROJECT_SCHEMAS_1".equals(message)
                ||"CORETEST_DIAG_PROJECT_SCHEMAS_2".equals(message)
                ||"CORETEST_DIAG_PROJECT_SCHEMAS_3".equals(message)
                ||"CORETEST_DIAG_PROJECT_SCHEMAS_OTHER".equals(message);
    }

    void observe(String message){
        if("CORETEST_DIAG_CALL_SEEN".equals(message))flags|=CALL;
        else if("CORETEST_DIAG_NAME_REGISTERED".equals(message))flags|=REGISTERED;
        else if("CORETEST_DIAG_NAME_UNREGISTERED".equals(message))flags|=UNREGISTERED;
        else if("CORETEST_DIAG_ARGUMENTS_INVALID".equals(message))flags|=INVALID;
        else if("CORETEST_DIAG_ITEM_STARTED".equals(message))flags|=STARTED;
        else if("CORETEST_DIAG_STREAM_CALL_PARSED".equals(message))flags|=PARSED;
        else if("CORETEST_DIAG_STREAM_CALL_PARSE_FAILED".equals(message))flags|=PARSE_FAILED;
        else if("CORETEST_DIAG_RESPONSE_DONE_NO_PARSED_CALL".equals(message)){
            if(!"with-call".equals(response))response="no-call";
        }
        else if("CORETEST_DIAG_RESPONSE_DONE_WITH_PARSED_CALL".equals(message))response="with-call";
        else if(message.startsWith("CORETEST_DIAG_PROJECT_SCHEMAS_")&&isMarker(message))
            schemas=message.substring("CORETEST_DIAG_PROJECT_SCHEMAS_".length()).toLowerCase(java.util.Locale.ROOT);
    }

    void itemReceived(){flags|=RECEIVED;}
    void callbackReceived(){flags|=CALLBACK;}

    String summary(){
        return "native tool path: project-schemas="+schemas+" response="+response
                +" parsed="+yes(PARSED)+" parse-failed="+yes(PARSE_FAILED)
                +" call="+yes(CALL)+" registered="+yes(REGISTERED)
                +" unsupported="+yes(UNREGISTERED)+" invalid-args="+yes(INVALID)
                +" item-emitted="+yes(STARTED)+" item-received="+yes(RECEIVED)
                +" callback-received="+yes(CALLBACK);
    }

    private String yes(int flag){return (flags&flag)==0?"no":"yes";}
}
