// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Locale;

/** Pure policy shared by the Android document provider bridge and host checks. */
final class FolderPolicy {
    static final int MAX_ENTRIES=64,MAX_BYTES=4096,MAX_NAME=64;
    private FolderPolicy(){}
    static String name(String value) throws IOException {
        if(value==null||value.length()<1||value.length()>MAX_NAME||value.charAt(0)=='.'
                ||value.charAt(0)==' '||value.endsWith(" ")||value.equals(".."))throw new IOException("NAME_NOT_ALLOWED");
        for(int i=0;i<value.length();i++){
            char c=value.charAt(i);
            if(!((c>='A'&&c<='Z')||(c>='a'&&c<='z')||(c>='0'&&c<='9')
                    ||c=='.'||c=='_'||c=='-'||c==' '))throw new IOException("NAME_NOT_ALLOWED");
        }
        String lower=value.toLowerCase(Locale.ROOT);
        if(!(lower.endsWith(".txt")||lower.endsWith(".md")||lower.endsWith(".json")))throw new IOException("TYPE_NOT_ALLOWED");
        return value;
    }
    static String text(byte[] bytes) throws IOException {
        if(bytes==null||bytes.length>MAX_BYTES)throw new IOException("FILE_TOO_LARGE");
        try{return StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(bytes)).toString();}
        catch(CharacterCodingException e){throw new IOException("INVALID_UTF8",e);}
    }
    static byte[] replacement(String value) throws IOException {
        if(value==null||value.indexOf('\0')>=0)throw new IOException("TEXT_INVALID");
        for(int i=0;i<value.length();i++){
            char c=value.charAt(i);
            if(Character.isHighSurrogate(c)){
                if(i+1>=value.length()||!Character.isLowSurrogate(value.charAt(i+1)))throw new IOException("UNICODE_INVALID");
                i++;
            }else if(Character.isLowSurrogate(c))throw new IOException("UNICODE_INVALID");
        }
        byte[] bytes=value.getBytes(StandardCharsets.UTF_8);
        if(bytes.length>MAX_BYTES)throw new IOException("REPLACEMENT_TOO_LARGE");
        return bytes;
    }
    static String sha(byte[] bytes) throws Exception {
        byte[] digest=MessageDigest.getInstance("SHA-256").digest(bytes);
        StringBuilder hex=new StringBuilder(64);
        for(byte b:digest)hex.append(String.format(Locale.ROOT,"%02x",b&255));
        return hex.toString();
    }
}
