// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

/** Local synthetic-test evidence. No token contents, image bytes, saved state or external actions. */
final class SimulatedReplayEvidence {
    static final class Snapshot {
        final SimulatedHandoff.State state;final int results,confirmations,frames,jobs;
        Snapshot(SimulatedHandoff c){state=c.state();results=c.results();confirmations=c.confirmations();frames=c.frames();jobs=c.releases();}
        String text(){return state+" results="+results+" confirmations="+confirmations+" frames="+frames+" jobs="+jobs;}
    }
    private static final class Cached {
        final SimulatedHandoff.Ticket ticket;final SimulatedHandoff.Result outcome;
        final long session;final int acceptedOrdinal;
        Cached(SimulatedHandoff.Ticket t,SimulatedHandoff.Result outcome,long session,int ordinal){
            ticket=t;this.outcome=outcome;this.session=session;acceptedOrdinal=ordinal;
        }
    }
    static final class Observation {
        final boolean attempted,accepted;final String outcome;
        final long sourceSession,targetSession;final Snapshot before,after;
        Observation(boolean attempted,boolean accepted,String outcome,long source,long target,Snapshot before,Snapshot after){
            this.attempted=attempted;this.accepted=accepted;this.outcome=outcome;sourceSession=source;targetSession=target;this.before=before;this.after=after;
        }
        String text(){
            if(!attempted)return "Replay attempted: NO / "+outcome;
            return "Replay attempted: YES / "+outcome+" (cached session "+sourceSession+" -> current session "+targetSession+")"
                    +"\nBefore replay: "+before.text()+"\nAfter replay: "+after.text()
                    +"\nReplay deltas: results="+(after.results-before.results)+" confirmations="+(after.confirmations-before.confirmations)
                    +" frames="+(after.frames-before.frames)+" jobs="+(after.jobs-before.jobs);
        }
    }
    private SimulatedHandoff current;private long session,invocations;
    private Cached cached;private Observation last;
    synchronized void attach(SimulatedHandoff c){
        if(c==null)throw new IllegalArgumentException();
        if(current!=c){current=c;session++;last=null;}
    }
    synchronized boolean primary(SimulatedHandoff c,SimulatedHandoff.Ticket t,SimulatedHandoff.Result outcome){
        if(c!=current)return false;
        synchronized(c){
            boolean accepted=c.result(t,outcome);
            if(accepted)cached=new Cached(t,outcome,session,c.results());
            return accepted;
        }
    }
    synchronized boolean hasAcceptedResult(){return cached!=null;}
    synchronized long invocations(){return invocations;}
    synchronized Observation replay(SimulatedHandoff c){
        if(c!=current)return new Observation(false,false,"NOT_CURRENT_SESSION",0,session,null,null);
        if(cached==null){last=new Observation(false,false,"NO_CACHED_ACCEPTED_RESULT",0,session,null,null);return last;}
        synchronized(c){
            Snapshot before=new Snapshot(c);boolean accepted=c.result(cached.ticket,cached.outcome);Snapshot after=new Snapshot(c);
            invocations++;last=new Observation(true,accepted,accepted?"ACCEPTED":"REJECTED",cached.session,session,before,after);
            return last;
        }
    }
    synchronized String text(){
        return "Current synthetic session: "+session+"\n"
                +(cached==null?"Cache: NO_CACHED_ACCEPTED_RESULT":
                    "Cache: GENUINE_ACCEPTED_RESULT session="+cached.session+" outcome="+cached.outcome+" accepted ordinal="+cached.acceptedOrdinal)
                +"\nReplay invocations (this screen lifetime): "+invocations+"\n"
                +(last==null?"Replay attempted in this session: NO":last.text());
    }
}
