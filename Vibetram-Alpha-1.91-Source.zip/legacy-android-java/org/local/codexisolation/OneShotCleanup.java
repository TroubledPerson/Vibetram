// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;
/** Attempt every owned cleanup step exactly once, even when an earlier step fails. */
final class OneShotCleanup {
 private boolean ran;
 synchronized boolean run(Runnable... steps){
  if(ran)return false;ran=true;boolean ok=true;
  for(Runnable step:steps)try{step.run();}catch(RuntimeException error){ok=false;}
  return ok;
 }
}
