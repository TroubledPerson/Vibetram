// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

import java.nio.charset.StandardCharsets;

/** Validates one in-memory, single-line prompt before the explicit Send gate opens. */
final class ShortPromptBoundary {
    static final int MAX_UTF16_UNITS=256;
    static final int MAX_UTF8_BYTES=1024;
    private ShortPromptBoundary(){}

    /** Returns null when valid, otherwise a fixed code that contains no prompt text. */
    static String check(String text){
        if(text==null||text.isEmpty())return "PROMPT_EMPTY";
        if(text.length()>MAX_UTF16_UNITS)return "PROMPT_TOO_LONG";
        boolean nonWhitespace=false;
        for(int i=0;i<text.length();){
            char first=text.charAt(i);
            int codepoint;
            if(Character.isHighSurrogate(first)){
                if(i+1>=text.length()||!Character.isLowSurrogate(text.charAt(i+1)))return "PROMPT_INVALID_UNICODE";
                codepoint=Character.toCodePoint(first,text.charAt(i+1));i+=2;
            }else{
                if(Character.isLowSurrogate(first))return "PROMPT_INVALID_UNICODE";
                codepoint=first;i++;
            }
            if(Character.isISOControl(codepoint))return "PROMPT_CONTROL_CHARACTER";
            if(!Character.isWhitespace(codepoint)&&!Character.isSpaceChar(codepoint))nonWhitespace=true;
        }
        if(!nonWhitespace)return "PROMPT_EMPTY";
        if(text.getBytes(StandardCharsets.UTF_8).length>MAX_UTF8_BYTES)return "PROMPT_TOO_LONG";
        return null;
    }
}
