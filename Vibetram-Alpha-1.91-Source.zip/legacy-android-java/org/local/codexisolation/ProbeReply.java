// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

/** Closed, non-sensitive status codes; failure frames never carry a proof. */
final class ProbeReply {
    static final int OK=0,NATIVE_NULL=1,NATIVE_LENGTH=2,LOAD_LINKAGE=3,JAVA_RUNTIME=4;
    static int classify(byte[] proof){return proof==null?NATIVE_NULL:proof.length==OutputProof.LENGTH?OK:NATIVE_LENGTH;}
    static String status(int code){return switch(code){case OK->"OK";case NATIVE_NULL->"NATIVE_NULL";case NATIVE_LENGTH->"NATIVE_LENGTH";case LOAD_LINKAGE->"LOAD_LINKAGE";case JAVA_RUNTIME->"JAVA_RUNTIME";default->"UNKNOWN";};}
    static int payloadSize(int code){if(code<OK||code>JAVA_RUNTIME)throw new SecurityException("Unknown worker status");return code==OK?176:4;}
    static void validate(int code,int remaining){if(remaining!=payloadSize(code))throw new SecurityException("Worker reply shape");}
    private ProbeReply(){}
}
