// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

import java.io.IOException;
import java.util.LinkedHashSet;

/** Paired-owner, one-request read gate. Network transport and credential enrollment are separate. */
final class RemotePhoneSession {
    interface Approval {boolean allow(String ownerId,String operation,String name);}
    static final class Request {
        final String id,ownerId,operation,name;final long expiresAt;
        Request(String id,String ownerId,String operation,String name,long expiresAt){
            this.id=id;this.ownerId=ownerId;this.operation=operation;this.name=name;this.expiresAt=expiresAt;
        }
    }
    static final class Result {
        final String id,decision,text,error;
        Result(String id,String decision,String text,String error){this.id=id;this.decision=decision;this.text=text;this.error=error;}
    }
    private final String expectedOwnerId;
    private final SelectedFolderAccess folder;
    private volatile boolean active=true;
    private final LinkedHashSet<String> seenRequests=new LinkedHashSet<>();
    RemotePhoneSession(String expectedOwnerId,SelectedFolderAccess folder){
        if(expectedOwnerId==null||expectedOwnerId.isEmpty()||folder==null)throw new IllegalArgumentException();
        this.expectedOwnerId=expectedOwnerId;this.folder=folder;
    }
    void disconnect(){active=false;}
    Result handle(Request request,Approval approval,long now) {
        if(!active)return new Result(request==null?"":request.id,"DENY","","BRIDGE_DISCONNECTED");
        if(request==null||request.id==null||!request.id.matches("[0-9a-f]{32}")
                ||!expectedOwnerId.equals(request.ownerId))return new Result("","DENY","","OWNER_MISMATCH");
        if(request.expiresAt<=now||request.expiresAt>now+60000)return new Result(request.id,"DENY","","REQUEST_EXPIRED");
        if(!"LIST".equals(request.operation)&&!"READ".equals(request.operation))
            return new Result(request.id,"DENY","","OPERATION_DENIED");
        String name="";
        if("READ".equals(request.operation))try{name=FolderPolicy.name(request.name);}
        catch(IOException error){return new Result(request.id,"DENY","","NAME_NOT_ALLOWED");}
        else if(request.name!=null&&!request.name.isEmpty())return new Result(request.id,"DENY","","ARGUMENTS_INVALID");
        synchronized(this){
            if(!seenRequests.add(request.id))return new Result(request.id,"DENY","","REQUEST_REPLAYED");
            if(seenRequests.size()>128)seenRequests.remove(seenRequests.iterator().next());
        }
        if(approval==null||!approval.allow(expectedOwnerId,request.operation,name))
            return new Result(request.id,"DENY","","PHONE_REJECTED");
        if(!active)return new Result(request.id,"DENY","","BRIDGE_DISCONNECTED");
        try {
            String text="LIST".equals(request.operation)?folder.list():folder.read(name).text;
            int bytes=text.getBytes(java.nio.charset.StandardCharsets.UTF_8).length;
            if(bytes>8192||("READ".equals(request.operation)&&bytes>FolderPolicy.MAX_BYTES))
                return new Result(request.id,"DENY","","RESULT_TOO_LARGE");
            return new Result(request.id,"ALLOW",text,"");
        }catch(Exception error){
            String code=error.getMessage();
            if(code==null||!code.matches("[A-Z_]{3,40}"))code="PHONE_ERROR";
            return new Result(request.id,"DENY","",code);
        }
    }
}
