// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Parcel;
import android.os.RemoteException;
import java.util.concurrent.atomic.AtomicBoolean;

/** One fixed Session per isolated process; accepts only a single-note capability. */
public final class CoreProbeService extends Service {
    static final String DESCRIPTOR = "org.local.codexisolation.core.stream-test.v1";
    static final int RUN = IBinder.FIRST_CALL_TRANSACTION;
    static final long LIFETIME_MS = 20000;
    private final AtomicBoolean started = new AtomicBoolean();
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Runnable terminate = () -> android.os.Process.killProcess(android.os.Process.myPid());

    private final Binder endpoint = new Binder() {
        @Override protected boolean onTransact(int code, Parcel in, Parcel out, int flags)
                throws RemoteException {
            if (code == INTERFACE_TRANSACTION) { out.writeString(DESCRIPTOR); return true; }
            if (code != RUN) return super.onTransact(code, in, out, flags);
            if (out == null || (flags & IBinder.FLAG_ONEWAY) != 0)
                throw new SecurityException("Synchronous fixture request required");
            if (in.dataSize() > NoteGrant.MAX_PARCEL) throw new SecurityException("Oversized grant");
            in.enforceInterface(DESCRIPTOR);
            IBinder broker = in.readStrongBinder();
            byte[] token = new byte[32];
            in.readByteArray(token);
            long generation = in.readLong();
            int scenario = in.readInt();
            IBinder modelBroker=in.readStrongBinder();byte[] modelToken=new byte[32];in.readByteArray(modelToken);
            if (broker == null || generation <= 0 || scenario != 23 || modelBroker == null || in.dataAvail() != 0)
                throw new SecurityException("Invalid grant");
            if (!android.os.Process.isIsolated()
                    || Binder.getCallingUid() == android.os.Process.myUid()) {
                throw new SecurityException("Separate isolated worker required");
            }
            if (!started.compareAndSet(false, true)) {
                throw new SecurityException("Fixture already started in this worker");
            }
            byte[] observed = null;
            int result=ProbeReply.NATIVE_NULL;
            try {
                byte[] output = NativeCoreProbe.runInIsolatedService(new NoteClient(broker, token, generation), new ModelClient(modelBroker,modelToken,generation));
                result=ProbeReply.classify(output);
                if (result==ProbeReply.OK) observed = output;
            } catch (LinkageError unavailable) { result=ProbeReply.LOAD_LINKAGE;
            } catch (RuntimeException unavailable) { result=ProbeReply.JAVA_RUNTIME; }
            out.writeNoException();
            out.writeLong(generation);
            out.writeInt(result);
            out.writeByteArray(observed);
            return true;
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        if (!android.os.Process.isIsolated()) throw new SecurityException("Isolation required");
        // The native join has no cancellation API. This bounds lifetime only while
        // Android's main looper remains responsive; it is not a hard OS deadline.
        main.postDelayed(terminate, LIFETIME_MS);
    }

    @Override public IBinder onBind(Intent intent) { return endpoint; }

    @Override public boolean onUnbind(Intent intent) {
        main.removeCallbacks(terminate);
        terminate.run();
        return false;
    }

    @Override public void onDestroy() {
        main.removeCallbacks(terminate);
        super.onDestroy();
        terminate.run();
    }
}
