// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

import android.app.Activity;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.File;
import java.lang.ref.WeakReference;

/** One controlled real Activity recreation while the local child stream is stalled. */
public final class LifecycleStreamActivity extends Activity {
    private static final Object LOCK=new Object();
    private static boolean started;
    private static volatile boolean firstDelta,recreateRequested,destroyObserved,networkAppeared;
    private static volatile String finalLine;
    private static volatile RealOfflineTurnSession session;
    private static volatile WeakReference<LifecycleStreamActivity> current=new WeakReference<>(null);
    private static ConnectivityManager connectivity;
    private static ConnectivityManager.NetworkCallback networkCallback;
    private TextView report;
    private boolean destroyed;

    @Override public void onCreate(Bundle saved){
        super.onCreate(saved);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setOnApplyWindowInsetsListener((v,insets)->{
            if(Build.VERSION.SDK_INT>=30){
                android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout());
                v.setPadding(bars.left,bars.top,bars.right,bars.bottom);
            }else v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),
                    insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());
            return insets;
        });
        Button run=new Button(this);run.setText("RUN REAL SCREEN RECREATION ONCE");
        synchronized(LOCK){run.setEnabled(!started);}
        report=new TextView(this);report.setTextIsSelectable(true);
        report.setText("1.42 offline lifecycle probe. With external Internet off, a synthetic callback gates a canned localhost stream. After the first delta, this real screen calls recreate(); its old onDestroy cancels the stalled child. No account or model request.\n");
        if(finalLine!=null)report.append(finalLine+"\n");
        else if(started)report.append("Recreated screen; waiting for child cleanup.\n");
        root.addView(run);ScrollView scroll=new ScrollView(this);scroll.addView(report);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);root.requestApplyInsets();
        current=new WeakReference<>(this);
        run.setOnClickListener(v->{
            synchronized(LOCK){if(started)return;started=true;}
            run.setEnabled(false);
            if(Build.VERSION.SDK_INT<29||!"arm64-v8a".equals(Build.SUPPORTED_ABIS[0])){
                finishReport("FAIL code=UNSUPPORTED_DEVICE");return;
            }
            connectivity=(ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);
            try{
                if(connectivity==null||validatedInternetPresent()){
                    finishReport("FAIL code=VALIDATED_INTERNET_PRESENT");return;
                }
                networkCallback=new ConnectivityManager.NetworkCallback(){
                    @Override public void onCapabilitiesChanged(Network network,NetworkCapabilities caps){
                        if(hasValidatedInternet(caps)){networkAppeared=true;
                            RealOfflineTurnSession active=session;if(active!=null)active.cancel();}
                    }
                };
                connectivity.registerNetworkCallback(new NetworkRequest.Builder().clearCapabilities()
                        .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).build(),networkCallback);
                if(validatedInternetPresent()){
                    networkAppeared=true;finishReport("FAIL code=VALIDATED_INTERNET_PRESENT");return;
                }
                OfflineAuthStreamGate.Result auth=OfflineAuthStreamGate.accept();
                if(!auth.accepted||!auth.replayRejected||!auth.closed)
                    throw new SecurityException("AUTH_GATE_INVALID");
            }catch(SecurityException e){finishReport("FAIL code=AUTH_GATE_INVALID");return;}
            catch(RuntimeException e){finishReport("FAIL code=OFFLINE_CHECK_UNAVAILABLE");return;}
            File appServer=new File(getApplicationInfo().nativeLibraryDir,"libcodex_app_server.so");
            File filesDir=getFilesDir();
            RealOfflineTurnSession active=new RealOfflineTurnSession(OfflineAppServerAdapter.SYSTEM,()->{
                firstDelta=true;
                runOnUiThread(()->{
                    LifecycleStreamActivity shown=current.get();
                    if(shown!=null&&!shown.destroyed&&!recreateRequested){
                        recreateRequested=true;
                        shown.report.append("FIRST_DELTA=1 recreating real Activity\n");
                        shown.recreate();
                    }
                });
            });
            session=active;
            new Thread(()->{
                String line;
                try{
                    active.run(filesDir,appServer,RealOfflineTurnSession.Mode.LIFECYCLE_DESTROY);
                    line="FAIL code=UNEXPECTED_STREAM_COMPLETION";
                }catch(RealOfflineTurnSession.GateException e){
                    if("CANCELLED".equals(e.code)&&firstDelta&&recreateRequested&&destroyObserved
                            &&!networkAppeared&&active.cleanupComplete()
                            &&active.observedRequests()==1&&active.observedDeltas()==1
                            &&!active.observedUtf8Split())
                        line="PASS lifecycle=REAL_RECREATE onDestroy=true childStopped=true localRequests=1 deltas=1 utf8Split=false authJson=ABSENT realAccount=NONE";
                    else line="FAIL stage="+active.stage()+" code="+e.code;
                }catch(RuntimeException e){line="FAIL code=LIFECYCLE_SESSION_STOPPED";}
                finally{session=null;}
                finishReport(line);
            },"real-lifecycle-parent").start();
        });
    }
    private static boolean validatedInternetPresent(){
        for(Network network:connectivity.getAllNetworks()){
            NetworkCapabilities caps=connectivity.getNetworkCapabilities(network);
            if(caps==null)throw new IllegalStateException("NETWORK_CAPABILITIES_UNAVAILABLE");
            if(hasValidatedInternet(caps))return true;
        }
        return false;
    }
    private static boolean hasValidatedInternet(NetworkCapabilities caps){
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                &&caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED);
    }
    private static void finishReport(String line){
        finalLine=line;
        ConnectivityManager cm=connectivity;ConnectivityManager.NetworkCallback cb=networkCallback;
        networkCallback=null;
        if(cm!=null&&cb!=null)try{cm.unregisterNetworkCallback(cb);}catch(RuntimeException ignored){}
        LifecycleStreamActivity shown=current.get();
        if(shown!=null)shown.runOnUiThread(()->{
            LifecycleStreamActivity latest=current.get();
            if(latest!=null&&!latest.destroyed)latest.report.append(line+"\n");
        });
    }
    @Override protected void onStop(){
        if(started&&!recreateRequested&&finalLine==null){
            RealOfflineTurnSession active=session;if(active!=null)active.cancel();
        }
        super.onStop();
    }
    @Override protected void onDestroy(){
        destroyed=true;
        if(recreateRequested&&firstDelta&&!destroyObserved){
            destroyObserved=true;
            RealOfflineTurnSession active=session;if(active!=null)active.cancel();
        }
        super.onDestroy();
    }
}
