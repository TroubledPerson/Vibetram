// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.File;

/** Offline native auth-configuration preflight only. No login request is sent. */
public final class OfflineManagedAuthActivity extends Activity {
    private OfflineManagedAuthSession session;
    private TextView report;
    private boolean attempted,destroyed;
    @Override public void onCreate(Bundle saved){
        super.onCreate(saved);
        attempted=saved!=null&&saved.getBoolean("attempted");
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setOnApplyWindowInsetsListener((v,insets)->{
            if(Build.VERSION.SDK_INT>=30){
                android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout());
                v.setPadding(bars.left,bars.top,bars.right,bars.bottom);
            }else{
                v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),
                        insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());
            }
            return insets;
        });
        Button run=new Button(this);run.setText("RUN OFFLINE AUTH PREFLIGHT ONCE");run.setEnabled(!attempted);
        report=new TextView(this);report.setTextIsSelectable(true);
        report.setText("1.20 offline managed-auth preflight\nChecks ephemeral credential setting and account/read only. No login or network request.\n");
        root.addView(run);ScrollView scroll=new ScrollView(this);scroll.addView(report);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);root.requestApplyInsets();
        run.setOnClickListener(v->{
            if(attempted)return;attempted=true;run.setEnabled(false);
            report.append("CASE=OFFLINE_AUTH_PREFLIGHT\n");
            if(Build.VERSION.SDK_INT<29||!"arm64-v8a".equals(Build.SUPPORTED_ABIS[0])){
                report.append("FAIL code=UNSUPPORTED_DEVICE\n");return;
            }
            session=new OfflineManagedAuthSession(OfflineAppServerAdapter.SYSTEM);
            File binary=new File(getApplicationInfo().nativeLibraryDir,"libcodex_app_server.so");
            new Thread(()->{
                String outcome;
                try{
                    OfflineManagedAuthSession.Outcome result=session.runOfflinePreflight(getFilesDir(),binary);
                    outcome=result==OfflineManagedAuthSession.Outcome.OFFLINE_PREFLIGHT
                            ?"PASS case=OFFLINE_AUTH_PREFLIGHT stage="+session.stage()+" notices="+session.noticeCount()+" credentials=EPHEMERAL authJson=ABSENT"
                            :"FAIL code=UNEXPECTED_RESULT";
                }catch(OfflineManagedAuthSession.GateException e){
                    outcome="FAIL case=OFFLINE_AUTH_PREFLIGHT stage="+session.stage()+" notices="+session.noticeCount()+" code="+e.code;
                }
                String line=outcome;
                runOnUiThread(()->{if(!destroyed)report.append(line+"\n");});
            },"offline-managed-auth-parent").start();
        });
    }
    @Override protected void onSaveInstanceState(Bundle out){out.putBoolean("attempted",attempted);super.onSaveInstanceState(out);}
    @Override protected void onDestroy(){destroyed=true;if(session!=null)session.cancel();super.onDestroy();}
}
