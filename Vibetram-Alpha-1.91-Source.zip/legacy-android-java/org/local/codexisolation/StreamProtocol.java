// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;
import java.util.Arrays;
import java.nio.charset.StandardCharsets;

/** Closed pull protocol: one credit per synchronous exchange; no provider fields. */
final class StreamProtocol {
    static final int CHUNK=16,MAX_FRAME=28,MAX_FRAMES=16,MAX_TOTAL=128;
    static final int CREATED=1,CHUNK_EVENT=2,DONE=3,COMPLETED=4,CANCELLED=5;
    static boolean magic(byte[] b,String magic){return b!=null&&b.length>=4&&b[0]==magic.charAt(0)&&b[1]==magic.charAt(1)&&b[2]==magic.charAt(2)&&b[3]==magic.charAt(3);}
    static int sequence(byte[] b){if(b==null||b.length<10)throw new SecurityException("Stream header");long n=0;for(int i=0;i<4;i++)n|=(long)(b[5+i]&255)<<(8*i);if(n>=MAX_FRAMES)throw new SecurityException("Stream sequence");return(int)n;}
    static byte[] pull(int id,int seq){byte[] b={'M','B','N','1',(byte)id,(byte)seq,0,0,0,0};if(id<1||id>2||seq<1||seq>=MAX_FRAMES)throw new SecurityException("Stream pull");return b;}
    static boolean cancel(byte[] b){return magic(b,"MBC1")&&b.length==10&&b[4]==0&&sequence(b)==0&&b[9]==0;}
    static byte[] payload(int id,byte[] reply){ModelPolicy.validateReply(id,reply);return id==1?"{\"path\":\"note.txt\"}".getBytes(StandardCharsets.US_ASCII):Arrays.copyOfRange(reply,6,92);}
    static int frameCount(byte[] payload){return 3+(payload.length+CHUNK-1)/CHUNK;}
    static byte[] frame(int id,int seq,byte[] payload){
        if(id<1||id>2||payload==null||payload.length<1||payload.length>MAX_TOTAL)throw new SecurityException("Stream payload");
        int chunks=(payload.length+CHUNK-1)/CHUNK,kind,length=0,offset=0;
        if(seq==0)kind=CREATED;else if(seq<=chunks){kind=CHUNK_EVENT;offset=(seq-1)*CHUNK;length=Math.min(CHUNK,payload.length-offset);}else if(seq==chunks+1)kind=DONE;else if(seq==chunks+2)kind=COMPLETED;else throw new SecurityException("Stream frame order");
        byte[] out=new byte[12+length];out[0]='M';out[1]='B';out[2]='E';out[3]='1';out[4]=(byte)id;out[5]=(byte)seq;out[9]=(byte)kind;out[10]=(byte)length;if(length>0)System.arraycopy(payload,offset,out,12,length);return out;
    }
    static int validate(byte[] b,int id,int seq){
        if(!magic(b,"MBE1")||b.length<12||b.length>MAX_FRAME||b[4]!=id||sequence(b)!=seq)throw new SecurityException("Stream frame identity");
        int kind=b[9]&255,n=(b[10]&255)|((b[11]&255)<<8);
        if(kind<CREATED||kind>COMPLETED||n>CHUNK||b.length!=12+n||(kind==CHUNK_EVENT?n==0:n!=0))throw new SecurityException("Stream frame shape");return kind;
    }
}
