// SPDX-License-Identifier: Apache-2.0
// Vibetram project source. See LICENSE and LICENSING.md.
package org.local.codexisolation;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/** One ephemeral sign-in and one in-memory thread with bounded explicit turns. */
final class ManagedChatSession {
    static final String APP_SERVER_SHA256="50d655fd709a44dabede21242f3c01aef2c9cf9c78b5fbfeecd1799555750c09";
    static final String VERIFY_URL="https://auth.openai.com/codex/device";
    static final int MAX_TURNS=12;
    private static final int MAX_FRAME=262144,MAX_FRAMES=1024,MAX_STDERR=131072,MAX_PREVIEW=4096;
    private static final String TRUNCATED="\n[Response preview truncated]";
    interface Events {
        void showCode(String code);
        void ready(int submittedTurns);
        void turnCompleted(String prompt,Result result);
        void turnStopped(String prompt,boolean started);
        void turnFailed(String prompt);
        default void approveTool(String title,String review,ToolGate decision){decision.resolve(false);}
        default void approvePanelAction(String title,String review,ToolGate decision){approveTool(title,review,decision);}
        default void toolNotice(String message){}
    }
    static final class ToolGate {
        private final CountDownLatch done=new CountDownLatch(1);
        private final AtomicBoolean decided=new AtomicBoolean();
        private volatile boolean approved;
        boolean resolve(boolean allow){if(!decided.compareAndSet(false,true))return false;approved=allow;done.countDown();return true;}
        boolean await() throws InterruptedException{return done.await(120,TimeUnit.SECONDS)&&approved;}
        boolean isOpen(){return !decided.get();}
    }
    static final class GateException extends Exception {
        final String code;
        GateException(String code){super(code);this.code=code;}
    }
    static final class Result {
        final String status,text;
        final int deltas;
        final String visualExpected;
        Result(String status,String text,int deltas){this(status,text,deltas,null);}
        Result(String status,String text,int deltas,String visualExpected){
            this.status=status;this.text=text;this.deltas=deltas;this.visualExpected=visualExpected;
        }
    }
    interface OwnPanelCapture { PanelImage capture(long token) throws Exception; }
    interface OwnPanelAction { boolean select(long revision,int row,int column,long token) throws Exception; }
    static final class PanelImage {
        final String dataUrl,expected;
        final long revision;
        PanelImage(String dataUrl,String expected,long revision){
            this.dataUrl=PngImageContent.requireDataUrl(dataUrl);
            if(expected==null||expected.length()>64)throw new IllegalArgumentException("OWN_PANEL_KEY_INVALID");
            if(revision<=0)throw new IllegalArgumentException("OWN_PANEL_REVISION_INVALID");
            this.expected=expected;this.revision=revision;
        }
    }
    private static final class PanelEvidence {
        final String thread,turn,imageCall;
        final long revision,gateToken;
        boolean used;
        PanelEvidence(String thread,String turn,String imageCall,long revision,long gateToken){
            this.thread=thread;this.turn=turn;this.imageCall=imageCall;
            this.revision=revision;this.gateToken=gateToken;
        }
    }
    static final class MissingImageProbe {
        final String guardResult;
        final int approvalRequests,actionAttempts;
        MissingImageProbe(String guardResult,int approvalRequests,int actionAttempts){
            this.guardResult=guardResult;this.approvalRequests=approvalRequests;this.actionAttempts=actionAttempts;
        }
    }
    private final OfflineAppServerAdapter.ProcessFactory factory;
    private final PhoneWorkspace workspace;
    private final SelectedFolderAccess folder;
    private final ScreenStatusGate screenStatusGate;
    private final OwnPanelCapture ownPanelCapture;
    private final OwnPanelAction ownPanelAction;
    private final AtomicBoolean started=new AtomicBoolean(),cancelled=new AtomicBoolean();
    private final AtomicBoolean inFlight=new AtomicBoolean(),stopRequested=new AtomicBoolean(),interruptIssued=new AtomicBoolean();
    private final AtomicInteger screenApprovalRequests=new AtomicInteger(),panelActionAttempts=new AtomicInteger();
    private final ArrayBlockingQueue<String> sendQueue=new ArrayBlockingQueue<>(1);
    private final AtomicInteger nextRequestId=new AtomicInteger(5),turnSequence=new AtomicInteger();
    private final Set<Integer> interruptRequestIds=ConcurrentHashMap.newKeySet();
    private final Set<String> retiredTurnIds=new HashSet<>();
    private final Set<String> seenToolCalls=new HashSet<>();
    private final PreItemDiagnostic preItemDiagnostic=new PreItemDiagnostic();
    private boolean preTurnDiagnosticObserved;
    private boolean staleDiagnosticObserved;
    private final ArrayList<DiagnosticWarning> pendingDiagnosticWarnings=new ArrayList<>();
    private final ArrayList<String> pendingModerationTurnIds=new ArrayList<>();
    private static final class DiagnosticWarning {
        final String turnId,message;
        DiagnosticWarning(String turnId,String message){this.turnId=turnId;this.message=message;}
    }
    private final Object writeLock=new Object();
    private volatile Process child;
    private volatile OutputStream writer;
    private volatile ToolGate pendingTool;
    private volatile ToolGate pendingScreenTool;
    private String visualExpected;
    private PanelEvidence panelEvidence;
    private volatile Events eventSink;
    private volatile String stage="NOT_STARTED";
    private volatile boolean turnTerminal;
    private volatile boolean authenticated;
    private volatile int turnStarts;
    private volatile int stderrBytes;
    private int frames,deltas;
    private boolean answerTruncated,itemAnswerTruncated;
    private String loginId,completedLoginId,loginFailureCode,agentItemId;
    private volatile String threadId,turnId;
    private boolean loginSuccess,loginCompleted;
    private final StringBuilder answer=new StringBuilder();
    private final StringBuilder itemAnswer=new StringBuilder();
    ManagedChatSession(OfflineAppServerAdapter.ProcessFactory factory){this(factory,null,null,new ScreenStatusGate());}
    ManagedChatSession(OfflineAppServerAdapter.ProcessFactory factory,PhoneWorkspace workspace){this(factory,workspace,null,new ScreenStatusGate());}
    ManagedChatSession(OfflineAppServerAdapter.ProcessFactory factory,PhoneWorkspace workspace,SelectedFolderAccess folder){
        this(factory,workspace,folder,new ScreenStatusGate());
    }
    ManagedChatSession(OfflineAppServerAdapter.ProcessFactory factory,PhoneWorkspace workspace,SelectedFolderAccess folder,ScreenStatusGate gate){
        this(factory,workspace,folder,gate,null);
    }
    ManagedChatSession(OfflineAppServerAdapter.ProcessFactory factory,PhoneWorkspace workspace,SelectedFolderAccess folder,
            ScreenStatusGate gate,OwnPanelCapture ownPanelCapture){
        this(factory,workspace,folder,gate,ownPanelCapture,null);
    }
    ManagedChatSession(OfflineAppServerAdapter.ProcessFactory factory,PhoneWorkspace workspace,SelectedFolderAccess folder,
            ScreenStatusGate gate,OwnPanelCapture ownPanelCapture,OwnPanelAction ownPanelAction){
        this.factory=factory;this.workspace=workspace;this.folder=folder;this.screenStatusGate=gate;
        this.ownPanelCapture=ownPanelCapture;this.ownPanelAction=ownPanelAction;
    }
    void revokeScreenStatus(){
        synchronized(screenStatusGate){
            screenStatusGate.stop();
            ToolGate pending=pendingScreenTool;if(pending!=null)pending.resolve(false);
        }
    }
    String stage(){return stage;}
    boolean authenticated(){return authenticated;}
    int turnStarts(){return turnStarts;}
    boolean requestSend(String text){
        if(ShortPromptBoundary.check(text)!=null||cancelled.get())return false;
        synchronized(writeLock){
            if(!"READY_FOR_SEND".equals(stage)||!inFlight.compareAndSet(false,true))return false;
            stopRequested.set(false);interruptIssued.set(false);turnTerminal=false;
            turnSequence.incrementAndGet();stage="TURN_QUEUED";
            if(sendQueue.offer(text))return true;
            inFlight.set(false);stage="READY_FOR_SEND";return false;
        }
    }
    /** Idle local check of the same image-evidence guard used by panel_select_cell. No tool frame or writer. */
    MissingImageProbe probeMissingPanelImage(){
        synchronized(writeLock){
            if(!authenticated||!"READY_FOR_SEND".equals(stage)||inFlight.get()||turnId!=null
                    ||cancelled.get()||stopRequested.get()||pendingTool!=null||pendingScreenTool!=null
                    ||panelEvidence!=null||!screenStatusGate.active())
                return new MissingImageProbe("LOCAL_PROBE_UNAVAILABLE",0,0);
            int approvalsBefore=screenApprovalRequests.get(),actionsBefore=panelActionAttempts.get();
            String result=panelActionPrecondition(screenStatusGate.token(),null);
            return new MissingImageProbe(result==null?"LOCAL_PROBE_GUARD_PASSED":result,
                    screenApprovalRequests.get()-approvalsBefore,panelActionAttempts.get()-actionsBefore);
        }
    }
    boolean requestStop(){
        if(!inFlight.get()||cancelled.get()||!stopRequested.compareAndSet(false,true))return false;
        revokeScreenStatus();
        ToolGate pending=pendingTool;if(pending!=null)pending.resolve(false);
        final int sequence=turnSequence.get();
        Thread interrupt=new Thread(()->{
            issueInterruptIfNeeded();
            try{Thread.sleep(12000);}catch(InterruptedException ignored){Thread.currentThread().interrupt();}
            if(turnSequence.get()==sequence&&inFlight.get()&&!turnTerminal)cancel();
        },"chat-stop-watchdog");interrupt.setDaemon(true);interrupt.start();
        return true;
    }
    void cancel(){cancelled.set(true);revokeScreenStatus();sendQueue.offer("");Process p=child;
        ToolGate pending=pendingTool;if(pending!=null)pending.resolve(false);
        if(p!=null)try{p.destroyForcibly();}catch(RuntimeException ignored){}
    }
    private void issueInterruptIfNeeded(){
        String currentThread=threadId,currentTurn=turnId;
        if(!stopRequested.get()||!inFlight.get()||turnTerminal||currentThread==null||currentTurn==null
                ||!interruptIssued.compareAndSet(false,true))return;
        int id=nextRequestId.getAndIncrement();interruptRequestIds.add(id);
        try{synchronized(writeLock){
            if(!turnTerminal&&writer!=null)send(writer,"{\"id\":"+id+",\"method\":\"turn/interrupt\",\"params\":{\"threadId\":"
                    +quote(currentThread)+",\"turnId\":"+quote(currentTurn)+"}}");
        }}catch(IOException e){cancel();}
    }
    private void finishTurn(){
        synchronized(writeLock){
            if(turnId!=null)retiredTurnIds.add(turnId);
            turnTerminal=true;inFlight.set(false);stopRequested.set(false);turnId=null;
            visualExpected=null;panelEvidence=null;
        }
    }
    void run(File filesDir,File binary,Events events) throws GateException {
        if(!started.compareAndSet(false,true))throw new GateException("ALREADY_RUN");
        eventSink=events;
        File home=null;Process p=null;ExecutorService readers=Executors.newFixedThreadPool(2);
        try{
            stage="HOME_CHECK";
            File privateDir=filesDir.getCanonicalFile();require(privateDir.isDirectory(),"PRIVATE_FILES_MISSING");
            home=new File(privateDir,"managed-chat-v50-"+UUID.randomUUID()).getCanonicalFile();
            require(privateDir.equals(home.getParentFile())&&!home.exists(),"HOME_BOUNDARY_INVALID");
            Files.createDirectory(home.toPath());
            require(binary.isFile()&&binary.canExecute()&&binary.length()==253508688,"APP_SERVER_UNAVAILABLE");
            MessageDigest digest=MessageDigest.getInstance("SHA-256");
            try(InputStream input=Files.newInputStream(binary.toPath())){
                byte[] b=new byte[65536];int n;while((n=input.read(b))!=-1)digest.update(b,0,n);
            }
            require(APP_SERVER_SHA256.equals(hex(digest.digest())),"APP_SERVER_MISMATCH");
            String config="model_provider = \"openai-bounded\"\napproval_policy = \"never\"\n"
                    +"sandbox_mode = \"read-only\"\ncli_auth_credentials_store = \"ephemeral\"\n"
                    +"web_search = \"disabled\"\n[history]\npersistence = \"none\"\n"
                    +"[analytics]\nenabled = false\n"
                    +"[features]\nplugins = false\napps = false\nmulti_agent = false\n"
                    +"goals = false\nshell_tool = false\n"
                    +"[features.code_mode]\nenabled = false\ndirect_only_tool_namespaces = [\"functions\"]\n"
                    +"[tools.experimental_request_user_input]\nenabled = false\n"
                    +"[tools.update_plan]\nenabled = false\n"
                    +"[agents]\nenabled = false\n[orchestrator.skills]\nenabled = false\n"
                    +"[model_providers.openai-bounded]\nname = \"OpenAI\"\nwire_api = \"responses\"\n"
                    +"requires_openai_auth = true\nrequest_max_retries = 0\nstream_max_retries = 0\n"
                    +"supports_websockets = false\nsupports_standalone_web_search = false\n";
            Files.write(home.toPath().resolve("config.toml"),config.getBytes(StandardCharsets.UTF_8));
            Map<String,String> env=new HashMap<>();env.put("PATH","/system/bin");
            env.put("HOME",home.getPath());env.put("CODEX_HOME",home.getPath());
            stage="PROCESS_START";
            p=factory.start(Arrays.asList(binary.getAbsolutePath(),"--listen","stdio://",
                    "-c","cli_auth_credentials_store=\"ephemeral\"",
                    "-c","features.plugins=false","-c","features.remote_plugin=false",
                    "--disable-plugin-startup-tasks-for-tests"),env);
            child=p;final Process running=p;
            readers.submit(()->{byte[] b=new byte[512];int n;
                try{while((n=running.getErrorStream().read(b))!=-1){stderrBytes+=n;
                    if(stderrBytes>MAX_STDERR){cancel();break;}}}catch(IOException ignored){} });
            InputStream in=p.getInputStream();OutputStream out=p.getOutputStream();writer=out;
            stage="INITIALIZE";long deadline=afterSeconds(30);
            send(out,"{\"id\":1,\"method\":\"initialize\",\"params\":{\"clientInfo\":{\"name\":\"coretest_chat\",\"title\":\"Core Test Chat\",\"version\":\"0.1\"},\"capabilities\":{\"experimentalApi\":true}}}");
            Map<?,?> init=obj(reply(in,readers,deadline,1).get("result"),"INIT_INVALID");
            require("android".equals(init.get("platformOs"))&&home.getPath().equals(init.get("codexHome")),"INIT_BOUNDARY_INVALID");
            send(out,"{\"method\":\"initialized\"}");
            stage="ACCOUNT_EMPTY";
            send(out,"{\"id\":2,\"method\":\"account/read\",\"params\":{\"refreshToken\":false}}");
            Map<?,?> empty=obj(reply(in,readers,deadline,2).get("result"),"ACCOUNT_INVALID");
            require(empty.containsKey("account")&&empty.get("account")==null,"ACCOUNT_NOT_EMPTY");
            stage="DEVICE_CODE";deadline=afterSeconds(30);
            send(out,"{\"id\":3,\"method\":\"account/login/start\",\"params\":{\"type\":\"chatgptDeviceCode\"}}");
            Map<?,?> login=obj(reply(in,readers,deadline,3).get("result"),"DEVICE_CODE_UNAVAILABLE");
            require("chatgptDeviceCode".equals(login.get("type"))&&VERIFY_URL.equals(login.get("verificationUrl")),"DEVICE_CODE_INVALID");
            loginId=string(login.get("loginId"),"LOGIN_ID_INVALID");
            try{UUID.fromString(loginId);}catch(IllegalArgumentException e){throw new GateException("LOGIN_ID_INVALID");}
            String code=string(login.get("userCode"),"USER_CODE_INVALID");
            require(code.matches("[A-Z0-9-]{4,24}"),"USER_CODE_INVALID");
            events.showCode(code);
            stage="WAIT_FOR_USER";deadline=afterSeconds(15*60);
            while(!loginCompleted)notification(frame(in,readers,deadline));
            require(loginId.equals(completedLoginId),"LOGIN_ID_MISMATCH");
            require(loginSuccess,loginFailureCode==null?"LOGIN_NOT_COMPLETED":loginFailureCode);
            stage="ACCOUNT_CONFIRM";deadline=afterSeconds(20);
            send(out,"{\"id\":4,\"method\":\"account/read\",\"params\":{\"refreshToken\":false}}");
            Map<?,?> account=obj(reply(in,readers,deadline,4).get("result"),"ACCOUNT_INVALID");
            require("chatgpt".equals(obj(account.get("account"),"ACCOUNT_INVALID").get("type")),"ACCOUNT_NOT_CHATGPT");
            authenticated=true;
            for(int submittedTurns=0;submittedTurns<MAX_TURNS&&!cancelled.get();){
                stage="READY_FOR_SEND";events.ready(submittedTurns);
                String requestText=sendQueue.poll(10,TimeUnit.MINUTES);
                require(requestText!=null,"SESSION_IDLE_CLOSED");
                require(!cancelled.get(),"CANCELLED");
                require(ShortPromptBoundary.check(requestText)==null,"PROMPT_INVALID");
                if(stopRequested.get()){
                    finishTurn();events.turnStopped(requestText,false);continue;
                }
                if(threadId==null){
                    stage="THREAD_START";deadline=afterSeconds(30);
                    int threadRequest=nextRequestId.getAndIncrement();
                    send(out,"{\"id\":"+threadRequest+",\"method\":\"thread/start\",\"params\":{\"cwd\":"+quote(workspace==null?home.getPath():workspace.root().toString())
                            +",\"approvalPolicy\":\"never\",\"sandbox\":\"read-only\",\"ephemeral\":true,\"environments\":[],"
                            +(workspace==null?"":"\"dynamicTools\":["
                                    +"{\"type\":\"function\",\"name\":\"project_read_file\",\"description\":\"Read exactly README.md or project.json from the selected phone project.\",\"inputSchema\":{\"type\":\"object\",\"properties\":{\"path\":{\"type\":\"string\",\"enum\":[\"README.md\",\"project.json\"]}},\"required\":[\"path\"],\"additionalProperties\":false}},"
                                    +"{\"type\":\"function\",\"name\":\"project_propose_edit\",\"description\":\"Propose complete replacement of README.md or project.json; the user reviews and approves before any write.\",\"inputSchema\":{\"type\":\"object\",\"properties\":{\"path\":{\"type\":\"string\",\"enum\":[\"README.md\",\"project.json\"]},\"expectedSha256\":{\"type\":\"string\"},\"replacement\":{\"type\":\"string\"}},\"required\":[\"path\",\"expectedSha256\",\"replacement\"],\"additionalProperties\":false}},"
                                     +"{\"type\":\"function\",\"name\":\"project_run_check\",\"description\":\"Request user approval to run the fixed project.json validity check; no shell.\",\"inputSchema\":{\"type\":\"object\",\"properties\":{},\"additionalProperties\":false}}"
                                     +",{\"type\":\"function\",\"name\":\"screen_status\",\"description\":\"Return only fixed local screen capability status after the user enables the foreground session and approves this call. No capture or tap.\",\"inputSchema\":{\"type\":\"object\",\"properties\":{},\"additionalProperties\":false}}"
                                     +",{\"type\":\"function\",\"name\":\"synthetic_image\",\"description\":\"Return only a bundled 1x1 PNG test image after the user enables the foreground session and approves this call. No screen capture.\",\"inputSchema\":{\"type\":\"object\",\"properties\":{},\"additionalProperties\":false}}"
                                     +",{\"type\":\"function\",\"name\":\"visual_pattern\",\"description\":\"Return a synthetic visual pattern after user approval. Describe what is visible in the image. No screen capture.\",\"inputSchema\":{\"type\":\"object\",\"properties\":{},\"additionalProperties\":false}}"
                                     +",{\"type\":\"function\",\"name\":\"own_panel_image\",\"description\":\"After approval, return one image rendered from this app's dedicated visible marker View only. No window, system UI, or other app capture.\",\"inputSchema\":{\"type\":\"object\",\"properties\":{},\"additionalProperties\":false}}"
                                      +",{\"type\":\"function\",\"name\":\"panel_select_cell\",\"description\":\"After a separately approved own_panel_image in this turn, propose one app-local test-panel cell selection requiring separate user approval. This does not send a touch event.\",\"inputSchema\":{\"type\":\"object\",\"properties\":{\"row\":{\"type\":\"string\",\"enum\":[\"top\",\"middle\",\"bottom\"]},\"column\":{\"type\":\"string\",\"enum\":[\"left\",\"center\",\"right\"]}},\"required\":[\"row\",\"column\"],\"additionalProperties\":false}}"
                                     +(folder==null?"":",{\"type\":\"function\",\"name\":\"folder_list_files\",\"description\":\"List up to 64 immediate text file names in the user-picked folder. No subfolders.\",\"inputSchema\":{\"type\":\"object\",\"properties\":{},\"additionalProperties\":false}}"
                                             +",{\"type\":\"function\",\"name\":\"folder_read_file\",\"description\":\"Read one named immediate .txt, .md, or .json file, at most 4096 bytes, from the user-picked folder.\",\"inputSchema\":{\"type\":\"object\",\"properties\":{\"name\":{\"type\":\"string\"}},\"required\":[\"name\"],\"additionalProperties\":false}}"
                                             +",{\"type\":\"function\",\"name\":\"folder_propose_edit\",\"description\":\"Propose an exact replacement of one previously read named file in the user-picked folder; requires user review and approval before writing.\",\"inputSchema\":{\"type\":\"object\",\"properties\":{\"name\":{\"type\":\"string\"},\"expectedSha256\":{\"type\":\"string\"},\"replacement\":{\"type\":\"string\"}},\"required\":[\"name\",\"expectedSha256\",\"replacement\"],\"additionalProperties\":false}}")+"],")
                            +"\"developerInstructions\":\"Reply concisely. "
                             +(workspace==null?"No tools or file access.":"The built-in phone project contains exactly README.md and project.json. Use its named project tools with those exact paths. "
                                     +(folder==null?"No external folder is selected.":"A separate user-picked folder is available only through folder_list_files, folder_read_file, and folder_propose_edit. Only immediate named text files; never infer or use device paths or subfolders. ")
                                     +"Read before proposing edits. screen_status, synthetic_image, visual_pattern, and own_panel_image require a visible user-enabled session and per-call approval. own_panel_image renders only this app's dedicated marker View, not the window or other apps. panel_select_cell requires that approved image in the same turn plus a separate approval; it only changes this app's disposable marker panel, never dispatches a touch event. Never assume approval. No shell or other file access.")
                            +"\"}}");
                    Map<?,?> thread=obj(reply(in,readers,deadline,threadRequest).get("result"),"THREAD_INVALID");
                    threadId=string(obj(thread.get("thread"),"THREAD_INVALID").get("id"),"THREAD_INVALID");
                    require(threadId.length()<=64,"THREAD_INVALID");
                }
                if(stopRequested.get()){
                    finishTurn();events.turnStopped(requestText,false);continue;
                }
                stage="TURN_START";deadline=afterSeconds(workspace==null?60:180);frames=0;deltas=0;
                preTurnDiagnosticObserved=false;
                staleDiagnosticObserved=false;pendingDiagnosticWarnings.clear();pendingModerationTurnIds.clear();
                answer.setLength(0);answerTruncated=false;itemAnswer.setLength(0);
                itemAnswerTruncated=false;agentItemId=null;turnId=null;turnTerminal=false;
                int turnRequest=nextRequestId.getAndIncrement();
                send(out,"{\"id\":"+turnRequest+",\"method\":\"turn/start\",\"params\":{\"threadId\":"+quote(threadId)
                        +",\"input\":[{\"type\":\"text\",\"text\":"+quote(requestText)+",\"textElements\":[]}]}}");
                submittedTurns++;turnStarts=submittedTurns;
                Map<?,?> turn=obj(reply(in,readers,deadline,turnRequest).get("result"),"TURN_INVALID");
                turnId=string(obj(turn.get("turn"),"TURN_INVALID").get("id"),"TURN_INVALID");
                require(turnId.length()<=64,"TURN_INVALID");
                validatePendingModeration();
                // A warning queued after the prior turn can arrive while waiting for
                // this reply. Start the diagnostic window only after the new turn ID.
                preItemDiagnostic.reset();
                for(DiagnosticWarning warning:pendingDiagnosticWarnings){
                    if(turnId.equals(warning.turnId)){
                        preItemDiagnostic.observe(warning.message);preTurnDiagnosticObserved=true;
                    }else staleDiagnosticObserved=true;
                }
                pendingDiagnosticWarnings.clear();
                if(stopRequested.get())issueInterruptIfNeeded();
                stage="STREAM";String status=null;
                for(int i=0;i<MAX_FRAMES&&status==null;i++)status=notification(frame(in,readers,deadline));
                turnTerminal=true;
                if(workspace!=null)events.toolNotice(preItemDiagnostic.summary()
                        +(preTurnDiagnosticObserved?" early-warning=yes":"")
                        +(staleDiagnosticObserved?" stale-warning=yes":""));
                if("completed".equals(status)){
                    require(answer.length()>0&&stderrBytes<=MAX_STDERR,"ANSWER_INVALID");
                    Result result=new Result(status,answer.toString()+(answerTruncated?TRUNCATED:""),deltas,visualExpected);
                    finishTurn();events.turnCompleted(requestText,result);
                }else if("interrupted".equals(status)&&stopRequested.get()){
                    finishTurn();events.turnStopped(requestText,true);
                }else if("failed".equals(status)){
                    finishTurn();events.turnFailed(requestText);
                }else throw new GateException("TURN_NOT_COMPLETED_SESSION_CLOSED");
            }
            stage=cancelled.get()?"CANCELLED":"TURN_LIMIT_REACHED";
        }catch(GateException e){throw e;}
        catch(Exception e){throw new GateException(cancelled.get()?"CANCELLED":"SESSION_STOPPED");}
        finally{
            writer=null;eventSink=null;sendQueue.clear();inFlight.set(false);turnTerminal=true;
            if(p!=null){p.destroyForcibly();try{if(!p.waitFor(2,TimeUnit.SECONDS)||p.isAlive())throw new GateException("CHILD_STILL_RUNNING");}
                catch(InterruptedException e){Thread.currentThread().interrupt();throw new GateException("CHILD_STILL_RUNNING");}}
            child=null;readers.shutdownNow();
            if(home!=null&&new File(home,"auth.json").exists()){
                try{Files.deleteIfExists(new File(home,"auth.json").toPath());}catch(IOException ignored){}
                throw new GateException("CREDENTIAL_FILE_CREATED");
            }
        }
    }
    private Map<?,?> reply(InputStream in,ExecutorService readers,long deadline,int id) throws Exception{
        for(int i=0;i<MAX_FRAMES;i++){
            Map<?,?> frame=frame(in,readers,deadline);
            if(frame.containsKey("id")){
                if(isToolRequest(frame)){handleToolRequest(frame);continue;}
                if(isInterruptReply(frame))continue;
                require(BigDecimal.valueOf(id).equals(frame.get("id"))&&!frame.containsKey("error"),"RPC_REJECTED");
                return frame;
            }
            require(notification(frame)==null,"PREMATURE_COMPLETION");
        }
        throw new GateException("REPLY_MISSING");
    }
    private String notification(Map<?,?> frame) throws GateException{
        if(frame.containsKey("id")){
            if(isToolRequest(frame)){handleToolRequest(frame);return null;}
            require(isInterruptReply(frame),"UNREQUESTED_SERVER_CALL");return null;
        }
        String method=string(frame.get("method"),"METHOD_INVALID");
        Map<?,?> params=obj(frame.get("params"),"NOTIFICATION_INVALID");
        if(isRetiredTurnEvent(method,params))return null;
        if("account/login/completed".equals(method)){
            completedLoginId=string(params.get("loginId"),"LOGIN_ID_INVALID");
            loginSuccess=Boolean.TRUE.equals(params.get("success"));
            if(!loginSuccess)loginFailureCode=completionFailureCode(params.get("error"));
            loginCompleted=true;return null;
        }
        if("item/started".equals(method)||"item/completed".equals(method)){
            require(threadId!=null&&turnId!=null&&threadId.equals(params.get("threadId"))
                    &&turnId.equals(params.get("turnId")),"ITEM_IDS_INVALID");
            Map<?,?> item=obj(params.get("item"),"ITEM_INVALID");
            String type=string(item.get("type"),"ITEM_INVALID");
            require("userMessage".equals(type)||"agentMessage".equals(type)||"reasoning".equals(type)
                    ||(workspace!=null&&"dynamicToolCall".equals(type)),"TOOL_ITEM_REJECTED");
            if("dynamicToolCall".equals(type)){
                if("item/started".equals(method))preItemDiagnostic.itemReceived();
                Events sink=eventSink;
                if(sink!=null){
                    if("item/started".equals(method))sink.toolNotice("app-server tool item started");
                    else{
                        Object status=item.get("status");
                        sink.toolNotice("failed".equals(status)?"app-server tool item failed"
                                :"app-server tool item completed");
                    }
                }
            }
            if("agentMessage".equals(type)){
                String id=string(item.get("id"),"ITEM_ID_INVALID");require(id.length()<=64,"ITEM_ID_INVALID");
                if("item/started".equals(method)){
                    commitAgentItem();
                    agentItemId=id;
                }
                else{require(id.equals(agentItemId),"ITEM_ID_INVALID");
                    Object text=item.get("text");if(text instanceof String){
                        String complete=(String)text;
                        if(itemAnswer.length()==0)appendItemPreview(complete);
                        else require(complete.startsWith(itemAnswer.toString())
                                &&(itemAnswerTruncated||complete.equals(itemAnswer.toString())),"ANSWER_MISMATCH");
                    }
                    commitAgentItem();}
            }
            return null;
        }
        if("item/agentMessage/delta".equals(method)){
            require(threadId!=null&&turnId!=null&&threadId.equals(params.get("threadId"))
                    &&turnId.equals(params.get("turnId"))&&agentItemId!=null
                    &&agentItemId.equals(params.get("itemId")),"DELTA_IDS_INVALID");
            String delta=string(params.get("delta"),"DELTA_INVALID");
            deltas++;
            appendItemPreview(delta);return null;
        }
        if("turn/completed".equals(method)){
            require(threadId!=null&&threadId.equals(params.get("threadId")),"COMPLETION_ID_INVALID");
            Map<?,?> turn=obj(params.get("turn"),"COMPLETION_INVALID");
            require(turnId!=null&&turnId.equals(turn.get("id")),"COMPLETION_ID_INVALID");
            commitAgentItem();
            turnTerminal=true;
            return string(turn.get("status"),"COMPLETION_INVALID");
        }
        if("warning".equals(method)){
            Object message=params.get("message");
            if(workspace!=null&&inFlight.get()&&threadId!=null&&threadId.equals(params.get("threadId"))
                    &&message instanceof String&&PreItemDiagnostic.isMarker((String)message)){
                Object warningTurnId=params.get("turnId");
                if(!(warningTurnId instanceof String)||((String)warningTurnId).length()>64)return null;
                if(turnId==null){
                    if(pendingDiagnosticWarnings.size()<32)pendingDiagnosticWarnings.add(
                            new DiagnosticWarning((String)warningTurnId,(String)message));
                }else if(turnId.equals(warningTurnId))preItemDiagnostic.observe((String)message);
                else staleDiagnosticObserved=true;
            }
            return null;
        }
        if("turn/moderationMetadata".equals(method)){
            require(inFlight.get()&&threadId!=null&&threadId.equals(params.get("threadId")),"MODERATION_IDS_INVALID");
            String moderationTurnId=string(params.get("turnId"),"MODERATION_IDS_INVALID");
            require(!moderationTurnId.isEmpty()&&moderationTurnId.length()<=64,"MODERATION_IDS_INVALID");
            obj(params.get("metadata"),"MODERATION_METADATA_INVALID");
            if(turnId==null){
                require(pendingModerationTurnIds.size()<32,"MODERATION_EVENTS_LIMIT");
                pendingModerationTurnIds.add(moderationTurnId);
            }else require(turnId.equals(moderationTurnId),"MODERATION_IDS_INVALID");
            return null;
        }
        boolean allowed="remoteControl/status/changed".equals(method)||"account/updated".equals(method)
                ||"thread/started".equals(method)||"warning".equals(method)||"configWarning".equals(method)
                ||"thread/status/changed".equals(method)||"turn/started".equals(method)
                ||"thread/tokenUsage/updated".equals(method)||"account/rateLimits/updated".equals(method)
                ||method.startsWith("item/reasoning/");
        if(!allowed)throw new GateException(UnexpectedNotice.code(method));
        return null;
    }
    private boolean isInterruptReply(Map<?,?> frame){
        Object id=frame.get("id");
        if(!(id instanceof BigDecimal))return false;
        try{return interruptRequestIds.contains(((BigDecimal)id).intValueExact());}
        catch(ArithmeticException ignored){return false;}
    }
    private boolean isToolRequest(Map<?,?> frame){
        return workspace!=null&&"item/tool/call".equals(frame.get("method"))&&frame.containsKey("id");
    }
    private void handleToolRequest(Map<?,?> frame) throws GateException {
        require(workspace!=null&&turnId!=null&&inFlight.get()&&!cancelled.get(),"TOOL_OUTSIDE_TURN");
        Map<?,?> params=obj(frame.get("params"),"TOOL_PARAMS_INVALID");
        require(threadId.equals(params.get("threadId"))&&turnId.equals(params.get("turnId"))
                &&params.get("namespace")==null,"TOOL_BOUNDARY_INVALID");
        String callId=string(params.get("callId"),"TOOL_CALL_ID_INVALID");
        require(callId.length()>0&&callId.length()<=64&&seenToolCalls.add(callId),"TOOL_REPLAY");
        String name=string(params.get("tool"),"TOOL_NAME_INVALID");
        Map<?,?> args=obj(params.get("arguments"),"TOOL_ARGUMENTS_INVALID");
        require("screen_status".equals(name)||"synthetic_image".equals(name)||"visual_pattern".equals(name)
                ||"own_panel_image".equals(name)||"panel_select_cell".equals(name)
                ||"project_read_file".equals(name)||"project_propose_edit".equals(name)
                ||"project_run_check".equals(name)||(folder!=null&&("folder_list_files".equals(name)
                ||"folder_read_file".equals(name)||"folder_propose_edit".equals(name))),"UNKNOWN_TOOL");
        preItemDiagnostic.callbackReceived();
        Events startedSink=eventSink;if(startedSink!=null)startedSink.toolNotice(name+" requested");
        Object rawId=frame.get("id");String responseId;
        if(rawId instanceof BigDecimal)responseId=((BigDecimal)rawId).toPlainString();
        else if(rawId instanceof String&&((String)rawId).length()<=64)responseId=quote((String)rawId);
        else throw new GateException("TOOL_REQUEST_ID_INVALID");
        String output="TOOL_REJECTED";String imageDataUrl=null;String localVisualExpected=null;
        long capturedPanelRevision=-1;
        boolean success=false;long screenToken=-1;
        try{
            if("screen_status".equals(name)){
                require(args.isEmpty(),"TOOL_ARGUMENTS_INVALID");
                screenToken=screenStatusGate.token();
                if(screenToken<0)output="SCREEN_STATUS_DISABLED";
                else if(!approvedScreenStatus("Share local screen capability status?",
                        "Only reports this foreground status session is active. Capture and tap are not integrated. No screen content or personal data.",screenToken))
                    output="SCREEN_STATUS_NOT_APPROVED";
                else if(screenStatusGate.valid(screenToken)){
                    output=ScreenStatusGate.fixedResult();success=true;
                }else output="SCREEN_STATUS_REVOKED";
            }else if("synthetic_image".equals(name)){
                require(args.isEmpty(),"TOOL_ARGUMENTS_INVALID");
                screenToken=screenStatusGate.token();
                if(screenToken<0)output="SCREEN_STATUS_DISABLED";
                else if(!approvedScreenStatus("Share a synthetic test image?",
                        "Shares only a bundled 1x1 PNG. No screen content is captured or shared.",screenToken))
                    output="SYNTHETIC_IMAGE_NOT_APPROVED";
                else if(screenStatusGate.valid(screenToken)){
                    imageDataUrl=PngImageContent.fixedDataUrl();
                    output="SYNTHETIC_IMAGE_1X1";success=true;
                }else output="SCREEN_STATUS_REVOKED";
            }else if("visual_pattern".equals(name)){
                require(args.isEmpty(),"TOOL_ARGUMENTS_INVALID");
                screenToken=screenStatusGate.token();
                if(screenToken<0)output="SCREEN_STATUS_DISABLED";
                else if(!approvedScreenStatus("Share a synthetic visual pattern?",
                        "Shares only generated colored shapes. No screen content is captured or shared.",screenToken))
                    output="VISUAL_PATTERN_NOT_APPROVED";
                else if(screenStatusGate.valid(screenToken)){
                    VisualPattern.Challenge challenge=VisualPattern.fresh();
                    imageDataUrl=challenge.dataUrl;localVisualExpected=challenge.expected;
                    output="VISUAL_PATTERN_READY";success=true;
                }else output="SCREEN_STATUS_REVOKED";
            }else if("own_panel_image".equals(name)){
                require(args.isEmpty(),"TOOL_ARGUMENTS_INVALID");
                screenToken=screenStatusGate.token();
                if(screenToken<0)output="SCREEN_STATUS_DISABLED";
                else if(!approvedScreenStatus("Share this app's marker panel image?",
                        "Shares one image of only the dedicated visible marker panel. No chat, account, system UI, or other app content.",screenToken))
                    output="OWN_PANEL_NOT_APPROVED";
                else if(visualExpected!=null)output="VISUAL_PATTERN_ALREADY_SENT";
                else if(ownPanelCapture==null)output="OWN_PANEL_UNAVAILABLE";
                else if(screenStatusGate.valid(screenToken)){
                    PanelImage capture=ownPanelCapture.capture(screenToken);
                    imageDataUrl=capture.dataUrl;localVisualExpected=capture.expected;
                    capturedPanelRevision=capture.revision;
                    output="OWN_PANEL_IMAGE_READY";success=true;
                }else output="SCREEN_STATUS_REVOKED";
            }else if("panel_select_cell".equals(name)){
                require(args.size()==2&&args.containsKey("row")&&args.containsKey("column"),"TOOL_ARGUMENTS_INVALID");
                String row=string(args.get("row"),"TOOL_ARGUMENTS_INVALID");
                String column=string(args.get("column"),"TOOL_ARGUMENTS_INVALID");
                int rowIndex=Arrays.asList("top","middle","bottom").indexOf(row);
                int columnIndex=Arrays.asList("left","center","right").indexOf(column);
                require(rowIndex>=0&&columnIndex>=0,"TOOL_ARGUMENTS_INVALID");
                screenToken=screenStatusGate.token();
                PanelEvidence evidence=panelEvidence;
                String guard=panelActionPrecondition(screenToken,callId);
                if(guard!=null)output=guard;
                else if(!approvedScreenStatus("Select "+row+"-"+column+" cell on this app's test panel?",
                        "Only outlines the exact "+row+"-"+column+" cell in the disposable marker panel. No Android touch event or other app control.",screenToken,true))
                    output="PANEL_ACTION_NOT_APPROVED";
                else if(!screenStatusGate.valid(evidence.gateToken))output="SCREEN_STATUS_REVOKED";
                else{
                    evidence.used=true; // consume before the one allowed mutation attempt
                    panelActionAttempts.incrementAndGet();
                    boolean applied=ownPanelAction.select(evidence.revision,rowIndex,columnIndex,screenToken);
                    output=applied?"PANEL_CELL_SELECTED row="+row+" column="+column:"PANEL_REVISION_STALE";
                    success=applied;
                }
            }else if("project_read_file".equals(name)){
                require(args.size()==1,"TOOL_ARGUMENTS_INVALID");
                String path=string(args.get("path"),"TOOL_PATH_INVALID");
                PhoneWorkspace.Snapshot read=workspace.read(path);
                output="path="+path+" sha256="+read.sha256+"\n"+read.text;success=true;
            }else if("project_propose_edit".equals(name)){
                require(args.size()==3,"TOOL_ARGUMENTS_INVALID");
                PhoneWorkspace.Proposal proposal=workspace.propose(
                        string(args.get("path"),"TOOL_PATH_INVALID"),
                        string(args.get("expectedSha256"),"TOOL_HASH_INVALID"),
                        string(args.get("replacement"),"TOOL_TEXT_INVALID"));
                if(approved("Approve edit to "+proposal.name+"?",proposal.diff)){
                    String hash=workspace.apply(proposal);output="EDIT_APPLIED sha256="+hash;success=true;
                }else output="EDIT_NOT_APPROVED";
            }else if("project_run_check".equals(name)){
                require(args.isEmpty(),"TOOL_ARGUMENTS_INVALID");
                if(approved("Run fixed project.json check?","Reads project.json and validates name and tasks. No shell or network.")){
                    output=workspace.check();success=output.startsWith("PASS:");
                }else output="CHECK_NOT_APPROVED";
            }else if("folder_list_files".equals(name)){
                require(args.isEmpty(),"TOOL_ARGUMENTS_INVALID");
                output=folder.list();success=true;
            }else if("folder_read_file".equals(name)){
                require(args.size()==1,"TOOL_ARGUMENTS_INVALID");
                String fileName=string(args.get("name"),"TOOL_NAME_INVALID");
                PhoneWorkspace.Snapshot read=folder.read(fileName);
                output="name="+fileName+" sha256="+read.sha256+"\n"+read.text;success=true;
            }else if("folder_propose_edit".equals(name)){
                require(args.size()==3,"TOOL_ARGUMENTS_INVALID");
                SelectedFolderAccess.Proposal proposal=folder.propose(
                        string(args.get("name"),"TOOL_NAME_INVALID"),
                        string(args.get("expectedSha256"),"TOOL_HASH_INVALID"),
                        string(args.get("replacement"),"TOOL_TEXT_INVALID"));
                if(approved("Approve selected-folder edit to "+proposal.name+"?",proposal.diff)){
                    String hash=folder.apply(proposal);output="EDIT_APPLIED sha256="+hash;success=true;
                }else output="EDIT_NOT_APPROVED";
            }else throw new GateException("UNKNOWN_TOOL");
        }catch(GateException e){throw e;}
        catch(Exception e){output=safeToolFailure(e);success=false;}
        if("screen_status".equals(name)||"synthetic_image".equals(name)
                ||"visual_pattern".equals(name)||"own_panel_image".equals(name)
                ||"panel_select_cell".equals(name)){
            synchronized(screenStatusGate){
                if(stopRequested.get()||cancelled.get()){output="TURN_STOPPED";success=false;}
                if(screenToken>=0&&!screenStatusGate.valid(screenToken)){
                    output="SCREEN_STATUS_REVOKED";success=false;
                }
                if(("visual_pattern".equals(name)||"own_panel_image".equals(name))&&success&&visualExpected!=null){
                    output="VISUAL_PATTERN_ALREADY_SENT";success=false;
                }
                sendToolReply(responseId,output,success,success?imageDataUrl:null);
                if(success&&localVisualExpected!=null)visualExpected=localVisualExpected;
                if(success&&"own_panel_image".equals(name))
                    panelEvidence=new PanelEvidence(threadId,turnId,callId,capturedPanelRevision,screenToken);
            }
        }else{
            if(stopRequested.get()||cancelled.get()){output="TURN_STOPPED";success=false;}
            sendToolReply(responseId,output,success);
        }
        Events sink=eventSink;if(sink!=null)sink.toolNotice(name+" "+(success?"OK":output));
    }
    private void sendToolReply(String responseId,String output,boolean success) throws GateException {
        sendToolReply(responseId,output,success,null);
    }
    private void sendToolReply(String responseId,String output,boolean success,String imageDataUrl) throws GateException {
        String result="{\"id\":"+responseId+",\"result\":{\"contentItems\":[{\"type\":\"inputText\",\"text\":"+quote(output)
                +"}"+(success&&imageDataUrl!=null?",{\"type\":\"inputImage\",\"imageUrl\":"+quote(imageDataUrl)+"}":"")
                +"],\"success\":"+success+"}}";
        try{synchronized(writeLock){require(writer!=null,"TOOL_WRITER_CLOSED");send(writer,result);}}
        catch(IOException e){throw new GateException("TOOL_REPLY_FAILED");}
    }
    private static String safeToolFailure(Exception error){
        String code=error.getMessage();
        if("PATH_NOT_ALLOWED".equals(code))return "PATH_NOT_ALLOWED: use README.md or project.json";
        if("STALE_FILE".equals(code))return "STALE_FILE: read again before proposing an edit";
        if("REPLACEMENT_TOO_LARGE".equals(code))return "REPLACEMENT_TOO_LARGE";
        if("UNICODE_INVALID".equals(code)||"TEXT_INVALID".equals(code))return "INVALID_REPLACEMENT_TEXT";
        if("FOLDER_DISCONNECTED".equals(code))return "FOLDER_DISCONNECTED";
        if("NAME_NOT_ALLOWED".equals(code)||"TYPE_NOT_ALLOWED".equals(code))return "FOLDER_NAME_NOT_ALLOWED";
        if("TOO_MANY_CHILDREN".equals(code))return "FOLDER_TOO_MANY_CHILDREN";
        if("FILE_TOO_LARGE".equals(code)||"INVALID_UTF8".equals(code))return "FOLDER_FILE_NOT_TEXT_WITHIN_LIMIT";
        if("FOLDER_READ_ONLY".equals(code))return "FOLDER_READ_ONLY";
        if("WRITE_UNCERTAIN_INSPECT_FILE".equals(code))return "WRITE_UNCERTAIN_INSPECT_FILE";
        return "TOOL_FAILED_OR_STALE";
    }
    private String panelActionPrecondition(long screenToken,String callId){
        PanelEvidence evidence=panelEvidence;
        if(screenToken<0)return "SCREEN_STATUS_DISABLED";
        if(evidence==null||evidence.used||threadId==null||turnId==null
                ||!threadId.equals(evidence.thread)||!turnId.equals(evidence.turn)
                ||(callId!=null&&callId.equals(evidence.imageCall))
                ||!screenStatusGate.valid(evidence.gateToken))return "PANEL_IMAGE_REQUIRED";
        if(ownPanelAction==null)return "PANEL_ACTION_UNAVAILABLE";
        return null;
    }
    private boolean approved(String title,String review) throws InterruptedException {
        if(stopRequested.get()||cancelled.get())return false;
        ToolGate gate=new ToolGate();pendingTool=gate;
        return awaitApproval(title,review,gate,false);
    }
    private boolean approvedScreenStatus(String title,String review,long token) throws InterruptedException {
        return approvedScreenStatus(title,review,token,false);
    }
    private boolean approvedScreenStatus(String title,String review,long token,boolean panelAction) throws InterruptedException {
        ToolGate gate=new ToolGate();
        synchronized(screenStatusGate){
            if(stopRequested.get()||cancelled.get()||!screenStatusGate.valid(token))return false;
            pendingTool=gate;pendingScreenTool=gate;
        }
        return awaitApproval(title,review,gate,true,panelAction);
    }
    private boolean awaitApproval(String title,String review,ToolGate gate,boolean screenStatus) throws InterruptedException {
        return awaitApproval(title,review,gate,screenStatus,false);
    }
    private boolean awaitApproval(String title,String review,ToolGate gate,boolean screenStatus,boolean panelAction) throws InterruptedException {
        try{
            Events sink=eventSink;if(sink==null)return false;
            if(screenStatus)screenApprovalRequests.incrementAndGet();
            if(panelAction)sink.approvePanelAction(title,review,gate);
            else sink.approveTool(title,review,gate);
            return gate.await()&&!stopRequested.get()&&!cancelled.get();
        }finally{
            if(screenStatus)synchronized(screenStatusGate){if(pendingScreenTool==gate)pendingScreenTool=null;}
            if(pendingTool==gate)pendingTool=null;
            gate.resolve(false);
        }
    }
    private boolean isRetiredTurnEvent(String method,Map<?,?> params){
        if(threadId==null||!threadId.equals(params.get("threadId")))return false;
        Object oldId;
        if("turn/completed".equals(method)){
            Object turn=params.get("turn");
            oldId=turn instanceof Map?((Map<?,?>)turn).get("id"):null;
        }else if(method.startsWith("item/")||"turn/moderationMetadata".equals(method))oldId=params.get("turnId");
        else return false;
        return oldId instanceof String&&retiredTurnIds.contains(oldId);
    }
    private void validatePendingModeration() throws GateException {
        for(String moderationTurnId:pendingModerationTurnIds)
            require(turnId!=null&&turnId.equals(moderationTurnId),"MODERATION_IDS_INVALID");
        pendingModerationTurnIds.clear();
    }
    private void commitAgentItem(){
        if(agentItemId==null)return;
        if(itemAnswer.length()>0){
            if(answer.length()>0)appendAnswerPreview("\n\n");
            appendAnswerPreview(itemAnswer.toString());
            if(itemAnswerTruncated)answerTruncated=true;
        }
        itemAnswer.setLength(0);itemAnswerTruncated=false;agentItemId=null;
    }
    private void appendItemPreview(String part){
        if(part.isEmpty())return;
        int available=MAX_PREVIEW-itemAnswer.length();
        if(available<=0){itemAnswerTruncated=true;return;}
        int keep=Math.min(available,part.length());
        if(keep<part.length()&&keep>0&&Character.isHighSurrogate(part.charAt(keep-1)))keep--;
        itemAnswer.append(part,0,keep);
        if(keep<part.length())itemAnswerTruncated=true;
    }
    private void appendAnswerPreview(String part){
        if(part.isEmpty())return;
        int available=MAX_PREVIEW-answer.length();
        if(available<=0){answerTruncated=true;return;}
        int keep=Math.min(available,part.length());
        if(keep<part.length()&&keep>0&&Character.isHighSurrogate(part.charAt(keep-1)))keep--;
        answer.append(part,0,keep);
        if(keep<part.length())answerTruncated=true;
    }
    private Map<?,?> frame(InputStream in,ExecutorService readers,long deadline) throws Exception{
        require(!cancelled.get()&&++frames<=MAX_FRAMES,"CANCELLED_OR_TOO_MANY_FRAMES");
        long remaining=deadline-System.nanoTime();require(remaining>0,"SESSION_TIMEOUT");
        byte[] line=readers.submit(()->readLine(in)).get(remaining,TimeUnit.NANOSECONDS);
        return obj(BoundedJson.parse(line),"FRAME_INVALID");
    }
    private static byte[] readLine(InputStream in) throws IOException{
        ByteArrayOutputStream bytes=new ByteArrayOutputStream();
        while(bytes.size()<MAX_FRAME){int b=in.read();if(b<0)throw new IOException("EOF");
            if(b=='\n')return bytes.toByteArray();bytes.write(b);}
        throw new IOException("FRAME_OVERSIZE");
    }
    private static void send(OutputStream out,String value) throws IOException{
        out.write((value+"\n").getBytes(StandardCharsets.UTF_8));out.flush();
    }
    private static long afterSeconds(long seconds){return System.nanoTime()+TimeUnit.SECONDS.toNanos(seconds);}
    private static String quote(String value){
        StringBuilder out=new StringBuilder(value.length()+2).append('"');
        for(int i=0;i<value.length();i++){
            char c=value.charAt(i);
            if(c=='"'||c=='\\')out.append('\\').append(c);
            else if(c=='\n')out.append("\\n");
            else if(c=='\r')out.append("\\r");
            else if(c=='\t')out.append("\\t");
            else if(c<0x20)out.append(String.format(java.util.Locale.ROOT,"\\u%04x",(int)c));
            else out.append(c);
        }
        return out.append('"').toString();
    }
    private static Map<?,?> obj(Object value,String code) throws GateException{
        if(!(value instanceof Map))throw new GateException(code);return (Map<?,?>)value;
    }
    private static String string(Object value,String code) throws GateException{
        if(!(value instanceof String))throw new GateException(code);return (String)value;
    }
    private static String completionFailureCode(Object rawError){
        if(!(rawError instanceof String))return "LOGIN_NOT_COMPLETED";
        String error=(String)rawError;
        String typed=NativePollDetail.classify(error);
        if(typed!=null)return typed;
        // These fixed phase markers are emitted by the pinned diagnostic native
        // build. They carry no HTTP body, token, account value, or error text.
        if("CORETEST_AUTH_CLIENT_INIT_FAILED".equals(error))return "AUTH_CLIENT_INIT_FAILED";
        if("CORETEST_DEVICE_POLL_FAILED".equals(error))return "DEVICE_POLL_FAILED";
        if("CORETEST_POLL_REQUEST_BUILD_FAILED".equals(error))return "POLL_REQUEST_BUILD_FAILED";
        if("CORETEST_POLL_TRANSPORT_FAILED".equals(error))return "POLL_TRANSPORT_FAILED";
        if("CORETEST_POLL_TRANSPORT_TIMEOUT".equals(error))return "POLL_TRANSPORT_TIMEOUT";
        if("CORETEST_POLL_CONNECT_AFTER_REDIRECT".equals(error))return "POLL_CONNECT_AFTER_REDIRECT";
        if("CORETEST_POLL_CONNECT_NO_REDIRECT".equals(error))return "POLL_CONNECT_NO_REDIRECT";
        if("CORETEST_POLL_CONNECT_FIRST_SEND_NO_REDIRECT".equals(error))return "POLL_CONNECT_FIRST_SEND_NO_REDIRECT";
        if("CORETEST_POLL_CONNECT_AFTER_PENDING_NO_REDIRECT".equals(error))return "POLL_CONNECT_AFTER_PENDING_NO_REDIRECT";
        if("CORETEST_POLL_CONNECT_FIRST_SEND_AFTER_REDIRECT".equals(error))return "POLL_CONNECT_FIRST_SEND_AFTER_REDIRECT";
        if("CORETEST_POLL_CONNECT_AFTER_PENDING_AFTER_REDIRECT".equals(error))return "POLL_CONNECT_AFTER_PENDING_AFTER_REDIRECT";
        if("CORETEST_POLL_TRANSPORT_OTHER_FAILED".equals(error))return "POLL_TRANSPORT_OTHER_FAILED";
        if("CORETEST_POLL_RESPONSE_SCHEMA_FAILED".equals(error))return "POLL_RESPONSE_SCHEMA_FAILED";
        if("CORETEST_POLL_EXPIRED".equals(error))return "POLL_EXPIRED";
        if("CORETEST_POLL_RATE_LIMITED".equals(error))return "POLL_RATE_LIMITED";
        if("CORETEST_POLL_HTTP_REJECTED".equals(error))return "POLL_HTTP_REJECTED";
        if("CORETEST_TOKEN_EXCHANGE_FAILED".equals(error))return "TOKEN_EXCHANGE_FAILED";
        if("CORETEST_WORKSPACE_REJECTED".equals(error))return "WORKSPACE_REJECTED";
        if("CORETEST_EPHEMERAL_STORE_FAILED".equals(error))return "EPHEMERAL_STORE_FAILED";
        if("CORETEST_POST_LOGIN_ACCOUNT_READ_FAILED".equals(error))return "POST_LOGIN_ACCOUNT_READ_FAILED";
        // The pinned server supplies this text. Match known source phrases only;
        // never log, retain, or display its raw content, which may contain secrets.
        if("Login was not completed".equals(error))return "SERVER_CANCELLED_LOGIN";
        if("account changed before sign-in completed".equals(error))return "ACCOUNT_CHANGED_AFTER_AUTH";
        if("device auth timed out after 15 minutes".equals(error))return "DEVICE_POLL_TIMEOUT";
        if(error.startsWith("device auth failed with status "))return "DEVICE_POLL_REJECTED";
        if(error.startsWith("device code exchange failed:"))return "TOKEN_EXCHANGE_FAILED";
        if(error.startsWith("workspace routing ")
                || error.startsWith("selected workspace ")
                || error.startsWith("failed to load workspace requirements")
                || error.startsWith("failed to reload workspace requirements")
                || error.startsWith("configuration changed during workspace routing discovery")){
            return "POST_LOGIN_ACCOUNT_CHECK_FAILED";
        }
        return "LOGIN_NOT_COMPLETED";
    }
    private static void require(boolean ok,String code) throws GateException{if(!ok)throw new GateException(code);}
    private static String hex(byte[] bytes){StringBuilder out=new StringBuilder();
        for(byte b:bytes)out.append(String.format(java.util.Locale.ROOT,"%02x",b&255));return out.toString();}
}
