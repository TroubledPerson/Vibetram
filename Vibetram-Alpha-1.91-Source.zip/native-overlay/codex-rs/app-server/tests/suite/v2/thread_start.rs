use anyhow::Context;
use anyhow::Result;
use app_test_support::ChatGptAuthFixture;
use app_test_support::PathBufExt;
use app_test_support::TestAppServer;
use app_test_support::create_mock_responses_server_repeating_assistant;
use app_test_support::to_response;
use app_test_support::write_chatgpt_auth;
use codex_app_server_protocol::AskForApproval;
use codex_app_server_protocol::ClientRequest;
use codex_app_server_protocol::ConfigWarningNotification;
use codex_app_server_protocol::JSONRPCError;
use codex_app_server_protocol::JSONRPCMessage;
use codex_app_server_protocol::JSONRPCNotification;
use codex_app_server_protocol::JSONRPCResponse;
use codex_app_server_protocol::ListMcpServerStatusParams;
use codex_app_server_protocol::ListMcpServerStatusResponse;
use codex_app_server_protocol::McpServerStartupState;
use codex_app_server_protocol::McpServerStatusDetail;
use codex_app_server_protocol::McpServerStatusUpdatedNotification;
use codex_app_server_protocol::RequestId;
use codex_app_server_protocol::SandboxMode;
#[cfg(not(windows))]
use codex_app_server_protocol::SandboxPolicy;
use codex_app_server_protocol::ServerNotification;
use codex_app_server_protocol::TextPosition;
use codex_app_server_protocol::TextRange;
use codex_app_server_protocol::ThreadHistoryMode;
use codex_app_server_protocol::ThreadSource;
use codex_app_server_protocol::ThreadStartParams;
use codex_app_server_protocol::ThreadStartResponse;
use codex_app_server_protocol::ThreadStartedNotification;
use codex_app_server_protocol::ThreadStatus;
use codex_app_server_protocol::ThreadStatusChangedNotification;
use codex_app_server_protocol::TurnEnvironmentParams;
use codex_app_server_protocol::TurnStartParams;
use codex_app_server_protocol::UserInput as V2UserInput;
use codex_config::loader::project_trust_key;
use codex_config::types::AuthCredentialsStoreMode;
use codex_core::config::set_project_trust_level;
use codex_exec_server::LOCAL_FS;
use codex_git_utils::resolve_root_git_project_for_trust;
use codex_login::REFRESH_TOKEN_URL_OVERRIDE_ENV_VAR;
use codex_protocol::config_types::SERVICE_TIER_DEFAULT_REQUEST_VALUE;
use codex_protocol::config_types::TrustLevel;
use codex_protocol::models::BUILT_IN_PERMISSION_PROFILE_WORKSPACE;
use codex_protocol::openai_models::ReasoningEffort;
use core_test_support::stdio_server_bin;
use pretty_assertions::assert_eq;
use serde_json::Value;
use serde_json::json;
use std::path::Path;
use std::path::PathBuf;
use tempfile::TempDir;
use test_case::test_case;
use tokio::net::TcpListener;
use tokio::sync::oneshot;
use tokio::time::timeout;
use wiremock::Mock;
use wiremock::MockServer;
use wiremock::ResponseTemplate;
use wiremock::matchers::method;
use wiremock::matchers::path;

use super::analytics::assert_basic_thread_initialized_event;
use super::analytics::mount_analytics_capture;
use super::analytics::thread_initialized_event;
use super::analytics::wait_for_analytics_payload;

const DEFAULT_READ_TIMEOUT: std::time::Duration = std::time::Duration::from_secs(10);
const INVALID_REQUEST_ERROR_CODE: i64 = -32600;
const EXEC_POLICY_PARSE_WARNING_SUMMARY: &str = "Error parsing rules; custom rules not applied.";

fn is_exec_policy_config_warning(notification: &JSONRPCNotification) -> bool {
    notification.method == "configWarning"
        && notification
            .params
            .as_ref()
            .and_then(|params| params.get("summary"))
            .and_then(Value::as_str)
            == Some(EXEC_POLICY_PARSE_WARNING_SUMMARY)
}

async fn start_thread_with_model(
    mcp: &mut TestAppServer,
    model: &str,
    allow_provider_model_fallback: bool,
) -> Result<ThreadStartResponse> {
    mcp.start_thread(ThreadStartParams {
        model: Some(model.to_string()),
        allow_provider_model_fallback,
        ..Default::default()
    })
    .await
}

#[tokio::test]
async fn thread_start_provider_model_fallback_applies_to_configured_model() -> Result<()> {
    let codex_home = TempDir::new()?;
    std::fs::write(
        codex_home.path().join("config.toml"),
        r#"model_provider = "amazon-bedrock"
model = "gpt-5.4-mini"
"#,
    )?;
    let mut mcp = TestAppServer::builder()
        .with_codex_home(codex_home.path())
        .build_initialized()
        .await?;

    let response = mcp
        .start_thread(ThreadStartParams {
            allow_provider_model_fallback: true,
            ..Default::default()
        })
        .await?;

    assert_eq!(response.model, "openai.gpt-5.6-sol");
    Ok(())
}

#[tokio::test]
async fn thread_start_warns_for_exec_policy_parse_failure_after_initialize() -> Result<()> {
    let codex_home = TempDir::new()?;
    let mut mcp = TestAppServer::builder()
        .with_codex_home(codex_home.path())
        .build_initialized()
        .await?;

    let rules_dir = codex_home.path().join("rules");
    std::fs::create_dir_all(&rules_dir)?;
    let rules_path = rules_dir.join("broken.rules");
    std::fs::write(&rules_path, "prefix_rule(")?;
    let rules_path = std::fs::canonicalize(rules_path)?;

    mcp.start_thread(ThreadStartParams::default()).await?;

    let notification = timeout(
        DEFAULT_READ_TIMEOUT,
        mcp.read_stream_until_matching_notification(
            "exec-policy configWarning",
            is_exec_policy_config_warning,
        ),
    )
    .await??;
    let notification: ServerNotification = notification.try_into()?;
    let ServerNotification::ConfigWarning(warning) = notification else {
        anyhow::bail!("unexpected notification variant");
    };
    let ConfigWarningNotification {
        summary,
        details,
        path,
        range,
    } = warning;
    assert_eq!(
        (summary, range),
        (
            "Error parsing rules; custom rules not applied.".to_string(),
            Some(TextRange {
                start: TextPosition {
                    line: 1,
                    column: 13,
                },
                end: TextPosition {
                    line: 1,
                    column: 13,
                },
            }),
        )
    );
    let path = path.context("warning should include a path")?;
    assert_eq!(
        normalize_path_for_comparison(path),
        normalize_path_for_comparison(&rules_path)
    );
    let details = details.context("warning should include details")?;
    assert!(
        details.contains("failed to parse rules file") && details.contains("broken.rules"),
        "unexpected warning details: {details}"
    );
    assert!(
        details.contains("Parse error"),
        "unexpected warning details: {details}"
    );

    Ok(())
}

#[tokio::test]
async fn thread_start_does_not_repeat_initialize_exec_policy_warning() -> Result<()> {
    let codex_home = TempDir::new()?;
    let rules_dir = codex_home.path().join("rules");
    std::fs::create_dir_all(&rules_dir)?;
    std::fs::write(rules_dir.join("broken.rules"), "prefix_rule(")?;

    let mut mcp = TestAppServer::builder()
        .with_codex_home(codex_home.path())
        .build_initialized()
        .await?;
    timeout(
        DEFAULT_READ_TIMEOUT,
        mcp.read_stream_until_matching_notification(
            "initialize exec-policy configWarning",
            is_exec_policy_config_warning,
        ),
    )
    .await??;

    mcp.start_thread(ThreadStartParams::default()).await?;

    let duplicate_warning = timeout(
        std::time::Duration::from_millis(250),
        mcp.read_stream_until_matching_notification(
            "duplicate exec-policy configWarning",
            is_exec_policy_config_warning,
        ),
    )
    .await;
    assert!(
        duplicate_warning.is_err(),
        "thread/start repeated the initialize exec-policy warning"
    );

    Ok(())
}

#[tokio::test]
async fn thread_start_provider_model_fallback_uses_bedrock_static_catalog() -> Result<()> {
    let codex_home = TempDir::new()?;
    std::fs::write(
        codex_home.path().join("config.toml"),
        r#"model_provider = "amazon-bedrock"
"#,
    )?;
    let mut mcp = TestAppServer::builder()
        .with_codex_home(codex_home.path())
        .build_initialized()
        .await?;

    let unsupported_with_fallback = start_thread_with_model(
        &mut mcp,
        "gpt-5.4-mini",
        /*allow_provider_model_fallback*/ true,
    )
    .await?;
    let supported_with_fallback = start_thread_with_model(
        &mut mcp,
        "openai.gpt-5.4",
        /*allow_provider_model_fallback*/ true,
    )
    .await?;
    let unsupported_without_fallback = start_thread_with_model(
        &mut mcp,
        "gpt-5.4-mini",
        /*allow_provider_model_fallback*/ false,
    )
    .await?;

    assert_eq!(
        vec![
            unsupported_with_fallback.model,
            supported_with_fallback.model,
            unsupported_without_fallback.model,
        ],
        vec!["openai.gpt-5.6-sol", "openai.gpt-5.4", "gpt-5.4-mini"]
    );
    Ok(())
}

#[tokio::test]
async fn thread_start_bedrock_runtime_prefers_global_cross_region_models() -> Result<()> {
    let codex_home = TempDir::new()?;
    std::fs::write(
        codex_home.path().join("config.toml"),
        r#"model_provider = "amazon-bedrock-runtime"
"#,
    )?;
    let mut mcp = TestAppServer::builder()
        .with_codex_home(codex_home.path())
        .build_initialized()
        .await?;

    for model in ["global.openai.gpt-5.6-sol", "us.openai.gpt-5.6-sol"] {
        let response =
            start_thread_with_model(&mut mcp, model, /*allow_provider_model_fallback*/ true)
                .await?;
        assert_eq!(response.model, model);
    }

    let response = start_thread_with_model(
        &mut mcp,
        "openai.gpt-5.6-sol",
        /*allow_provider_model_fallback*/ true,
    )
    .await?;
    assert_eq!(response.model, "global.openai.gpt-5.6-sol");

    Ok(())
}

#[tokio::test]
async fn thread_start_provider_model_fallback_ignores_dynamic_catalog() -> Result<()> {
    let server = create_mock_responses_server_repeating_assistant("Done").await;
    let codex_home = TempDir::new()?;
    create_config_toml_without_approval_policy(codex_home.path(), &server.uri())?;
    let mut mcp = TestAppServer::builder()
        .with_codex_home(codex_home.path())
        .build_initialized()
        .await?;

    let response = start_thread_with_model(
        &mut mcp,
        "unlisted-dynamic-model",
        /*allow_provider_model_fallback*/ true,
    )
    .await?;

    assert_eq!(response.model, "unlisted-dynamic-model");
    Ok(())
}

#[tokio::test]
async fn thread_start_creates_thread_and_emits_started() -> Result<()> {
    // Provide a mock server and config so model wiring is valid.
    let server = create_mock_responses_server_repeating_assistant("Done").await;

    let codex_home = TempDir::new()?;
    create_config_toml(
        codex_home.path(),
        &server.uri(),
        "sandbox_mode = \"read-only\"\nmodel_reasoning_effort = \"high\"",
        "",
    )?;

    // Start server and initialize.
    let mut mcp = TestAppServer::builder()
        .with_codex_home(codex_home.path())
        .build_initialized()
        .await?;

    // Start a v2 thread with an explicit model override.
    let req_id = mcp
        .send_thread_start_request_with_auto_env(ThreadStartParams {
            model: Some("gpt-5.2".to_string()),
            thread_source: Some(ThreadSource::User),
            service_name: Some("codex_work_desktop".to_string()),
            ..Default::default()
        })
        .await?;

    // Expect a proper JSON-RPC response with a thread id.
    let resp: JSONRPCResponse = timeout(
        DEFAULT_READ_TIMEOUT,
        mcp.read_stream_until_response_message(RequestId::Integer(req_id)),
    )
    .await??;
    let resp_result = resp.result.clone();
    let ThreadStartResponse {
        thread,
        model_provider,
        ..
    } = to_response::<ThreadStartResponse>(resp)?;
    assert!(
        !thread.session_id.is_empty(),
        "session id should not be empty"
    );
    assert!(!thread.id.is_empty(), "thread id should not be empty");
    assert!(
        thread.preview.is_empty(),
        "new threads should start with an empty preview"
    );
    assert_eq!(model_provider, "mock_provider");
    assert_eq!(
        (thread.model.as_deref(), thread.reasoning_effort.clone()),
        (Some("gpt-5.2"), Some(ReasoningEffort::High))
    );
    assert!(
        thread.created_at > 0,
        "created_at should be a positive UNIX timestamp"
    );
    assert!(
        !thread.ephemeral,
        "new persistent threads should not be ephemeral"
    );
    assert_eq!(thread.status, ThreadStatus::Idle);
    assert_eq!(thread.thread_source, Some(ThreadSource::User));
    assert_eq!(thread.originator.as_deref(), Some("codex_work_desktop"));
    let thread_path = thread.path.clone().expect("thread path should be present");
    assert!(thread_path.is_absolute(), "thread path should be absolute");
    assert!(
        !thread_path.exists(),
        "fresh thread rollout should not be materialized until first user message"
    );

    // Wire contract: thread title field is `name`, serialized as null when unset.
    let thread_json = resp_result
        .get("thread")
        .and_then(Value::as_object)
        .expect("thread/start result.thread must be an object");
    assert_eq!(
        thread_json.get("sessionId").and_then(Value::as_str),
        Some(thread.session_id.as_str()),
        "new threads should serialize `sessionId` on the thread object"
    );
    assert_eq!(
        thread_json.get("name"),
        Some(&Value::Null),
        "new threads should serialize `name: null`"
    );
    assert_eq!(
        resp_result.get("sessionId"),
        None,
        "thread/start should not serialize a top-level `sessionId`"
    );
    assert_eq!(
        thread_json.get("ephemeral").and_then(Value::as_bool),
        Some(false),
        "new persistent threads should serialize `ephemeral: false`"
    );
    assert_eq!(
        thread_json.get("historyMode").and_then(Value::as_str),
        Some("paginated"),
        "durable threads should default to `historyMode: paginated` when supported"
    );
    assert_eq!(
        thread_json.get("threadSource").and_then(Value::as_str),
        Some("user"),
        "new threads should serialize the caller-supplied thread origin"
    );
    assert_eq!(thread.name, None);

    // A corresponding thread/started notification should arrive.
    let deadline = tokio::time::Instant::now() + DEFAULT_READ_TIMEOUT;
    let notif = loop {
        let remaining = deadline.saturating_duration_since(tokio::time::Instant::now());
        let message = timeout(remaining, mcp.read_next_message()).await??;
        let JSONRPCMessage::Notification(notif) = message else {
            continue;
        };
        if notif.method == "thread/status/changed" {
            let status_changed: ThreadStatusChangedNotification =
                serde_json::from_value(notif.params.expect("params must be present"))?;
            if status_changed.thread_id == thread.id {
                anyhow::bail!(
                    "thread/start should introduce the thread without a preceding thread/status/changed"
                );
            }
            continue;
        }
        if notif.method == "thread/started" {
            break notif;
        }
    };
    let started_params = notif.params.clone().expect("params must be present");
    let started_thread_json = started_params
        .get("thread")
        .and_then(Value::as_object)
        .expect("thread/started params.thread must be an object");
    assert_eq!(
        started_thread_json.get("name"),
        Some(&Value::Null),
        "thread/started should serialize `name: null` for new threads"
    );
    assert_eq!(
        started_thread_json
            .get("ephemeral")
            .and_then(Value::as_bool),
        Some(false),
        "thread/started should serialize `ephemeral: false` for new persistent threads"
    );
    assert_eq!(
        started_thread_json
            .get("threadSource")
            .and_then(Value::as_str),
        Some("user"),
        "thread/started should preserve the caller-supplied thread origin"
    );
    let started: ThreadStartedNotification =
        serde_json::from_value(notif.params.expect("params must be present"))?;
    assert_eq!(started.thread, thread);

    Ok(())
}

#[tokio::test]
async fn thread_start_history_mode_accepts_legacy_and_paginated() -> Result<()> {
    let server = create_mock_responses_server_repeating_assistant("Done").await;
    let codex_home = TempDir::new()?;
    create_config_toml_without_approval_policy(codex_home.path(), &server.uri())?;

    let mut mcp = TestAppServer::builder()
        .with_codex_home(codex_home.path())
        .build_initialized()
        .await?;

    let ThreadStartResponse { thread, .. } = mcp
        .start_thread(ThreadStartParams {
            history_mode: Some(ThreadHistoryMode::Legacy),
            ..Default::default()
        })
        .await?;

    assert_eq!(thread.history_mode, ThreadHistoryMode::Legacy);

    let ThreadStartResponse { thread, .. } = mcp
        .start_thread(ThreadStartParams {
            history_mode: Some(ThreadHistoryMode::Paginated),
            ..Default::default()
        })
        .await?;

    assert_eq!(thread.history_mode, ThreadHistoryMode::Paginated);
    Ok(())
}

#[tokio::test]
async fn thread_start_accepts_absolute_runtime_workspace_roots() -> Result<()> {
    let server = create_mock_responses_server_repeating_assistant("Done").await;
    let codex_home = TempDir::new()?;
    create_config_toml_without_approval_policy(codex_home.path(), &server.uri())?;

    let cwd_tmp = TempDir::new()?;
    let cwd = cwd_tmp.path().to_path_buf();
    let extra_root = cwd.join("extra-root");
    std::fs::create_dir_all(&extra_root)?;

    let mut mcp = TestAppServer::builder()
        .with_codex_home(codex_home.path())
        .build_initialized()
        .await?;

    let req_id = mcp
        .send_thread_start_request(ThreadStartParams {
            cwd: Some(cwd.to_string_lossy().to_string()),
            runtime_workspace_roots: Some(vec![extra_root.abs()]),
            sandbox: Some(SandboxMode::WorkspaceWrite),
            ..Default::default()
        })
        .await?;

    let ThreadStartResponse {
        cwd: response_cwd,
        runtime_workspace_roots,
        sandbox,
        ..
    } = timeout(DEFAULT_READ_TIMEOUT, mcp.read_response(req_id)).await??;

    assert_eq!(response_cwd, cwd.abs());
    assert_eq!(runtime_workspace_roots, vec![extra_root.abs()]);
    #[cfg(windows)]
    let _ = sandbox;
    #[cfg(not(windows))]
    {
        let SandboxPolicy::WorkspaceWrite { writable_roots, .. } = sandbox else {
            panic!("expected workspace-write sandbox");
        };
        assert!(
            writable_roots.contains(&extra_root.abs().canonicalize()?),
            "legacy sandbox projection should include the runtime workspace root"
        );
    }

    let environment_root = cwd.join("environment-root");
    std::fs::create_dir_all(&environment_root)?;
    let mut environment = mcp.auto_env_params()?;
    environment.runtime_workspace_roots = Some(vec![environment_root.abs().into()]);
    let req_id = mcp
        .send_thread_start_request(ThreadStartParams {
            runtime_workspace_roots: Some(vec![extra_root.abs()]),
            environments: Some(vec![environment]),
            sandbox: Some(SandboxMode::WorkspaceWrite),
            ..Default::default()
        })
        .await?;
    let ThreadStartResponse {
        runtime_workspace_roots,
        sandbox,
        ..
    } = timeout(DEFAULT_READ_TIMEOUT, mcp.read_response(req_id)).await??;
    assert_eq!(runtime_workspace_roots, vec![environment_root.abs()]);
    #[cfg(windows)]
    let _ = sandbox;
    #[cfg(not(windows))]
    {
        let SandboxPolicy::WorkspaceWrite { writable_roots, .. } = sandbox else {
            panic!("expected workspace-write sandbox");
        };
        assert!(
            writable_roots.contains(&environment_root.abs().canonicalize()?),
            "legacy sandbox projection should include the environment workspace root"
        );
    }

    Ok(())
}

#[tokio::test]
async fn thread_start_excludes_profile_workspace_roots_from_runtime_workspace_roots() -> Result<()>
{
    let server = create_mock_responses_server_repeating_assistant("Done").await;
    let codex_home = TempDir::new()?;
    let cwd = TempDir::new()?;
    let profile_root = TempDir::new()?;
    create_config_toml_with_profile_workspace_root(
        codex_home.path(),
        &server.uri(),
        profile_root.path(),
    )?;

    let mut mcp = TestAppServer::builder()
        .with_codex_home(codex_home.path())
        .build_initialized()
        .await?;

    let req_id = mcp
        .send_thread_start_request(ThreadStartParams {
            cwd: Some(cwd.path().to_string_lossy().to_string()),
            ..Default::default()
        })
        .await?;

    let ThreadStartResponse {
        runtime_workspace_roots,
        ..
    } = timeout(DEFAULT_READ_TIMEOUT, mcp.read_response(req_id)).await??;

    assert_eq!(
        runtime_workspace_roots,
        vec![cwd.path().to_path_buf().abs()]
    );

    Ok(())
}

#[tokio::test]
async fn thread_start_rejects_unknown_environment_as_invalid_request() -> Result<()> {
    let server = create_mock_responses_server_repeating_assistant("Done").await;

    let codex_home = TempDir::new()?;
    create_config_toml_without_approval_policy(codex_home.path(), &server.uri())?;
    let config_path = codex_home.path().join("config.toml");
    let config_before = std::fs::read_to_string(&config_path)?;
    let workspace = TempDir::new()?;
    let workspace = workspace.path().to_path_buf().abs();

    let mut mcp = TestAppServer::builder()
        .with_codex_home(codex_home.path())
        .build_initialized()
        .await?;

    let request_id = mcp
        .send_thread_start_request(ThreadStartParams {
            cwd: Some(workspace.to_string_lossy().into_owned()),
            sandbox: Some(SandboxMode::WorkspaceWrite),
            environments: Some(vec![TurnEnvironmentParams {
                environment_id: "missing".to_string(),
                cwd: workspace.into(),
                runtime_workspace_roots: None,
            }]),
            ..Default::default()
        })
        .await?;

    let error: JSONRPCError = timeout(
        DEFAULT_READ_TIMEOUT,
        mcp.read_stream_until_error_message(RequestId::Integer(request_id)),
    )
    .await??;

    assert_eq!(error.id, RequestId::Integer(request_id));
    assert_eq!(error.error.code, INVALID_REQUEST_ERROR_CODE);
    assert_eq!(error.error.message, "unknown turn environment id `missing`");
    assert_eq!(std::fs::read_to_string(config_path)?, config_before);

    Ok(())
}

#[tokio::test]
async fn thread_start_rejects_relative_environment_cwd_as_invalid_request() -> Result<()> {
    let server = create_mock_responses_server_repeating_assistant("Done").await;
    let codex_home = TempDir::new()?;
    create_config_toml_without_approval_policy(codex_home.path(), &server.uri())?;

    let mut mcp = TestAppServer::builder()
        .with_codex_home(codex_home.path())
        .build_initialized()
        .await?;
    let environment_id = mcp.auto_env_params()?.environment_id;

    let request_id = mcp
        .send_thread_start_request(ThreadStartParams {
            environments: Some(vec![TurnEnvironmentParams {
                environment_id: environment_id.clone(),
                cwd: serde_json::from_value(json!("relative"))?,
                runtime_workspace_roots: None,
            }]),
            ..Default::default()
        })
        .await?;
    let error: JSONRPCError = timeout(
        DEFAULT_READ_TIMEOUT,
        mcp.read_stream_until_error_message(RequestId::Integer(request_id)),
    )
    .await??;

    assert_eq!(error.id, RequestId::Integer(request_id));
    assert_eq!(error.error.code, INVALID_REQUEST_ERROR_CODE);
    assert_eq!(
        error.error.message,
        format!(
            "invalid cwd for environment `{environment_id}`: path `relative` does not use absolute POSIX or Windows path syntax"
        )
    );

    Ok(())
}

#[tokio::test]
async fn thread_start_rejects_oversized_environment_cwd_as_invalid_request() -> Result<()> {
    let server = create_mock_responses_server_repeating_assistant("Done").await;
    let codex_home = TempDir::new()?;
    create_config_toml_without_approval_policy(codex_home.path(), &server.uri())?;

    let mut mcp = TestAppServer::builder()
        .with_codex_home(codex_home.path())
        .build_initialized()
        .await?;
    let environment_id = mcp.auto_env_params()?.environment_id;

    let request_id = mcp
        .send_thread_start_request(ThreadStartParams {
            environments: Some(vec![TurnEnvironmentParams {
                environment_id,
                cwd: serde_json::from_value(json!(format!("C:\\{}", "x".repeat(9_000))))?,
                runtime_workspace_roots: None,
            }]),
            ..Default::default()
        })
        .await?;
    let error: JSONRPCError = timeout(
        DEFAULT_READ_TIMEOUT,
        mcp.read_stream_until_error_message(RequestId::Integer(request_id)),
    )
    .await??;

    assert_eq!(error.id, RequestId::Integer(request_id));
    assert_eq!(error.error.code, INVALID_REQUEST_ERROR_CODE);
    assert_eq!(
        error.error.message,
        "turn environment working directory exceeds the maximum size"
    );

    Ok(())
}

#[tokio::test]
async fn thread_start_response_includes_loaded_instruction_sources() -> Result<()> {
    let server = create_mock_responses_server_repeating_assistant("Done").await;
    let codex_home = TempDir::new()?;
    create_config_toml_without_approval_policy(codex_home.path(), &server.uri())?;
    let global_agents_path = codex_home.path().join("AGENTS.md");
    std::fs::write(&global_agents_path, "global instructions")?;
    let workspace = TempDir::new()?;
    let project_agents_path = workspace.path().join("AGENTS.md");
    std::fs::write(&project_agents_path, "project instructions")?;

    let mut mcp = TestAppServer::builder()
        .with_codex_home(codex_home.path())
        // TODO(anp): Move the instruction-source fixture into the auto environment cwd.
        .without_auto_env()
        .build_initialized()
        .await?;

    let request_id = mcp
        .send_thread_start_request(ThreadStartParams {
            cwd: Some(workspace.path().display().to_string()),
            ..Default::default()
        })
        .await?;
    let ThreadStartResponse {
        instruction_sources,
        ..
    } = timeout(DEFAULT_READ_TIMEOUT, mcp.read_response(request_id)).await??;

    let instruction_sources = instruction_sources
        .into_iter()
        .map(|path| normalize_path_for_comparison(path.as_str()))
        .collect::<Vec<_>>();
    let expected_instruction_sources = vec![
        std::fs::canonicalize(global_agents_path)?,
        project_agents_path,
    ]
    .into_iter()
    .map(normalize_path_for_comparison)
    .collect::<Vec<_>>();

    assert_eq!(instruction_sources, expected_instruction_sources);

    Ok(())
}

#[tokio::test]
async fn thread_start_response_excludes_empty_project_instruction_source() -> Result<()> {
    let server = create_mock_responses_server_repeating_assistant("Done").await;
    let codex_home = TempDir::new()?;
    create_config_toml_without_approval_policy(codex_home.path(), &server.uri())?;
    let global_agents_path = codex_home.path().join("AGENTS.md");
    std::fs::write(&global_agents_path, "global instructions")?;
    let workspace = TempDir::new()?;
    let project_agents_path = workspace.path().join("AGENTS.md");
    std::fs::write(project_agents_path, "")?;

    let mut mcp = TestAppServer::builder()
        .with_codex_home(codex_home.path())
        // TODO(anp): Move the instruction-source fixture into the auto environment cwd.
        .without_auto_env()
        .build_initialized()
        .await?;

    let request_id = mcp
        .send_thread_start_request(ThreadStartParams {
            cwd: Some(workspace.path().display().to_string()),
            ..Default::default()
        })
        .await?;
    let ThreadStartResponse {
        instruction_sources,
        ..
    } = timeout(DEFAULT_READ_TIMEOUT, mcp.read_response(request_id)).await??;

    let instruction_sources = instruction_sources
        .into_iter()
        .map(|path| normalize_path_for_comparison(path.as_str()))
        .collect::<Vec<_>>();
    let expected_instruction_sources = vec![normalize_path_for_comparison(std::fs::canonicalize(
        global_agents_path,
    )?)];

    assert_eq!(instruction_sources, expected_instruction_sources);

    Ok(())
}

#[tokio::test]
async fn thread_start_without_selected_environment_includes_only_global_instruction_source()
-> Result<()> {
    let server = create_mock_responses_server_repeating_assistant("Done").await;
    let codex_home = TempDir::new()?;
    create_config_toml_without_approval_policy(codex_home.path(), &server.uri())?;
    let global_agents_path = codex_home.path().join("AGENTS.md");
    std::fs::write(&global_agents_path, "global instructions")?;
    let workspace = TempDir::new()?;
    std::fs::write(workspace.path().join("AGENTS.md"), "project instructions")?;

    let mut mcp = TestAppServer::builder()
        .with_codex_home(codex_home.path())
        .build_initialized()
        .await?;

    let request_id = mcp
        .send_thread_start_request(ThreadStartParams {
            cwd: Some(workspace.path().display().to_string()),
            environments: Some(Vec::new()),
            ..Default::default()
        })
        .await?;
    let ThreadStartResponse {
        thread,
        instruction_sources,
        ..
    } = timeout(DEFAULT_READ_TIMEOUT, mcp.read_response(request_id)).await??;

    assert_eq!(
        instruction_sources
            .into_iter()
            .map(|path| normalize_path_for_comparison(path.as_str()))
            .collect::<Vec<_>>(),
        vec![normalize_path_for_comparison(std::fs::canonicalize(
            global_agents_path,
        )?)]
    );

    let turn_request_id = mcp
        .send_turn_start_request(TurnStartParams {
            thread_id: thread.id,
            input: vec![V2UserInput::Text {
                text: "inspect instructions".to_string(),
                text_elements: Vec::new(),
            }],
            ..Default::default()
        })
        .await?;
    timeout(
        DEFAULT_READ_TIMEOUT,
        mcp.read_stream_until_response_message(RequestId::Integer(turn_request_id)),
    )
    .await??;
    timeout(
        DEFAULT_READ_TIMEOUT,
        mcp.read_stream_until_notification_message("turn/completed"),
    )
    .await??;

    let requests = server
        .received_requests()
        .await
        .context("failed to fetch received requests")?;
    let model_request = requests
        .iter()
        .find(|request| request.url.path().ends_with("/responses"))
        .context("expected model request")?;
    let model_request_body = model_request
        .body_json::<Value>()
        .context("model request body should be JSON")?
        .to_string();
    assert!(model_request_body.contains("global instructions"));
    assert!(!model_request_body.contains("project instructions"));

    Ok(())
}

#[cfg(windows)]
fn normalize_path_for_comparison(path: impl AsRef<Path>) -> PathBuf {
    let path = path.as_ref();
    let path = path.display().to_string();
    PathBuf::from(path.strip_prefix(r"\\?\").unwrap_or(&path))
}

#[cfg(not(windows))]
fn normalize_path_for_comparison(path: impl AsRef<Path>) -> PathBuf {
    path.as_ref().to_path_buf()
}

#[tokio::test]
async fn thread_start_tracks_thread_initialized_analytics() -> Result<()> {
    let server = create_mock_responses_server_repeating_assistant("Done").await;

    let codex_home = TempDir::new()?;
    create_config_toml_with_chatgpt_base_url(codex_home.path(), &server.uri(), &server.uri())?;
    mount_analytics_capture(&server, codex_home.path()).await?;

    let mut mcp = TestAppServer::builder()
        .with_codex_home(codex_home.path())
        .without_managed_config()
        .build_initialized()
        .await?;

    let ThreadStartResponse { thread, .. } = mcp
        .start_thread(ThreadStartParams {
            thread_source: Some(ThreadSource::User),
            service_name: Some("codex_work_desktop".to_string()),
            ..Default::default()
        })
        .await?;

    let payload = wait_for_analytics_payload(&server, DEFAULT_READ_TIMEOUT).await?;
    assert_eq!(payload["events"].as_array().expect("events array").len(), 1);
    let event = thread_initialized_event(&payload)?;
    assert_basic_thread_initialized_event(
        event,
        &thread.id,
        &thread.session_id,
        "codex_work_desktop",
        "mock-model",
        "new",
        "user",
    );
    Ok(())
}

#[tokio::test]
async fn thread_start_respects_project_config_from_cwd() -> Result<()> {
    let server = create_mock_responses_server_repeating_assistant("Done").await;

    let codex_home = TempDir::new()?;
    create_config_toml_without_approval_policy(codex_home.path(), &server.uri())?;

    let workspace = TempDir::new()?;
    let project_config_dir = workspace.path().join(".codex");
    std::fs::create_dir_all(&project_config_dir)?;
    std::fs::write(
        project_config_dir.join("config.toml"),
        r#"
model_reasoning_effort = "high"
"#,
    )?;
    set_project_trust_level(codex_home.path(), workspace.path(), TrustLevel::Trusted)?;

    let mut mcp = TestAppServer::builder()
        .with_codex_home(codex_home.path())
        .build_initialized()
        .await?;

    let ThreadStartResponse {
        reasoning_effort, ..
    } = mcp
        .start_thread(ThreadStartParams {
            cwd: Some(workspace.path().to_string_lossy().into_owned()),
            ..Default::default()
        })
        .await?;

    assert_eq!(reasoning_effort, Some(ReasoningEffort::High));
    Ok(())
}

#[tokio::test]
async fn thread_start_drops_unsupported_service_tier_id() -> Result<()> {
    let server = create_mock_responses_server_repeating_assistant("Done").await;

    let codex_home = TempDir::new()?;
    create_config_toml_without_approval_policy(codex_home.path(), &server.uri())?;

    let mut mcp = TestAppServer::builder()
        .with_codex_home(codex_home.path())
        .build_initialized()
        .await?;

    let service_tier_id = "experimental-tier-id".to_string();
    let ThreadStartResponse { service_tier, .. } = mcp
        .start_thread(ThreadStartParams {
            service_tier: Some(Some(service_tier_id.clone())),
            ..Default::default()
        })
        .await?;

    // Unsupported catalog ids are dropped at session config time instead of echoed back.
    assert_eq!(service_tier, None);
    Ok(())
}

#[tokio::test]
async fn thread_start_accepts_default_service_tier() -> Result<()> {
    let server = create_mock_responses_server_repeating_assistant("Done").await;

    let codex_home = TempDir::new()?;
    create_config_toml_without_approval_policy(codex_home.path(), &server.uri())?;

    let mut mcp = TestAppServer::builder()
        .with_codex_home(codex_home.path())
        .build_initialized()
        .await?;

    let ThreadStartResponse { service_tier, .. } = mcp
        .start_thread(ThreadStartParams {
            service_tier: Some(Some(SERVICE_TIER_DEFAULT_REQUEST_VALUE.to_string())),
            ..Default::default()
        })
        .await?;

    assert_eq!(
        service_tier,
        Some(SERVICE_TIER_DEFAULT_REQUEST_VALUE.to_string())
    );
    Ok(())
}

#[tokio::test]
async fn thread_start_accepts_metrics_service_name() -> Result<()> {
    let server = create_mock_responses_server_repeating_assistant("Done").await;

    let codex_home = TempDir::new()?;
    create_config_toml_without_approval_policy(codex_home.path(), &server.uri())?;

    let mut mcp = TestAppServer::builder()
        .with_codex_home(codex_home.path())
        .build_initialized()
        .await?;

    let ThreadStartResponse { thread, .. } = mcp
        .start_thread(ThreadStartParams {
            service_name: Some("my_app_server_client".to_string()),
            ..Default::default()
        })
        .await?;
    assert!(!thread.id.is_empty(), "thread id should not be empty");

    Ok(())
}

#[tokio::test]
async fn thread_start_ephemeral_remains_pathless() -> Result<()> {
    let server = create_mock_responses_server_repeating_assistant("Done").await;
    let codex_home = TempDir::new()?;
    create_config_toml_without_approval_policy(codex_home.path(), &server.uri())?;

    let mut mcp = TestAppServer::builder()
        .with_codex_home(codex_home.path())
        .build_initialized()
        .await?;

    let req_id = mcp
        .send_thread_start_request_with_auto_env(ThreadStartParams {
            model: Some("gpt-5.2".to_string()),
            ephemeral: Some(true),
            ..Default::default()
        })
        .await?;

    let resp: JSONRPCResponse = timeout(
        DEFAULT_READ_TIMEOUT,
        mcp.read_stream_until_response_message(RequestId::Integer(req_id)),
    )
    .await??;
    let resp_result = resp.result.clone();
    let ThreadStartResponse { thread, .. } = to_response::<ThreadStartResponse>(resp)?;
    assert!(
        thread.ephemeral,
        "ephemeral threads should be marked explicitly"
    );
    assert_eq!(thread.history_mode, ThreadHistoryMode::Legacy);
    assert_eq!(
        thread.path, None,
        "ephemeral threads should not expose a path"
    );
    let thread_json = resp_result
        .get("thread")
        .and_then(Value::as_object)
        .expect("thread/start result.thread must be an object");
    assert_eq!(
        thread_json.get("ephemeral").and_then(Value::as_bool),
        Some(true),
        "ephemeral threads should serialize `ephemeral: true`"
    );

    Ok(())
}

#[tokio::test]
async fn thread_start_fails_when_required_mcp_server_fails_to_initialize() -> Result<()> {
    let server = create_mock_responses_server_repeating_assistant("Done").await;

    let codex_home = TempDir::new()?;
    create_config_toml_with_required_broken_mcp(codex_home.path(), &server.uri())?;

    let mut mcp = TestAppServer::builder()
        .with_codex_home(codex_home.path())
        .build_initialized()
        .await?;

    let req_id = mcp
        .send_thread_start_request_with_auto_env(ThreadStartParams::default())
        .await?;

    let err: JSONRPCError = timeout(
        DEFAULT_READ_TIMEOUT,
        mcp.read_stream_until_error_message(RequestId::Integer(req_id)),
    )
    .await??;

    assert!(
        err.error
            .message
            .contains("required MCP servers failed to initialize"),
        "unexpected error message: {}",
        err.error.message
    );
    assert!(
        err.error.message.contains("required_broken"),
        "unexpected error message: {}",
        err.error.message
    );

    Ok(())
}

#[tokio::test]
async fn thread_start_fails_when_managed_hook_matcher_is_invalid() -> Result<()> {
    let server = create_mock_responses_server_repeating_assistant("Done").await;
    let codex_home = TempDir::new()?;
    create_config_toml_without_approval_policy(codex_home.path(), &server.uri())?;
    std::fs::write(
        codex_home.path().join("requirements.toml"),
        r#"[hooks]

[[hooks.PreToolUse]]
matcher = "["

[[hooks.PreToolUse.hooks]]
type = "command"
command = "echo managed"
"#,
    )?;

    let mut app_server = TestAppServer::builder()
        .with_codex_home(codex_home.path())
        .build_initialized()
        .await?;
    let request_id = app_server
        .send_thread_start_request_with_auto_env(ThreadStartParams::default())
        .await?;
    let error: JSONRPCError = timeout(
        DEFAULT_READ_TIMEOUT,
        app_server.read_stream_until_error_message(RequestId::Integer(request_id)),
    )
    .await??;

    assert!(
        error.error.message.contains("managed") && error.error.message.contains("invalid matcher"),
        "unexpected error message: {}",
        error.error.message
    );

    Ok(())
}

#[tokio::test]
async fn thread_start_fails_when_managed_hook_handler_is_unsupported() -> Result<()> {
    let server = create_mock_responses_server_repeating_assistant("Done").await;
    let codex_home = TempDir::new()?;
    create_config_toml_without_approval_policy(codex_home.path(), &server.uri())?;
    std::fs::write(
        codex_home.path().join("requirements.toml"),
        r#"[hooks]

[[hooks.PreToolUse]]
matcher = "^Bash$"

[[hooks.PreToolUse.hooks]]
type = "prompt"
"#,
    )?;

    let mut app_server = TestAppServer::builder()
        .with_codex_home(codex_home.path())
        .build_initialized()
        .await?;
    let request_id = app_server
        .send_thread_start_request_with_auto_env(ThreadStartParams::default())
        .await?;
    let error: JSONRPCError = timeout(
        DEFAULT_READ_TIMEOUT,
        app_server.read_stream_until_error_message(RequestId::Integer(request_id)),
    )
    .await??;

    assert!(
        error.error.message.contains("prompt hook"),
        "unexpected error message: {}",
        error.error.message
    );

    Ok(())
}

#[tokio::test]
async fn thread_start_succeeds_when_managed_mcp_hook_is_supported() -> Result<()> {
    let server = create_mock_responses_server_repeating_assistant("Done").await;
    let codex_home = TempDir::new()?;
    create_config_toml_without_approval_policy(codex_home.path(), &server.uri())?;
    std::fs::write(
        codex_home.path().join("requirements.toml"),
        r#"[hooks]

[[hooks.PreToolUse]]
matcher = "^Bash$"

[[hooks.PreToolUse.hooks]]
type = "mcp_tool"
server = "security"
tool = "scan"
"#,
    )?;

    let mut app_server = TestAppServer::builder()
        .with_codex_home(codex_home.path())
        .build_initialized()
        .await?;
    let response = app_server
        .start_thread(ThreadStartParams::default())
        .await?;

    assert!(!response.thread.id.is_empty());

    Ok(())
}

#[tokio::test]
async fn thread_start_emits_mcp_server_status_updated_notifications() -> Result<()> {
    let server = create_mock_responses_server_repeating_assistant("Done").await;

    let codex_home = TempDir::new()?;
    create_config_toml_with_optional_broken_mcp(codex_home.path(), &server.uri())?;

    let mut mcp = TestAppServer::builder()
        .with_codex_home(codex_home.path())
        .build_initialized()
        .await?;

    let start_response = mcp.start_thread(ThreadStartParams::default()).await?;

    let starting = timeout(
        DEFAULT_READ_TIMEOUT,
        mcp.read_stream_until_matching_notification(
            "mcpServer/startupStatus/updated starting",
            |notification| {
                notification.method == "mcpServer/startupStatus/updated"
                    && notification
                        .params
                        .as_ref()
                        .and_then(|params| params.get("name"))
                        .and_then(Value::as_str)
                        == Some("optional_broken")
                    && notification
                        .params
                        .as_ref()
                        .and_then(|params| params.get("status"))
                        .and_then(Value::as_str)
                        == Some("starting")
            },
        ),
    )
    .await??;
    let starting: ServerNotification = starting.try_into()?;
    let ServerNotification::McpServerStatusUpdated(starting) = starting else {
        anyhow::bail!("unexpected notification variant");
    };
    assert_eq!(
        starting,
        McpServerStatusUpdatedNotification {
            thread_id: Some(start_response.thread.id.clone()),
            name: "optional_broken".to_string(),
            status: McpServerStartupState::Starting,
            error: None,
            failure_reason: None,
        }
    );

    let failed = timeout(
        DEFAULT_READ_TIMEOUT,
        mcp.read_stream_until_matching_notification(
            "mcpServer/startupStatus/updated failed",
            |notification| {
                notification.method == "mcpServer/startupStatus/updated"
                    && notification
                        .params
                        .as_ref()
                        .and_then(|params| params.get("name"))
                        .and_then(Value::as_str)
                        == Some("optional_broken")
                    && notification
                        .params
                        .as_ref()
                        .and_then(|params| params.get("status"))
                        .and_then(Value::as_str)
                        == Some("failed")
            },
        ),
    )
    .await??;
    let failed: ServerNotification = failed.try_into()?;
    let ServerNotification::McpServerStatusUpdated(failed) = failed else {
        anyhow::bail!("unexpected notification variant");
    };
    assert_eq!(failed.thread_id, Some(start_response.thread.id));
    assert_eq!(failed.name, "optional_broken");
    assert_eq!(failed.status, McpServerStartupState::Failed);
    assert_eq!(failed.failure_reason, None);
    assert!(
        failed
            .error
            .as_deref()
            .is_some_and(|error| error.contains("MCP client for `optional_broken` failed to start")),
        "unexpected MCP startup error: {:?}",
        failed.error
    );

    Ok(())
}

#[tokio::test]
async fn thread_start_does_not_wait_for_optional_http_mcp_auth_discovery() -> Result<()> {
    let server = create_mock_responses_server_repeating_assistant("Done").await;
    let listener = TcpListener::bind("127.0.0.1:0").await?;
    let mcp_addr = listener.local_addr()?;
    let (connection_started_tx, connection_started_rx) = oneshot::channel();
    let blackhole_server = tokio::spawn(async move {
        let Ok((connection, _)) = listener.accept().await else {
            return;
        };
        let _ = connection_started_tx.send(());
        let _connection = connection;
        std::future::pending::<()>().await;
    });

    let codex_home = TempDir::new()?;
    create_config_toml_with_optional_http_mcp(
        codex_home.path(),
        &server.uri(),
        &format!("http://{mcp_addr}/mcp"),
    )?;

    let mut mcp = TestAppServer::builder()
        .with_codex_home(codex_home.path())
        .build_initialized()
        .await?;

    let req_id = mcp
        .send_thread_start_request_with_auto_env(ThreadStartParams::default())
        .await?;

    timeout(DEFAULT_READ_TIMEOUT, connection_started_rx)
        .await
        .context("optional HTTP MCP never attempted a connection")??;
    let response = timeout(
        std::time::Duration::from_secs(3),
        mcp.read_stream_until_response_message(RequestId::Integer(req_id)),
    )
    .await
    .context("thread/start waited for optional HTTP MCP auth discovery");
    blackhole_server.abort();
    let response: JSONRPCResponse = response??;
    let response: ThreadStartResponse = to_response(response)?;

    assert!(!response.thread.id.is_empty());
    Ok(())
}

#[test_case("thread/start"; "thread_start")]
#[test_case("model/list"; "model_list")]
#[tokio::test]
async fn config_requests_surface_cloud_config_bundle_load_errors(
    request_method: &str,
) -> Result<()> {
    let server = MockServer::start().await;
    Mock::given(method("GET"))
        .and(path("/backend-api/wham/config/bundle"))
        .respond_with(
            ResponseTemplate::new(401)
                .insert_header("content-type", "text/html")
                .set_body_string("<html>nope</html>"),
        )
        .mount(&server)
        .await;
    Mock::given(method("POST"))
        .and(path("/oauth/token"))
        .respond_with(ResponseTemplate::new(401).set_body_json(json!({
            "error": { "code": "refresh_token_invalidated" }
        })))
        .mount(&server)
        .await;

    let codex_home = TempDir::new()?;
    let model_server = create_mock_responses_server_repeating_assistant("Done").await;
    let chatgpt_base_url = format!("{}/backend-api", server.uri());
    create_config_toml_with_chatgpt_base_url(
        codex_home.path(),
        &model_server.uri(),
        &chatgpt_base_url,
    )?;
    write_chatgpt_auth(
        codex_home.path(),
        ChatGptAuthFixture::new("chatgpt-token")
            .refresh_token("stale-refresh-token")
            .plan_type("business")
            .chatgpt_user_id("user-123")
            .chatgpt_account_id("account-123")
            .account_id("account-123"),
        AuthCredentialsStoreMode::File,
    )?;

    let refresh_token_url = format!("{}/oauth/token", server.uri());
    let mut mcp = TestAppServer::builder()
        .with_codex_home(codex_home.path())
        .with_env_overrides(&[
            ("OPENAI_API_KEY", None),
            (
                REFRESH_TOKEN_URL_OVERRIDE_ENV_VAR,
                Some(refresh_token_url.as_str()),
            ),
        ])
        .build_initialized()
        .await?;

    let req_id = if request_method == "thread/start" {
        mcp.send_thread_start_request_with_auto_env(ThreadStartParams::default())
            .await?
    } else {
        mcp.send_raw_request(request_method, Some(json!({})))
            .await?
    };

    let err: JSONRPCError = timeout(
        DEFAULT_READ_TIMEOUT,
        mcp.read_stream_until_error_message(RequestId::Integer(req_id)),
    )
    .await??;

    assert!(
        err.error.message.contains("failed to load configuration"),
        "unexpected error message: {}",
        err.error.message
    );
    assert_eq!(
        err.error.data,
        Some(json!({
            "reason": "cloudConfigBundle",
            "errorCode": "Auth",
            "action": "relogin",
            "statusCode": 401,
            "detail": "Your access token could not be refreshed because your refresh token was revoked. Please log out and sign in again.",
        }))
    );

    Ok(())
}

#[tokio::test]
async fn thread_start_workspace_write_respects_effective_permissions_for_project_trust()
-> Result<()> {
    let server = create_mock_responses_server_repeating_assistant("Done").await;

    let codex_home = TempDir::new()?;
    create_config_toml_without_approval_policy(codex_home.path(), &server.uri())?;

    let workspace = TempDir::new()?;
    let project_config_dir = workspace.path().join(".codex");
    std::fs::create_dir_all(&project_config_dir)?;
    std::fs::write(
        project_config_dir.join("config.toml"),
        r#"
model_reasoning_effort = "high"
"#,
    )?;

    let mut mcp = TestAppServer::builder()
        .with_codex_home(codex_home.path())
        .build_initialized()
        .await?;
    let config_before = std::fs::read_to_string(codex_home.path().join("config.toml"))?;

    let first_response = mcp
        .start_thread(ThreadStartParams {
            cwd: Some(workspace.path().display().to_string()),
            sandbox: Some(SandboxMode::WorkspaceWrite),
            ..Default::default()
        })
        .await?;

    let ThreadStartResponse {
        approval_policy,
        reasoning_effort,
        ..
    } = mcp
        .start_thread(ThreadStartParams {
            cwd: Some(workspace.path().display().to_string()),
            ..Default::default()
        })
        .await?;

    let config_toml = std::fs::read_to_string(codex_home.path().join("config.toml"))?;
    if cfg!(windows) {
        assert_eq!(
            first_response.sandbox,
            codex_app_server_protocol::SandboxPolicy::ReadOnly {
                network_access: false,
            }
        );
        assert_eq!(reasoning_effort, None);
        assert_eq!(config_toml, config_before);
    } else {
        assert_eq!(approval_policy, AskForApproval::OnRequest);
        assert_eq!(reasoning_effort, Some(ReasoningEffort::High));
        let workspace_abs = workspace.path().to_path_buf().abs();
        let trusted_root = resolve_root_git_project_for_trust(LOCAL_FS.as_ref(), &workspace_abs)
            .await
            .unwrap_or(workspace_abs);
        let trusted_root_key = project_trust_key(trusted_root.as_path());
        assert!(config_toml.contains(&trusted_root_key));
        assert!(config_toml.contains("trust_level = \"trusted\""));
    }

    Ok(())
}

#[tokio::test]
async fn thread_start_with_managed_read_only_does_not_trust_or_load_project_mcp() -> Result<()> {
    let server = create_mock_responses_server_repeating_assistant("Done").await;

    let codex_home = TempDir::new()?;
    create_config_toml_without_approval_policy(codex_home.path(), &server.uri())?;
    std::fs::write(
        codex_home.path().join("managed_config.toml"),
        r#"sandbox_mode = "read-only""#,
    )?;

    let workspace = TempDir::new()?;
    std::fs::create_dir(workspace.path().join(".git"))?;
    let project_config_dir = workspace.path().join(".codex");
    std::fs::create_dir(&project_config_dir)?;
    std::fs::write(
        project_config_dir.join("config.toml"),
        format!(
            r#"[mcp_servers.project-server]
command = {}
required = true
"#,
            toml::Value::String(stdio_server_bin()?),
        ),
    )?;

    let mut mcp = TestAppServer::builder()
        .with_codex_home(codex_home.path())
        .without_auto_env()
        .build_initialized()
        .await?;
    let config_before = std::fs::read_to_string(codex_home.path().join("config.toml"))?;

    let request_id = mcp
        .send_thread_start_request(ThreadStartParams {
            cwd: Some(workspace.path().display().to_string()),
            permissions: Some(BUILT_IN_PERMISSION_PROFILE_WORKSPACE.to_string()),
            environments: Some(Vec::new()),
            ..Default::default()
        })
        .await?;
    let ThreadStartResponse {
        thread, sandbox, ..
    } = timeout(DEFAULT_READ_TIMEOUT, mcp.read_response(request_id)).await??;

    assert_eq!(
        sandbox,
        codex_app_server_protocol::SandboxPolicy::ReadOnly {
            network_access: false,
        }
    );
    assert_eq!(
        std::fs::read_to_string(codex_home.path().join("config.toml"))?,
        config_before
    );
    let mcp_status: ListMcpServerStatusResponse = mcp
        .request(|request_id| ClientRequest::McpServerStatusList {
            request_id,
            params: ListMcpServerStatusParams {
                cursor: None,
                limit: None,
                detail: Some(McpServerStatusDetail::ToolsAndAuthOnly),
                thread_id: Some(thread.id),
            },
        })
        .await?;
    assert_eq!(
        mcp_status,
        ListMcpServerStatusResponse {
            data: Vec::new(),
            next_cursor: None,
        }
    );

    Ok(())
}

#[tokio::test]
async fn thread_start_with_nested_git_cwd_respects_effective_permissions_for_project_trust()
-> Result<()> {
    let server = create_mock_responses_server_repeating_assistant("Done").await;

    let codex_home = TempDir::new()?;
    create_config_toml_without_approval_policy(codex_home.path(), &server.uri())?;

    let repo_root = TempDir::new()?;
    std::fs::create_dir(repo_root.path().join(".git"))?;
    std::fs::write(repo_root.path().join(".git/HEAD"), "ref: refs/heads/main\n")?;
    let nested = repo_root.path().join("nested/project");
    std::fs::create_dir_all(nested.join(".git"))?;

    let mut mcp = TestAppServer::builder()
        .with_codex_home(codex_home.path())
        .build_initialized()
        .await?;
    let config_before = std::fs::read_to_string(codex_home.path().join("config.toml"))?;

    let ThreadStartResponse { sandbox, .. } = mcp
        .start_thread(ThreadStartParams {
            cwd: Some(nested.display().to_string()),
            sandbox: Some(SandboxMode::WorkspaceWrite),
            ..Default::default()
        })
        .await?;

    let config_toml = std::fs::read_to_string(codex_home.path().join("config.toml"))?;
    if cfg!(windows) {
        assert_eq!(
            sandbox,
            codex_app_server_protocol::SandboxPolicy::ReadOnly {
                network_access: false,
            }
        );
        assert_eq!(config_toml, config_before);
    } else {
        let nested_abs = nested.abs();
        let trusted_root = resolve_root_git_project_for_trust(LOCAL_FS.as_ref(), &nested_abs)
            .await
            .expect("git root should resolve");
        let trusted_root_key = project_trust_key(trusted_root.as_path());
        let nested_key = project_trust_key(&nested);
        assert!(config_toml.contains(&trusted_root_key));
        assert!(!config_toml.contains(&nested_key));
    }

    Ok(())
}

#[tokio::test]
async fn thread_start_projectless_does_not_preapprove_later_project_config() -> Result<()> {
    let server = create_mock_responses_server_repeating_assistant("Done").await;
    let codex_home = TempDir::new()?;
    create_config_toml_without_approval_policy(codex_home.path(), &server.uri())?;
    let workspace = TempDir::new()?;
    let config_path = codex_home.path().join("config.toml");
    let config_before = std::fs::read_to_string(&config_path)?;
    let mut mcp = TestAppServer::builder()
        .with_codex_home(codex_home.path())
        .build_initialized()
        .await?;

    let response = mcp
        .start_thread(ThreadStartParams {
            cwd: Some(workspace.path().display().to_string()),
            sandbox: Some(SandboxMode::DangerFullAccess),
            ..Default::default()
        })
        .await?;
    assert_eq!(
        response.sandbox,
        codex_app_server_protocol::SandboxPolicy::DangerFullAccess
    );
    assert_eq!(std::fs::read_to_string(&config_path)?, config_before);

    let project_config_dir = workspace.path().join(".codex");
    std::fs::create_dir(&project_config_dir)?;
    std::fs::write(
        project_config_dir.join("config.toml"),
        "model_reasoning_effort = \"high\"\n",
    )?;
    let response = mcp
        .start_thread(ThreadStartParams {
            cwd: Some(workspace.path().display().to_string()),
            sandbox: Some(SandboxMode::ReadOnly),
            ..Default::default()
        })
        .await?;
    assert_eq!(response.reasoning_effort, None);
    assert_eq!(std::fs::read_to_string(&config_path)?, config_before);
    Ok(())
}

#[tokio::test]
async fn thread_start_with_read_only_sandbox_does_not_persist_project_trust() -> Result<()> {
    let server = create_mock_responses_server_repeating_assistant("Done").await;

    let codex_home = TempDir::new()?;
    create_config_toml_without_approval_policy(codex_home.path(), &server.uri())?;

    let workspace = TempDir::new()?;
    std::fs::create_dir(workspace.path().join(".codex"))?;

    let mut mcp = TestAppServer::builder()
        .with_codex_home(codex_home.path())
        .build_initialized()
        .await?;

    mcp.start_thread(ThreadStartParams {
        cwd: Some(workspace.path().display().to_string()),
        ..Default::default()
    })
    .await?;

    let config_toml = std::fs::read_to_string(codex_home.path().join("config.toml"))?;
    assert!(!config_toml.contains("trust_level = \"trusted\""));
    assert!(!config_toml.contains(&workspace.path().display().to_string()));

    Ok(())
}

#[tokio::test]
async fn thread_start_preserves_untrusted_project_trust() -> Result<()> {
    let server = create_mock_responses_server_repeating_assistant("Done").await;

    let codex_home = TempDir::new()?;
    create_config_toml_without_approval_policy(codex_home.path(), &server.uri())?;

    let workspace = TempDir::new()?;
    std::fs::create_dir(workspace.path().join(".codex"))?;
    let config_path = codex_home.path().join("config.toml");
    let workspace_key = workspace.path().display().to_string();
    let mut config_toml =
        std::fs::read_to_string(&config_path)?.parse::<toml_edit::DocumentMut>()?;
    config_toml["projects"][workspace_key.as_str()]["trust_level"] = toml_edit::value("untrusted");
    std::fs::write(&config_path, config_toml.to_string())?;
    let config_before = std::fs::read_to_string(&config_path)?;

    let mut mcp = TestAppServer::builder()
        .with_codex_home(codex_home.path())
        .build_initialized()
        .await?;

    mcp.start_thread(ThreadStartParams {
        cwd: Some(workspace.path().display().to_string()),
        sandbox: Some(SandboxMode::WorkspaceWrite),
        ..Default::default()
    })
    .await?;

    let config_after = std::fs::read_to_string(&config_path)?;
    assert_eq!(config_after, config_before);

    Ok(())
}

#[tokio::test]
async fn thread_start_skips_trust_write_when_project_is_already_trusted() -> Result<()> {
    let server = create_mock_responses_server_repeating_assistant("Done").await;

    let codex_home = TempDir::new()?;
    create_config_toml_without_approval_policy(codex_home.path(), &server.uri())?;

    let workspace = TempDir::new()?;
    let project_config_dir = workspace.path().join(".codex");
    std::fs::create_dir_all(&project_config_dir)?;
    std::fs::write(
        project_config_dir.join("config.toml"),
        r#"
model_reasoning_effort = "high"
"#,
    )?;
    set_project_trust_level(codex_home.path(), workspace.path(), TrustLevel::Trusted)?;
    let config_before = std::fs::read_to_string(codex_home.path().join("config.toml"))?;

    let mut mcp = TestAppServer::builder()
        .with_codex_home(codex_home.path())
        .build_initialized()
        .await?;

    let ThreadStartResponse {
        approval_policy,
        reasoning_effort,
        ..
    } = mcp
        .start_thread(ThreadStartParams {
            cwd: Some(workspace.path().display().to_string()),
            sandbox: Some(SandboxMode::WorkspaceWrite),
            ..Default::default()
        })
        .await?;

    assert_eq!(approval_policy, AskForApproval::OnRequest);
    assert_eq!(reasoning_effort, Some(ReasoningEffort::High));

    let config_after = std::fs::read_to_string(codex_home.path().join("config.toml"))?;
    assert_eq!(config_after, config_before);

    Ok(())
}

fn create_config_toml_without_approval_policy(
    codex_home: &Path,
    server_uri: &str,
) -> std::io::Result<()> {
    create_config_toml(codex_home, server_uri, "sandbox_mode = \"read-only\"", "")
}

fn create_config_toml(
    codex_home: &Path,
    server_uri: &str,
    top_level_config: &str,
    additional_tables: &str,
) -> std::io::Result<()> {
    std::fs::write(
        codex_home.join("config.toml"),
        format!(
            r#"
model = "mock-model"
{top_level_config}

model_provider = "mock_provider"

[model_providers.mock_provider]
name = "Mock provider for test"
base_url = "{server_uri}/v1"
wire_api = "responses"
request_max_retries = 0
stream_max_retries = 0
{additional_tables}
"#
        ),
    )
}

fn create_config_toml_with_profile_workspace_root(
    codex_home: &Path,
    server_uri: &str,
    profile_root: &Path,
) -> std::io::Result<()> {
    let profile_root_key = profile_root
        .display()
        .to_string()
        .replace('\\', "\\\\")
        .replace('"', "\\\"");
    create_config_toml(
        codex_home,
        server_uri,
        "default_permissions = \"dev\"",
        &format!(
            r#"
[permissions.dev.workspace_roots]
"{profile_root_key}" = true

# This test only exercises workspace roots; Windows restricted-token sandboxes
# cannot enforce a filesystem policy without root read access.
[permissions.dev.filesystem]
":root" = "read"

[permissions.dev.filesystem.":workspace_roots"]
"." = "write"
"#,
        ),
    )
}

fn create_config_toml_with_chatgpt_base_url(
    codex_home: &Path,
    server_uri: &str,
    chatgpt_base_url: &str,
) -> std::io::Result<()> {
    create_config_toml(
        codex_home,
        server_uri,
        &format!(
            "approval_policy = \"never\"\nsandbox_mode = \"read-only\"\nchatgpt_base_url = \"{chatgpt_base_url}\""
        ),
        "",
    )
}

fn create_config_toml_with_required_broken_mcp(
    codex_home: &Path,
    server_uri: &str,
) -> std::io::Result<()> {
    create_config_toml(
        codex_home,
        server_uri,
        "approval_policy = \"never\"\nsandbox_mode = \"read-only\"",
        &format!(
            r#"
[mcp_servers.required_broken]
{required_broken_transport}
required = true
"#,
            required_broken_transport = broken_mcp_transport_toml()
        ),
    )
}

fn create_config_toml_with_optional_broken_mcp(
    codex_home: &Path,
    server_uri: &str,
) -> std::io::Result<()> {
    create_config_toml(
        codex_home,
        server_uri,
        "approval_policy = \"never\"\nsandbox_mode = \"read-only\"",
        &format!(
            r#"
[mcp_servers.optional_broken]
{optional_broken_transport}
"#,
            optional_broken_transport = broken_mcp_transport_toml()
        ),
    )
}

fn create_config_toml_with_optional_http_mcp(
    codex_home: &Path,
    server_uri: &str,
    mcp_uri: &str,
) -> std::io::Result<()> {
    create_config_toml(
        codex_home,
        server_uri,
        "approval_policy = \"never\"\nsandbox_mode = \"read-only\"",
        &format!(
            r#"
[mcp_servers.optional_http]
url = "{mcp_uri}"
startup_timeout_sec = 60
"#,
        ),
    )
}

#[cfg(target_os = "windows")]
fn broken_mcp_transport_toml() -> &'static str {
    r#"command = "cmd"
args = ["/C", "exit 1"]"#
}

#[cfg(not(target_os = "windows"))]
fn broken_mcp_transport_toml() -> &'static str {
    r#"command = "/bin/sh"
args = ["-c", "exit 1"]"#
}
