mod account;
#[path = "account_system_proxy_tests.rs"]
mod account_system_proxy;
mod account_thread_usage;
mod agent_message_board;
mod analytics;
mod app_installed;
mod app_list;
mod app_read;
mod attestation;
mod auto_env;
mod bedrock_setup;
mod client_metadata;
mod code_mode_host;
mod collaboration_mode_list;
#[cfg(unix)]
mod command_exec;
mod compaction;
#[path = "config_model_provider_requirements_tests.rs"]
mod config_model_provider_requirements;
mod config_requirements_application;
#[path = "config_requirements_browser_use_tests.rs"]
mod config_requirements_browser_use;
#[path = "config_requirements_exec_tests.rs"]
mod config_requirements_exec;
mod config_requirements_in_app_browser;
mod config_requirements_login;
mod config_rpc;
#[cfg(unix)]
#[path = "connection_handling_stdio_tests.rs"]
mod connection_handling_stdio;
mod connection_handling_websocket;
#[cfg(unix)]
mod connection_handling_websocket_unix;
#[cfg(unix)]
mod curated_mcp_sync;
mod current_time;
mod cyber_access_program;
mod daemon_update_recovery;
mod daybreak_access;
mod dynamic_tools;
mod environment_add;
mod environment_info;
mod environment_status;
mod exec_server_test_support;
#[cfg(not(target_os = "windows"))]
mod executor_mcp;
mod executor_skills;
mod experimental_api;
mod experimental_feature_list;
mod external_agent_config;
mod external_agent_import_sync;
mod feedback;
mod fs;
mod git_attribution;
mod guardian_v2;
mod history_notes_extension;
mod hooks_list;
mod host_skills;
mod imagegen_extension;
mod initialize;
mod luna_reserve;
mod marketplace_add;
mod marketplace_remove;
mod marketplace_upgrade;
mod mcp_event_stream;
mod mcp_protocol_default;
mod mcp_resource;
mod mcp_resource_origin;
mod mcp_server_elicitation;
mod mcp_server_status;
mod mcp_tool;
mod memory_read;
mod memory_reset;
mod misalignment_policy;
mod model_auto_review;
mod model_list;
mod model_list_requirements_tests;
mod model_provider_capabilities_read;
#[path = "model_provider_enforcement_tests.rs"]
mod model_provider_enforcement;
mod multi_agent_v2_developer_instructions;
mod otel;
mod output_schema;
mod permission_profile_list;
mod plan_item;
mod plugin_install;
mod plugin_list;
mod plugin_read;
mod plugin_reconcile;
mod plugin_search;
mod plugin_share;
mod plugin_uninstall;
mod process_exec;
mod projects;
mod rate_limit_reset_credits;
mod rate_limits;
#[path = "rate_limits_identity_tests.rs"]
mod rate_limits_identity;
mod realtime_conversation;
mod recommended_plugins;
mod remote_control;
#[cfg(debug_assertions)]
mod remote_thread_store;
mod request_permissions;
mod request_user_input;
mod request_validation;
mod residency;
mod review;
#[path = "rollout_compress_tests.rs"]
mod rollout_compress;
mod rollout_migration;
mod safety_check_downgrade;
#[cfg(not(target_os = "windows"))]
mod selected_capability_stack;
mod selected_environment;
mod server_diagnostics;
#[cfg(not(target_os = "windows"))]
mod session_end;
mod skills_list;
mod sleep;
mod thread_archive;
mod thread_attachments;
mod thread_delete;
mod thread_environments;
mod thread_fork;
#[path = "thread_fork_multi_agent_tests.rs"]
mod thread_fork_multi_agent;
mod thread_goal_empty_responses;
mod thread_inject_items;
mod thread_list;
mod thread_loaded_list;
mod thread_memory_mode_set;
mod thread_metadata_update;
mod thread_name_websocket;
mod thread_queue;
mod thread_read;
mod thread_resume;
mod thread_revert;
mod thread_sections;
mod thread_settings_update;
mod thread_shell_command;
mod thread_start;
mod thread_status;
mod thread_timeline;
mod thread_unarchive;
mod thread_unsubscribe;
mod turn_cost_otel;
mod turn_interrupt;
mod turn_settings_update;
mod turn_start;
mod turn_start_zsh_fork;
mod turn_steer;
mod view_image;
mod web_search;
mod windows_sandbox_setup;
mod workspace_routing;

mod user_verification;
mod user_verification_mcp;
